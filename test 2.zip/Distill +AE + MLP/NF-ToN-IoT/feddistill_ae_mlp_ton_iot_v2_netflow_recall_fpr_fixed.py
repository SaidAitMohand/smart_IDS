import os
import copy
import random
import pickle
import subprocess
import sys

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    fbeta_score,
    confusion_matrix,
    classification_report,
    roc_auc_score,
)

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader

try:
    import joblib
except Exception:
    joblib = None

try:
    from tqdm.auto import tqdm
except Exception:
    tqdm = None


# =========================================================
# 1. PARAMETRES - ToN-IoT NetFlow v2
# =========================================================
DATA_FOLDER = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/TON_IoT"
PARQUET_FILE = os.path.join(DATA_FOLDER, "NF-ToN-IoT-V2.parquet")
FEATURE_DESCRIPTION_CSV = os.path.join(DATA_FOLDER, "NetFlow v2 Features.csv")

SAVE_FOLDER = "C:/Users/anis/Desktop/M2_RMSE/Memoire/Tests/TON_IoT/FedDistill_AE_MLP_NetFlowV2_RECALL_FPR"
os.makedirs(SAVE_FOLDER, exist_ok=True)

# Si votre Python n'a pas pyarrow/duckdb, mettez True pour que le script tente :
# python -m pip install pyarrow
AUTO_INSTALL_PARQUET_ENGINE = False

# Si True, cree aussi une copie CSV du parquet lu.
CONVERT_PARQUET_TO_CSV = False
CONVERTED_CSV_FILE = os.path.join(DATA_FOLDER, "NF-ToN-IoT-V2_converted.csv")

RANDOM_STATE = 42
TEST_SIZE = 0.30
VALID_SIZE = 0.20
AE_VALID_SIZE = 0.20

NUM_CLIENTS = 5
CLIENT_DATA_PROPORTIONS = [0.40, 0.25, 0.18, 0.12, 0.05]

GLOBAL_ROUNDS = 10
LOCAL_EPOCHS_AE = 5
LOCAL_EPOCHS_MLP = 8

PUBLIC_DISTILL_SIZE = 15000
DISTILL_EPOCHS = 4
DISTILL_TEMPERATURE = 3.0
DISTILL_ALPHA = 0.65

BATCH_SIZE = 512
LEARNING_RATE_AE = 1e-3
LEARNING_RATE_MLP = 8e-4
WEIGHT_DECAY_MLP = 1e-4

AUTO_THRESHOLD_PERCENTILES = np.concatenate([
    np.arange(70.0, 99.0, 0.5),
    np.arange(99.0, 99.95, 0.05),
])

MAX_ALLOWED_FPR = 0.08
MLP_THRESHOLD_GRID = np.arange(0.01, 0.96, 0.01)

USE_FOCAL_LOSS = True
FOCAL_GAMMA = 2.0
ATTACK_CLASS_WEIGHT_MULTIPLIER = 1.7

USE_RECONSTRUCTION_ERROR_AS_FEATURE = True
USE_AE_DECISION_AS_MLP_FEATURE = True
MAX_CATEGORICAL_UNIQUE = 60

NORMAL_LABEL = 0
ATTACK_LABEL = 1

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device utilise :", DEVICE)

random.seed(RANDOM_STATE)
np.random.seed(RANDOM_STATE)
torch.manual_seed(RANDOM_STATE)
if torch.cuda.is_available():
    torch.cuda.manual_seed_all(RANDOM_STATE)


def progress(iterable, **kwargs):
    if tqdm is None:
        return iterable
    kwargs.setdefault("dynamic_ncols", True)
    return tqdm(iterable, **kwargs)


def save_object(obj, path):
    if joblib is not None:
        joblib.dump(obj, path)
        return
    with open(path, "wb") as file:
        pickle.dump(obj, file)


def validate_config():
    if len(CLIENT_DATA_PROPORTIONS) != NUM_CLIENTS:
        raise ValueError("CLIENT_DATA_PROPORTIONS doit avoir la meme longueur que NUM_CLIENTS.")
    if any(p <= 0 for p in CLIENT_DATA_PROPORTIONS):
        raise ValueError("Toutes les proportions clients doivent etre positives.")
    if not np.isclose(sum(CLIENT_DATA_PROPORTIONS), 1.0):
        raise ValueError("La somme de CLIENT_DATA_PROPORTIONS doit etre egale a 1.0.")


validate_config()


# =========================================================
# 2. LECTURE PARQUET ROBUSTE
# =========================================================
def try_install_pyarrow():
    if not AUTO_INSTALL_PARQUET_ENGINE:
        return False
    print("\nAUTO_INSTALL_PARQUET_ENGINE=True : installation de pyarrow...")
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pyarrow"])
        return True
    except Exception as exc:
        print("Installation pyarrow impossible :", exc)
        return False


def read_parquet_robust(path):
    errors = []

    try:
        return pd.read_parquet(path), "pandas/pyarrow-or-fastparquet"
    except Exception as exc:
        errors.append(f"pandas: {exc}")

    if try_install_pyarrow():
        try:
            return pd.read_parquet(path), "pandas/pyarrow"
        except Exception as exc:
            errors.append(f"pandas apres installation pyarrow: {exc}")

    try:
        import polars as pl
        return pl.read_parquet(path).to_pandas(), "polars"
    except Exception as exc:
        errors.append(f"polars: {exc}")

    try:
        import duckdb
        sql_path = path.replace("\\", "/").replace("'", "''")
        return duckdb.sql(f"SELECT * FROM read_parquet('{sql_path}')").df(), "duckdb"
    except Exception as exc:
        errors.append(f"duckdb: {exc}")

    msg = "\n".join(errors)
    raise RuntimeError(
        "\nImpossible de lire NF-ToN-IoT-V2.parquet.\n"
        "Le fichier 'NetFlow v2 Features.csv' n'est PAS le dataset : c'est seulement "
        "le dictionnaire des colonnes Feature/Description.\n\n"
        "Solution recommandee dans PowerShell :\n"
        f'  & "{sys.executable}" -m pip install pyarrow\n\n'
        "Ou bien :\n"
        f'  & "{sys.executable}" -m pip install duckdb\n\n'
        "Details erreurs :\n"
        + msg
    )


def load_netflow_v2_dataset():
    if not os.path.exists(PARQUET_FILE):
        raise FileNotFoundError(f"Fichier parquet introuvable : {PARQUET_FILE}")

    print("\nLecture du vrai dataset parquet :", PARQUET_FILE)
    df, engine = read_parquet_robust(PARQUET_FILE)
    print("Parquet charge avec succes via :", engine)

    if CONVERT_PARQUET_TO_CSV:
        print("Conversion parquet -> CSV :", CONVERTED_CSV_FILE)
        df.to_csv(CONVERTED_CSV_FILE, index=False)

    if os.path.exists(FEATURE_DESCRIPTION_CSV):
        print("Info : le fichier CSV detecte est le dictionnaire des features, pas les donnees :")
        print("      ", FEATURE_DESCRIPTION_CSV)

    return df, PARQUET_FILE


# =========================================================
# 3. LABELS ET PRETRAITEMENT
# =========================================================
LABEL_CANDIDATES = [
    "Label", "label", "TARGET", "target", "class", "Class",
    "binary_label", "BinaryLabel", "attack", "Attack",
]

NORMAL_STRINGS = {
    "0", "normal", "benign", "legitimate", "normal.", "benign.",
    "false", "no", "none", "normal traffic",
}

DROP_COLS_ALWAYS = [
    "id", "ID", "Flow ID", "flow_id", "FlowID",
    "ts", "timestamp", "Timestamp", "stime", "ltime", "time", "Time",
    "src_ip", "dst_ip", "Src IP", "Dst IP", "IPV4_SRC_ADDR", "IPV4_DST_ADDR",
    "src_mac", "dst_mac", "MAC", "Unnamed: 0",
]

LEAKAGE_COLS = [
    "Attack", "attack", "type", "Type", "category", "Category",
    "attack_cat", "Attack_cat", "subcategory", "Subcategory",
]

HIGH_CARDINALITY_TEXT_HINTS = [
    "uri", "url", "user_agent", "host", "query", "subject", "issuer",
    "dns", "ssl", "http", "ftp", "smtp",
]


def find_label_column(df):
    for col in LABEL_CANDIDATES:
        if col in df.columns:
            return col
    raise ValueError("Colonne label introuvable. Colonnes disponibles : " + ", ".join(list(df.columns)[:100]))


def make_binary_labels(series):
    numeric = pd.to_numeric(series, errors="coerce")
    if numeric.notna().mean() > 0.95:
        return (numeric.fillna(0).astype(float) != 0).astype(np.int64).values

    values = series.astype(str).str.strip().str.lower()
    return (~values.isin(NORMAL_STRINGS)).astype(np.int64).values


def split_raw_features_labels(df):
    df = df.copy()
    df.columns = df.columns.str.strip()

    label_col = find_label_column(df)
    y = make_binary_labels(df[label_col])
    original_labels = df[label_col].copy().values

    X_df = df.drop(columns=[label_col])
    drop_cols = [c for c in DROP_COLS_ALWAYS if c in X_df.columns]
    drop_cols += [c for c in LEAKAGE_COLS if c in X_df.columns]

    if drop_cols:
        drop_cols = sorted(set(drop_cols))
        X_df = X_df.drop(columns=drop_cols, errors="ignore")
        print("\nColonnes supprimees (IDs/leakage) :", drop_cols)

    return X_df, y, original_labels, label_col


def fit_preprocessor(train_df):
    df = train_df.copy()
    df.columns = df.columns.str.strip()

    numeric_cols = []
    categorical_cols = []
    dropped_text_cols = []

    for col in df.columns:
        converted = pd.to_numeric(df[col], errors="coerce")
        numeric_ratio = converted.notna().mean()
        if numeric_ratio >= 0.95:
            df[col] = converted
            numeric_cols.append(col)
            continue

        values = df[col].astype(str).fillna("missing").str.strip()
        nunique = values.nunique(dropna=True)
        looks_high_card = any(hint in col.lower() for hint in HIGH_CARDINALITY_TEXT_HINTS)
        if nunique <= MAX_CATEGORICAL_UNIQUE and not looks_high_card:
            categorical_cols.append(col)
        else:
            dropped_text_cols.append(col)

    if dropped_text_cols:
        print("\nColonnes texte haute cardinalite supprimees :", dropped_text_cols)

    num_df = df[numeric_cols].copy() if numeric_cols else pd.DataFrame(index=df.index)
    num_df = num_df.replace([np.inf, -np.inf], np.nan)
    medians = num_df.median(numeric_only=True)
    num_df = num_df.fillna(medians).fillna(0)

    cat_df = pd.DataFrame(index=df.index)
    category_levels = {}
    for col in categorical_cols:
        values = df[col].astype(str).fillna("missing").str.strip()
        levels = values.value_counts().head(MAX_CATEGORICAL_UNIQUE).index.tolist()
        category_levels[col] = levels
        values = values.where(values.isin(levels), other="__OTHER__")
        cat_df = pd.concat([cat_df, pd.get_dummies(values, prefix=col, dtype=np.float32)], axis=1)

    X_df = pd.concat([num_df, cat_df], axis=1)
    X_df = X_df.replace([np.inf, -np.inf], np.nan).fillna(0)

    constant_cols = [col for col in X_df.columns if X_df[col].nunique() <= 1]
    if constant_cols:
        X_df = X_df.drop(columns=constant_cols)
        print("Colonnes constantes supprimees :", len(constant_cols))

    feature_columns = list(X_df.columns)
    scaler = StandardScaler()
    X = scaler.fit_transform(X_df).astype(np.float32)
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)

    return X, {
        "numeric_cols": numeric_cols,
        "categorical_cols": categorical_cols,
        "category_levels": category_levels,
        "dropped_text_cols": dropped_text_cols,
        "medians": medians,
        "feature_columns": feature_columns,
        "scaler": scaler,
    }


def transform_preprocessor(df, preprocessor):
    df = df.copy()
    df.columns = df.columns.str.strip()

    numeric_cols = preprocessor["numeric_cols"]
    categorical_cols = preprocessor["categorical_cols"]
    category_levels = preprocessor["category_levels"]
    medians = preprocessor["medians"]
    feature_columns = preprocessor["feature_columns"]
    scaler = preprocessor["scaler"]

    num_df = pd.DataFrame(index=df.index)
    for col in numeric_cols:
        if col in df.columns:
            num_df[col] = pd.to_numeric(df[col], errors="coerce")
        else:
            num_df[col] = np.nan
    num_df = num_df.replace([np.inf, -np.inf], np.nan).fillna(medians).fillna(0)

    cat_df = pd.DataFrame(index=df.index)
    for col in categorical_cols:
        if col in df.columns:
            values = df[col].astype(str).fillna("missing").str.strip()
        else:
            values = pd.Series(["missing"] * len(df), index=df.index)
        levels = category_levels[col]
        values = values.where(values.isin(levels), other="__OTHER__")
        cat_df = pd.concat([cat_df, pd.get_dummies(values, prefix=col, dtype=np.float32)], axis=1)

    X_df = pd.concat([num_df, cat_df], axis=1)
    X_df = X_df.reindex(columns=feature_columns, fill_value=0)
    X_df = X_df.replace([np.inf, -np.inf], np.nan).fillna(0)

    X = scaler.transform(X_df).astype(np.float32)
    return np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)


def print_distribution(title, y):
    print(f"\n===== {title} =====")
    print(pd.Series(y).value_counts().sort_index())
    print("Normal :", int(np.sum(y == NORMAL_LABEL)))
    print("Attack :", int(np.sum(y == ATTACK_LABEL)))


# =========================================================
# 4. FEDDISTILL / MODELES
# =========================================================
def split_clients_unsupervised(X, proportions):
    idx = np.random.permutation(len(X))
    X = X[idx]
    counts = [int(len(X) * p) for p in proportions]
    counts[-1] = len(X) - sum(counts[:-1])
    clients, start = [], 0
    for count in counts:
        clients.append(X[start:start + count])
        start += count
    return clients


def split_clients_supervised(X, y, proportions):
    idx = np.random.permutation(len(X))
    X, y = X[idx], y[idx]
    counts = [int(len(X) * p) for p in proportions]
    counts[-1] = len(X) - sum(counts[:-1])
    clients, start = [], 0
    for count in counts:
        clients.append((X[start:start + count], y[start:start + count]))
        start += count
    return clients


def weighted_average_state_dicts(state_dicts, sizes):
    total_size = sum(sizes)
    avg_state = copy.deepcopy(state_dicts[0])
    for key in avg_state.keys():
        if not torch.is_floating_point(avg_state[key]):
            avg_state[key] = state_dicts[0][key]
            continue
        avg_state[key] = torch.zeros_like(avg_state[key])
        for state, size in zip(state_dicts, sizes):
            avg_state[key] += state[key] * (size / total_size)
    return avg_state


def fedavg_aggregate(local_weights, local_sizes, model_name):
    print(f"\n===== AGREGATION FEDAVG : {model_name} =====")
    print("Tailles clients :", local_sizes)
    return weighted_average_state_dicts(local_weights, local_sizes)


def sample_public_distillation_set(X, y, max_size, random_state=42):
    if len(X) <= max_size:
        return X, y
    try:
        _, X_public, _, y_public = train_test_split(
            X, y, test_size=max_size, random_state=random_state, stratify=y
        )
        return X_public, y_public
    except Exception:
        rng = np.random.default_rng(random_state)
        idx = rng.choice(len(X), size=max_size, replace=False)
        return X[idx], y[idx]


class Autoencoder(nn.Module):
    def __init__(self, input_dim):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 256), nn.ReLU(),
            nn.Linear(256, 128), nn.ReLU(),
            nn.Linear(128, 64), nn.ReLU(),
        )
        self.decoder = nn.Sequential(
            nn.Linear(64, 128), nn.ReLU(),
            nn.Linear(128, 256), nn.ReLU(),
            nn.Linear(256, input_dim),
        )

    def forward(self, x):
        return self.decoder(self.encoder(x))

    def encode(self, x):
        return self.encoder(x)


class MLPBinaryClassifier(nn.Module):
    def __init__(self, input_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 256), nn.ReLU(), nn.BatchNorm1d(256), nn.Dropout(0.40),
            nn.Linear(256, 128), nn.ReLU(), nn.BatchNorm1d(128), nn.Dropout(0.30),
            nn.Linear(128, 64), nn.ReLU(), nn.BatchNorm1d(64), nn.Dropout(0.20),
            nn.Linear(64, 2),
        )

    def forward(self, x):
        return self.net(x)


class FocalLoss(nn.Module):
    def __init__(self, weight=None, gamma=2.0):
        super().__init__()
        self.weight = weight
        self.gamma = gamma

    def forward(self, logits, targets):
        ce = nn.functional.cross_entropy(logits, targets, weight=self.weight, reduction="none")
        pt = torch.exp(-ce)
        return (((1.0 - pt) ** self.gamma) * ce).mean()


def make_ae_loader(X, shuffle=True):
    t = torch.tensor(X, dtype=torch.float32)
    return DataLoader(TensorDataset(t, t), batch_size=BATCH_SIZE, shuffle=shuffle)


def make_supervised_loader(X, y, shuffle=True):
    Xt = torch.tensor(X, dtype=torch.float32)
    yt = torch.tensor(y, dtype=torch.long)
    return DataLoader(TensorDataset(Xt, yt), batch_size=BATCH_SIZE, shuffle=shuffle)


def train_local_autoencoder(global_model, client_X, client_idx):
    local_model = copy.deepcopy(global_model).to(DEVICE)
    local_model.train()
    loader = make_ae_loader(client_X, shuffle=True)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(local_model.parameters(), lr=LEARNING_RATE_AE)
    losses = []

    for epoch_idx in range(LOCAL_EPOCHS_AE):
        running_loss = 0.0
        iterator = progress(loader, desc=f"AE Client {client_idx + 1} E{epoch_idx + 1}/{LOCAL_EPOCHS_AE}", leave=False)
        for batch_x, batch_target in iterator:
            batch_x = batch_x.to(DEVICE)
            batch_target = batch_target.to(DEVICE)
            optimizer.zero_grad()
            loss = criterion(local_model(batch_x), batch_target)
            if torch.isnan(loss):
                continue
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * batch_x.size(0)
            if tqdm is not None:
                iterator.set_postfix(loss=f"{loss.item():.4f}")
        losses.append(running_loss / len(loader.dataset))

    return local_model.state_dict(), len(client_X), float(np.mean(losses))


def build_class_weights(y):
    counts = np.bincount(y, minlength=2)
    total = counts.sum()
    weights = total / (2.0 * np.maximum(counts, 1))
    weights[ATTACK_LABEL] *= ATTACK_CLASS_WEIGHT_MULTIPLIER
    return torch.tensor(weights, dtype=torch.float32).to(DEVICE)


def train_local_mlp(global_model, client_X, client_y, client_idx):
    local_model = copy.deepcopy(global_model).to(DEVICE)
    local_model.train()
    loader = make_supervised_loader(client_X, client_y, shuffle=True)
    class_weights = build_class_weights(client_y)
    criterion = FocalLoss(weight=class_weights, gamma=FOCAL_GAMMA) if USE_FOCAL_LOSS else nn.CrossEntropyLoss(weight=class_weights)
    optimizer = optim.AdamW(local_model.parameters(), lr=LEARNING_RATE_MLP, weight_decay=WEIGHT_DECAY_MLP)
    losses = []

    for epoch_idx in range(LOCAL_EPOCHS_MLP):
        running_loss = 0.0
        iterator = progress(loader, desc=f"MLP Client {client_idx + 1} E{epoch_idx + 1}/{LOCAL_EPOCHS_MLP}", leave=False)
        for batch_x, batch_y in iterator:
            batch_x = batch_x.to(DEVICE)
            batch_y = batch_y.to(DEVICE)
            optimizer.zero_grad()
            loss = criterion(local_model(batch_x), batch_y)
            if torch.isnan(loss):
                continue
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * batch_x.size(0)
            if tqdm is not None:
                iterator.set_postfix(loss=f"{loss.item():.4f}")
        losses.append(running_loss / len(loader.dataset))

    return local_model.state_dict(), len(client_X), float(np.mean(losses))


def collect_soft_targets_from_clients(client_models, X_public, client_sizes, temperature):
    loader = DataLoader(torch.tensor(X_public, dtype=torch.float32), batch_size=BATCH_SIZE, shuffle=False)
    all_client_probs = []
    for model in progress(client_models, desc="Collecte soft labels clients", leave=False):
        model.eval()
        probs_batches = []
        with torch.no_grad():
            for batch_x in loader:
                logits = model(batch_x.to(DEVICE))
                probs_batches.append(torch.softmax(logits / temperature, dim=1).cpu().numpy())
        all_client_probs.append(np.vstack(probs_batches))

    total_size = sum(client_sizes)
    soft_targets = np.zeros_like(all_client_probs[0], dtype=np.float32)
    for probs, size in zip(all_client_probs, client_sizes):
        soft_targets += probs * (size / total_size)
    soft_targets = soft_targets / np.clip(soft_targets.sum(axis=1, keepdims=True), 1e-12, None)
    return soft_targets.astype(np.float32)


def distill_global_mlp(global_model, X_public, y_public, soft_targets):
    model = copy.deepcopy(global_model).to(DEVICE)
    model.train()
    dataset = TensorDataset(
        torch.tensor(X_public, dtype=torch.float32),
        torch.tensor(y_public, dtype=torch.long),
        torch.tensor(soft_targets, dtype=torch.float32),
    )
    loader = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True)
    class_weights = build_class_weights(y_public)
    ce_loss = FocalLoss(weight=class_weights, gamma=FOCAL_GAMMA) if USE_FOCAL_LOSS else nn.CrossEntropyLoss(weight=class_weights)
    kl_loss = nn.KLDivLoss(reduction="batchmean")
    optimizer = optim.AdamW(model.parameters(), lr=LEARNING_RATE_MLP, weight_decay=WEIGHT_DECAY_MLP)
    losses = []

    for epoch_idx in range(DISTILL_EPOCHS):
        running_loss = 0.0
        iterator = progress(loader, desc=f"Serveur distillation E{epoch_idx + 1}/{DISTILL_EPOCHS}", leave=False)
        for batch_x, batch_y, batch_soft in iterator:
            batch_x = batch_x.to(DEVICE)
            batch_y = batch_y.to(DEVICE)
            batch_soft = batch_soft.to(DEVICE)
            optimizer.zero_grad()
            logits = model(batch_x)
            loss_ce = ce_loss(logits, batch_y)
            log_probs = torch.log_softmax(logits / DISTILL_TEMPERATURE, dim=1)
            loss_kd = kl_loss(log_probs, batch_soft) * (DISTILL_TEMPERATURE ** 2)
            loss = (1.0 - DISTILL_ALPHA) * loss_ce + DISTILL_ALPHA * loss_kd
            if torch.isnan(loss):
                continue
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * batch_x.size(0)
            if tqdm is not None:
                iterator.set_postfix(loss=f"{loss.item():.4f}")
        losses.append(running_loss / len(loader.dataset))

    return model.state_dict(), float(np.mean(losses))


# =========================================================
# 5. SEUILS / FEATURES / EVALUATION
# =========================================================
def compute_reconstruction_errors(model, X):
    model.eval()
    loader = DataLoader(torch.tensor(X, dtype=torch.float32), batch_size=BATCH_SIZE, shuffle=False)
    errors = []
    with torch.no_grad():
        for batch_x in loader:
            batch_x = batch_x.to(DEVICE)
            output = model(batch_x)
            errors.extend(torch.mean((batch_x - output) ** 2, dim=1).cpu().numpy())
    return np.array(errors, dtype=np.float32)


def choose_auto_threshold_percentile(normal_reference_errors, validation_errors, validation_y):
    best = {"percentile": None, "threshold": None, "accuracy": -1.0, "precision": 0.0, "recall": 0.0, "f1": -1.0, "fpr": 1.0}
    for percentile in AUTO_THRESHOLD_PERCENTILES:
        threshold = float(np.percentile(normal_reference_errors, percentile))
        pred = (validation_errors > threshold).astype(np.int64)
        acc = accuracy_score(validation_y, pred)
        prec = precision_score(validation_y, pred, zero_division=0)
        rec = recall_score(validation_y, pred, zero_division=0)
        f1 = f1_score(validation_y, pred, zero_division=0)
        tn, fp, fn, tp = confusion_matrix(validation_y, pred, labels=[NORMAL_LABEL, ATTACK_LABEL]).ravel()
        fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
        if f1 > best["f1"] or (np.isclose(f1, best["f1"]) and fpr < best["fpr"]):
            best = {"percentile": float(percentile), "threshold": threshold, "accuracy": float(acc), "precision": float(prec), "recall": float(rec), "f1": float(f1), "fpr": float(fpr)}
    return best


def extract_ae_features_and_detection(model, X, threshold, normal_error_std):
    model.eval()
    loader = DataLoader(torch.tensor(X, dtype=torch.float32), batch_size=BATCH_SIZE, shuffle=False)
    all_z, all_errors = [], []
    with torch.no_grad():
        for batch_x in loader:
            batch_x = batch_x.to(DEVICE)
            z = model.encode(batch_x)
            x_hat = model(batch_x)
            err = torch.mean((batch_x - x_hat) ** 2, dim=1, keepdim=True)
            all_z.append(z.cpu().numpy())
            all_errors.append(err.cpu().numpy())

    z_all = np.vstack(all_z).astype(np.float32)
    err_all = np.vstack(all_errors).astype(np.float32)
    features = [z_all]
    if USE_RECONSTRUCTION_ERROR_AS_FEATURE:
        features.append(err_all)
    ae_pred = (err_all > threshold).astype(np.float32)
    ae_score = ((err_all - threshold) / max(normal_error_std, 1e-12)).astype(np.float32)
    if USE_AE_DECISION_AS_MLP_FEATURE:
        features.extend([ae_pred, ae_score])
    return np.hstack(features).astype(np.float32), err_all.ravel(), ae_pred.ravel().astype(np.int64), ae_score.ravel()


def predict_mlp(model, X):
    model.eval()
    loader = DataLoader(torch.tensor(X, dtype=torch.float32), batch_size=BATCH_SIZE, shuffle=False)
    preds, probs = [], []
    softmax = nn.Softmax(dim=1)
    with torch.no_grad():
        for batch_x in loader:
            p = softmax(model(batch_x.to(DEVICE)))
            preds.extend(torch.argmax(p, dim=1).cpu().numpy())
            probs.append(p.cpu().numpy())
    return np.array(preds), np.vstack(probs)


def choose_mlp_threshold_recall_fpr(y_true, attack_scores, max_fpr=0.08):
    best, fallback = None, None
    for threshold in MLP_THRESHOLD_GRID:
        pred = (attack_scores >= threshold).astype(np.int64)
        tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[NORMAL_LABEL, ATTACK_LABEL]).ravel()
        fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
        info = {
            "threshold": float(threshold),
            "accuracy": float(accuracy_score(y_true, pred)),
            "precision": float(precision_score(y_true, pred, zero_division=0)),
            "recall": float(recall_score(y_true, pred, zero_division=0)),
            "f1": float(f1_score(y_true, pred, zero_division=0)),
            "f2": float(fbeta_score(y_true, pred, beta=2.0, zero_division=0)),
            "fpr": float(fpr),
            "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
        }
        if fallback is None or info["f2"] > fallback["f2"]:
            fallback = info
        if fpr <= max_fpr:
            if best is None or info["recall"] > best["recall"] or (np.isclose(info["recall"], best["recall"]) and info["f1"] > best["f1"]):
                best = info

    if best is None:
        fallback["note"] = "Aucun seuil ne respecte MAX_ALLOWED_FPR; seuil choisi par meilleur F2."
        return fallback
    best["note"] = f"Seuil choisi pour maximiser recall avec FPR <= {max_fpr}."
    return best


def evaluate_binary(name, y_true, y_pred, scores=None):
    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    f2 = fbeta_score(y_true, y_pred, beta=2.0, zero_division=0)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[NORMAL_LABEL, ATTACK_LABEL]).ravel()
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    fnr = fn / (fn + tp) if (fn + tp) > 0 else 0.0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    try:
        auc = roc_auc_score(y_true, scores) if scores is not None else np.nan
    except Exception:
        auc = np.nan

    print(f"\n===== RESULTATS {name} =====")
    print("Accuracy              :", acc)
    print("Precision             :", prec)
    print("Recall / DetectionRate:", rec)
    print("F1-score              :", f1)
    print("F2-score              :", f2)
    print("Specificity           :", specificity)
    print("False Positive Rate   :", fpr)
    print("False Negative Rate   :", fnr)
    print("ROC-AUC               :", auc)
    print("\nMatrice de confusion :")
    print(np.array([[tn, fp], [fn, tp]]))
    print("\nClassification report :")
    print(classification_report(y_true, y_pred, target_names=["Normal", "Attack"], digits=4, zero_division=0))
    return {
        "accuracy": float(acc), "precision": float(prec), "recall_detection_rate": float(rec),
        "f1_score": float(f1), "f2_score": float(f2), "specificity": float(specificity),
        "fpr": float(fpr), "fnr": float(fnr),
        "roc_auc": float(auc) if not np.isnan(auc) else np.nan,
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
    }


# =========================================================
# 6. PIPELINE PRINCIPAL
# =========================================================
df_all, source_path = load_netflow_v2_dataset()
df_all.columns = df_all.columns.str.strip()

print("\n===== DATASET BRUT ToN-IoT NetFlow v2 =====")
print("Source :", source_path)
print("Shape  :", df_all.shape)
print("Colonnes :", list(df_all.columns)[:50])

X_df_all, y_all, original_labels, label_col = split_raw_features_labels(df_all)
print("\nColonne label utilisee :", label_col)
print_distribution("DISTRIBUTION COMPLETE", y_all)

df_train_full, df_test, y_train_full, y_test, labels_train_full, labels_test = train_test_split(
    X_df_all, y_all, original_labels, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=y_all
)
df_train, df_val, y_train, y_val, labels_train, labels_val = train_test_split(
    df_train_full, y_train_full, labels_train_full, test_size=VALID_SIZE, random_state=RANDOM_STATE, stratify=y_train_full
)

print("\n===== SPLIT DATA =====")
print("Train final :", df_train.shape, " (~56%)")
print("Validation  :", df_val.shape, " (~14%)")
print("Test        :", df_test.shape, " (~30%)")
print_distribution("TRAIN", y_train)
print_distribution("VALIDATION", y_val)
print_distribution("TEST", y_test)

print("\n===== PRETRAITEMENT =====")
X_train, preprocessor = fit_preprocessor(df_train)
X_val = transform_preprocessor(df_val, preprocessor)
X_test = transform_preprocessor(df_test, preprocessor)
feature_columns = preprocessor["feature_columns"]
print("X_train :", X_train.shape)
print("X_val   :", X_val.shape)
print("X_test  :", X_test.shape)
print("Nombre features :", len(feature_columns))

X_train_normal = X_train[y_train == NORMAL_LABEL]
if len(X_train_normal) == 0:
    raise ValueError("Aucune donnee normale pour entrainer l'autoencodeur.")

X_ae_train, X_ae_val = train_test_split(X_train_normal, test_size=AE_VALID_SIZE, random_state=RANDOM_STATE)
print("\n===== DONNEES AUTOENCODEUR =====")
print("AE train normal :", X_ae_train.shape)
print("AE val normal   :", X_ae_val.shape)

clients_ae = split_clients_unsupervised(X_ae_train, CLIENT_DATA_PROPORTIONS)
print("\n===== CLIENTS AE FEDAVG =====")
for i, client_X in enumerate(clients_ae):
    print(f"Client AE {i + 1}: X={client_X.shape}")

input_dim = X_train.shape[1]
global_ae = Autoencoder(input_dim).to(DEVICE)
best_ae_val_loss = float("inf")
best_ae_path = os.path.join(SAVE_FOLDER, "best_feddistill_autoencoder_ton_iot_v2.pth")

print("\n===== DEBUT ENTRAINEMENT FEDAVG + AE =====")
for round_idx in range(GLOBAL_ROUNDS):
    print(f"\n--- Round AE {round_idx + 1}/{GLOBAL_ROUNDS} ---")
    local_weights, local_sizes, local_losses = [], [], []
    for client_idx, client_X in enumerate(clients_ae):
        weights, size, loss = train_local_autoencoder(global_ae, client_X, client_idx)
        local_weights.append(weights)
        local_sizes.append(size)
        local_losses.append(loss)
        print(f"Client AE {client_idx + 1} | size={size} | loss={loss:.6f}")
    global_ae.load_state_dict(fedavg_aggregate(local_weights, local_sizes, "Autoencoder"))
    val_loss = float(np.mean(compute_reconstruction_errors(global_ae, X_ae_val)))
    print(f"Loss moyenne clients AE : {np.mean(local_losses):.6f}")
    print(f"Validation loss AE      : {val_loss:.6f}")
    if val_loss < best_ae_val_loss:
        best_ae_val_loss = val_loss
        torch.save(global_ae.state_dict(), best_ae_path)
        print(">> Meilleur AE sauvegarde.")

best_ae = Autoencoder(input_dim).to(DEVICE)
best_ae.load_state_dict(torch.load(best_ae_path, map_location=DEVICE))
best_ae.eval()

print("\n===== CHOIX AUTOMATIQUE DU SEUIL AE =====")
normal_reference_errors = compute_reconstruction_errors(best_ae, X_ae_train)
val_errors_for_threshold = compute_reconstruction_errors(best_ae, X_val)
ae_threshold_info = choose_auto_threshold_percentile(normal_reference_errors, val_errors_for_threshold, y_val)
AE_THRESHOLD_PERCENTILE = ae_threshold_info["percentile"]
AE_THRESHOLD = ae_threshold_info["threshold"]
AE_NORMAL_ERROR_STD = float(np.std(normal_reference_errors))
print("threshold_percentile choisi :", AE_THRESHOLD_PERCENTILE)
print("threshold AE                :", AE_THRESHOLD)
print("Validation AE F1            :", ae_threshold_info["f1"])
print("Validation AE Recall        :", ae_threshold_info["recall"])
print("Validation AE FPR           :", ae_threshold_info["fpr"])

print("\n===== EXTRACTION FEATURES AE POUR MLP =====")
X_mlp_train, train_errors, train_ae_pred, train_ae_score = extract_ae_features_and_detection(best_ae, X_train, AE_THRESHOLD, AE_NORMAL_ERROR_STD)
X_mlp_val, val_errors, val_ae_pred, val_ae_score = extract_ae_features_and_detection(best_ae, X_val, AE_THRESHOLD, AE_NORMAL_ERROR_STD)
X_test_mlp, test_errors, test_ae_pred, test_ae_score = extract_ae_features_and_detection(best_ae, X_test, AE_THRESHOLD, AE_NORMAL_ERROR_STD)

print("\n===== PERFORMANCE AE SEUL SUR VALIDATION =====")
print("Train AE F1 :", f1_score(y_train, train_ae_pred, zero_division=0))
print("Val AE F1   :", f1_score(y_val, val_ae_pred, zero_division=0))
print(confusion_matrix(y_val, val_ae_pred, labels=[NORMAL_LABEL, ATTACK_LABEL]))

mlp_feature_scaler = StandardScaler()
X_mlp_train = mlp_feature_scaler.fit_transform(X_mlp_train).astype(np.float32)
X_mlp_val = mlp_feature_scaler.transform(X_mlp_val).astype(np.float32)
X_test_mlp = mlp_feature_scaler.transform(X_test_mlp).astype(np.float32)
print("X_mlp_train :", X_mlp_train.shape)
print("X_mlp_val   :", X_mlp_val.shape)
print("X_test_mlp  :", X_test_mlp.shape)

clients_mlp = split_clients_supervised(X_mlp_train, y_train, CLIENT_DATA_PROPORTIONS)
print("\n===== CLIENTS MLP FEDDISTILL =====")
for i, (client_X, client_y) in enumerate(clients_mlp):
    print(f"Client MLP {i + 1}: X={client_X.shape} | normal={np.sum(client_y == NORMAL_LABEL)} | attack={np.sum(client_y == ATTACK_LABEL)}")

X_public_distill, y_public_distill = sample_public_distillation_set(X_mlp_val, y_val, PUBLIC_DISTILL_SIZE, RANDOM_STATE)
print("\n===== JEU PUBLIC / PROXY FEDDISTILL =====")
print("X_public_distill :", X_public_distill.shape)
print("Normal public    :", np.sum(y_public_distill == NORMAL_LABEL))
print("Attack public    :", np.sum(y_public_distill == ATTACK_LABEL))

mlp_input_dim = X_mlp_train.shape[1]
global_mlp = MLPBinaryClassifier(mlp_input_dim).to(DEVICE)
best_mlp_val_f2 = -1.0
best_mlp_path = os.path.join(SAVE_FOLDER, "best_feddistill_mlp_ton_iot_v2.pth")

print("\n===== DEBUT ENTRAINEMENT FEDDISTILL + MLP =====")
for round_idx in range(GLOBAL_ROUNDS):
    print(f"\n--- Round FedDistill MLP {round_idx + 1}/{GLOBAL_ROUNDS} ---")
    local_models, local_sizes, local_losses = [], [], []
    for client_idx, (client_X, client_y) in enumerate(clients_mlp):
        weights, size, loss = train_local_mlp(global_mlp, client_X, client_y, client_idx)
        client_model = MLPBinaryClassifier(mlp_input_dim).to(DEVICE)
        client_model.load_state_dict(weights)
        client_model.eval()
        local_models.append(client_model)
        local_sizes.append(size)
        local_losses.append(loss)
        print(f"Client MLP {client_idx + 1} | size={size} | loss={loss:.6f}")

    soft_targets = collect_soft_targets_from_clients(local_models, X_public_distill, local_sizes, DISTILL_TEMPERATURE)
    distilled_weights, distill_loss = distill_global_mlp(global_mlp, X_public_distill, y_public_distill, soft_targets)
    global_mlp.load_state_dict(distilled_weights)

    _, val_probs = predict_mlp(global_mlp, X_mlp_val)
    val_scores = val_probs[:, ATTACK_LABEL]
    val_threshold_info = choose_mlp_threshold_recall_fpr(y_val, val_scores, MAX_ALLOWED_FPR)
    val_pred_threshold = (val_scores >= val_threshold_info["threshold"]).astype(np.int64)
    val_f2 = fbeta_score(y_val, val_pred_threshold, beta=2.0, zero_division=0)

    print(f"Loss moyenne clients MLP  : {np.mean(local_losses):.6f}")
    print(f"Loss distillation serveur : {distill_loss:.6f}")
    print(f"Validation F2 seuil       : {val_f2:.6f}")
    print(f"Validation Recall seuil   : {val_threshold_info['recall']:.6f}")
    print(f"Validation FPR seuil      : {val_threshold_info['fpr']:.6f}")
    print(f"Seuil MLP temporaire      : {val_threshold_info['threshold']:.4f}")
    if val_f2 > best_mlp_val_f2:
        best_mlp_val_f2 = val_f2
        torch.save(global_mlp.state_dict(), best_mlp_path)
        print(">> Meilleur MLP FedDistill sauvegarde.")

best_mlp = MLPBinaryClassifier(mlp_input_dim).to(DEVICE)
best_mlp.load_state_dict(torch.load(best_mlp_path, map_location=DEVICE))
best_mlp.eval()

print("\n===== CHOIX FINAL DU SEUIL MLP RECALL/FPR =====")
_, val_probs = predict_mlp(best_mlp, X_mlp_val)
val_scores = val_probs[:, ATTACK_LABEL]
mlp_threshold_info = choose_mlp_threshold_recall_fpr(y_val, val_scores, MAX_ALLOWED_FPR)
MLP_DECISION_THRESHOLD = mlp_threshold_info["threshold"]
print("Seuil MLP choisi :", MLP_DECISION_THRESHOLD)
print("Validation MLP Recall:", mlp_threshold_info["recall"])
print("Validation MLP F1    :", mlp_threshold_info["f1"])
print("Validation MLP F2    :", mlp_threshold_info["f2"])
print("Validation MLP FPR   :", mlp_threshold_info["fpr"])
print("Note seuil           :", mlp_threshold_info["note"])

print("\n===== TEST FINAL AE -> MLP FEDDISTILL SUR ToN-IoT NetFlow v2 =====")
test_pred_argmax, test_probs = predict_mlp(best_mlp, X_test_mlp)
test_scores = test_probs[:, ATTACK_LABEL]
test_pred_threshold = (test_scores >= MLP_DECISION_THRESHOLD).astype(np.int64)

ae_test_metrics = evaluate_binary("AE SEUL - SEUIL AUTO", y_test, test_ae_pred, scores=test_errors)
argmax_metrics = evaluate_binary("FedDistill AE -> MLP ARGMAX", y_test, test_pred_argmax, scores=test_scores)
final_metrics = evaluate_binary("FedDistill AE -> MLP SEUIL RECALL/FPR", y_test, test_pred_threshold, scores=test_scores)

print("\n===== RESUME ERREURS RECONSTRUCTION TEST =====")
print(pd.Series(test_errors).describe())
print("\n===== RESUME SCORES MLP TEST =====")
print(pd.Series(test_scores).describe())

torch.save(best_ae.state_dict(), os.path.join(SAVE_FOLDER, "feddistill_autoencoder_ton_iot_v2_final.pth"))
torch.save(best_mlp.state_dict(), os.path.join(SAVE_FOLDER, "feddistill_mlp_ton_iot_v2_final.pth"))
save_object(preprocessor, os.path.join(SAVE_FOLDER, "preprocessor_ton_iot_v2.pkl"))
save_object(mlp_feature_scaler, os.path.join(SAVE_FOLDER, "mlp_feature_scaler_ton_iot_v2.pkl"))
save_object(ae_threshold_info, os.path.join(SAVE_FOLDER, "ae_threshold_info_ton_iot_v2.pkl"))
save_object(MLP_DECISION_THRESHOLD, os.path.join(SAVE_FOLDER, "mlp_decision_threshold_ton_iot_v2.pkl"))
save_object(mlp_threshold_info, os.path.join(SAVE_FOLDER, "mlp_threshold_info_ton_iot_v2.pkl"))

metadata = {
    "architecture": (
        "ToN-IoT NetFlow v2 FedDistill + AE + MLP. AE normal-only, seuil AE auto, "
        "MLP avec latent AE + erreur + decision AE + score AE, FocalLoss, "
        "pondération attaque, distillation, seuil MLP recall/FPR."
    ),
    "source_path": source_path,
    "label_col": label_col,
    "num_clients": NUM_CLIENTS,
    "client_data_proportions": CLIENT_DATA_PROPORTIONS,
    "test_size": TEST_SIZE,
    "valid_size": VALID_SIZE,
    "ae_valid_size": AE_VALID_SIZE,
    "global_rounds": GLOBAL_ROUNDS,
    "local_epochs_ae": LOCAL_EPOCHS_AE,
    "local_epochs_mlp": LOCAL_EPOCHS_MLP,
    "public_distill_size": PUBLIC_DISTILL_SIZE,
    "distill_epochs": DISTILL_EPOCHS,
    "distill_temperature": DISTILL_TEMPERATURE,
    "distill_alpha": DISTILL_ALPHA,
    "learning_rate_ae": LEARNING_RATE_AE,
    "learning_rate_mlp": LEARNING_RATE_MLP,
    "weight_decay_mlp": WEIGHT_DECAY_MLP,
    "use_focal_loss": USE_FOCAL_LOSS,
    "attack_class_weight_multiplier": ATTACK_CLASS_WEIGHT_MULTIPLIER,
    "max_allowed_fpr": MAX_ALLOWED_FPR,
    "best_ae_val_loss": best_ae_val_loss,
    "best_mlp_val_f2": best_mlp_val_f2,
    "input_dim": input_dim,
    "mlp_input_dim": mlp_input_dim,
    "ae_threshold_percentile": AE_THRESHOLD_PERCENTILE,
    "ae_threshold": AE_THRESHOLD,
    "mlp_decision_threshold": MLP_DECISION_THRESHOLD,
    "feature_columns": feature_columns,
}

all_metrics = {
    "ae_test_metrics": ae_test_metrics,
    "argmax_mlp_metrics": argmax_metrics,
    "final_threshold_mlp_metrics": final_metrics,
    "ae_threshold_info": ae_threshold_info,
    "mlp_threshold_info": mlp_threshold_info,
}
save_object(metadata, os.path.join(SAVE_FOLDER, "metadata_feddistill_ae_mlp_ton_iot_v2.pkl"))
save_object(all_metrics, os.path.join(SAVE_FOLDER, "metrics_feddistill_ae_mlp_ton_iot_v2.pkl"))

results_df = pd.DataFrame({
    "label_original": labels_test,
    "y_true": y_test,
    "ae_pred": test_ae_pred,
    "mlp_pred_argmax": test_pred_argmax,
    "mlp_pred_threshold": test_pred_threshold,
    "reconstruction_error": test_errors,
    "ae_score": test_ae_score,
    "mlp_attack_score": test_scores,
})
results_path = os.path.join(SAVE_FOLDER, "detailed_predictions_feddistill_ae_mlp_ton_iot_v2.csv")
results_df.to_csv(results_path, index=False)

print("\n===== SAUVEGARDE TERMINEE =====")
print("Dossier resultats :", SAVE_FOLDER)
print("Fichier predictions :", results_path)
print("Seuil AE sauvegarde :", AE_THRESHOLD)
print("Seuil MLP sauvegarde :", MLP_DECISION_THRESHOLD)
