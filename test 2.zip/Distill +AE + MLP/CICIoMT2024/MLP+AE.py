import os
import glob
import copy
import random
import joblib
import tarfile
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
    roc_auc_score
)

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader

try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False


# =========================================================
# 1. PARAMÈTRES  (adaptés CIC-IoMT 2024)
# =========================================================
BENIGN_TRAIN_FILE = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/CIC IOMT 24/Train/Benign_train.pcap.csv"
TRAIN_FOLDER      = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/CIC IOMT 24/Train"
TEST_FOLDER       = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/CIC IOMT 24/Test"

SAVE_FOLDER = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/CIC IOMT 24/FedDistill_AE_MLP"
os.makedirs(SAVE_FOLDER, exist_ok=True)

LABEL_COL     = "label"
NORMAL_VALUES = ["benign", "normal", "0", 0]

RANDOM_STATE  = 42
VALID_SIZE_AE = 0.2          # fraction benign réservée à la validation AE

NUM_CLIENTS               = 5
CLIENT_DATA_PROPORTIONS   = [0.40, 0.25, 0.18, 0.12, 0.05]

GLOBAL_ROUNDS     = 10
LOCAL_EPOCHS_AE   = 5
LOCAL_EPOCHS_MLP  = 5

# FedDistill
PUBLIC_DISTILL_SIZE  = 10_000
DISTILL_EPOCHS       = 3
DISTILL_TEMPERATURE  = 2.0
DISTILL_ALPHA        = 0.7

BATCH_SIZE        = 256
LEARNING_RATE_AE  = 1e-3
LEARNING_RATE_MLP = 1e-3

USE_RECONSTRUCTION_ERROR_AS_FEATURE = True

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device utilisé :", DEVICE)

random.seed(RANDOM_STATE)
np.random.seed(RANDOM_STATE)
torch.manual_seed(RANDOM_STATE)


# =========================================================
# 2. BARRE DE PROGRESSION (fallback ASCII si tqdm absent)
# =========================================================
class ProgressBar:
    """Barre d'avancement légère compatible tqdm ou ASCII."""

    def __init__(self, total: int, desc: str = "", unit: str = "batch"):
        self.total   = total
        self.desc    = desc
        self.unit    = unit
        self.current = 0
        self._bar    = None

        if TQDM_AVAILABLE:
            self._bar = tqdm(total=total, desc=desc, unit=unit,
                             ncols=90, leave=True,
                             bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]")

    def update(self, n: int = 1):
        self.current += n
        if self._bar:
            self._bar.update(n)
        else:
            pct   = self.current / self.total if self.total else 1
            width = 40
            done  = int(width * pct)
            bar   = "█" * done + "░" * (width - done)
            print(f"\r{self.desc}: [{bar}] {self.current}/{self.total} {self.unit}",
                  end="", flush=True)
            if self.current >= self.total:
                print()

    def set_postfix(self, **kwargs):
        if self._bar:
            self._bar.set_postfix(**kwargs)

    def close(self):
        if self._bar:
            self._bar.close()
        elif self.current < self.total:
            print()


# =========================================================
# 3. LECTURE CSV / TAR.XZ
# =========================================================
def read_csv_or_tarxz(path: str) -> pd.DataFrame:
    if path.endswith(".tar.xz"):
        with tarfile.open(path, "r:xz") as tar:
            members = [m for m in tar.getmembers() if m.name.endswith(".csv")]
            if not members:
                raise ValueError(f"Aucun CSV dans {path}")
            f = tar.extractfile(members[0])
            return pd.read_csv(f)
    return pd.read_csv(path)


def list_data_files(folder: str):
    files = []
    files.extend(glob.glob(os.path.join(folder, "*.csv")))
    files.extend(glob.glob(os.path.join(folder, "*.csv.tar.xz")))
    return sorted(files)


# =========================================================
# 4. CHARGEMENT DOSSIER AVEC LABELS
#    (logique identique au script CIC-IoMT 2024 d'origine)
# =========================================================
def load_labeled_folder(folder: str):
    """
    Charge tous les CSV/tar.xz d'un dossier.
    Labels : colonne 'label' si présente, sinon déduit du nom de fichier.
    Retourne X_df (DataFrame brut), y (ndarray int), source_files (list[str]).
    """
    files = list_data_files(folder)
    if not files:
        raise FileNotFoundError(f"Aucun fichier CSV ou csv.tar.xz dans : {folder}")

    dfs, labels, source_files = [], [], []

    print(f"\nChargement dossier : {folder}")
    print("Nombre de fichiers :", len(files))

    for path in files:
        filename = os.path.basename(path)
        df = read_csv_or_tarxz(path)
        df.columns = df.columns.str.strip()

        if LABEL_COL in df.columns:
            y_file = df[LABEL_COL].apply(
                lambda x: 0 if str(x).strip().lower() in [str(v).lower() for v in NORMAL_VALUES] else 1
            ).astype(int).values
            df = df.drop(columns=[LABEL_COL])
        else:
            if "benign" in filename.lower() or "normal" in filename.lower():
                y_file = np.zeros(len(df), dtype=int)
            else:
                y_file = np.ones(len(df), dtype=int)

        dfs.append(df)
        labels.append(y_file)
        source_files.extend([filename] * len(df))

        print(f"[OK] {filename} -> {df.shape} | labels={np.unique(y_file)}")

    X_df = pd.concat(dfs, ignore_index=True)
    y    = np.concatenate(labels)
    return X_df, y, source_files


# =========================================================
# 5. PRÉTRAITEMENT
# =========================================================
_DROP_COLS = ["Flow ID", "flow_id", "Timestamp", "timestamp",
              "Src IP", "Dst IP", "Source IP", "Destination IP", "Unnamed: 0"]


def preprocess_fit(df: pd.DataFrame):
    df = df.copy()
    df.columns = df.columns.str.strip()
    df = df.drop(columns=[c for c in _DROP_COLS if c in df.columns], errors="ignore")
    if LABEL_COL in df.columns:
        df = df.drop(columns=[LABEL_COL])

    df = df.select_dtypes(include=[np.number])
    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.dropna(axis=1, how="all")
    df = df.fillna(df.median(numeric_only=True)).fillna(0)

    constant_cols = [c for c in df.columns if df[c].nunique() <= 1]
    df = df.drop(columns=constant_cols)
    print(f"Colonnes constantes supprimées : {len(constant_cols)}")

    feature_columns = list(df.columns)
    scaler = StandardScaler()
    X = scaler.fit_transform(df).astype(np.float32)
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    return X, scaler, feature_columns


def preprocess_transform(df: pd.DataFrame, scaler, feature_columns):
    df = df.copy()
    df.columns = df.columns.str.strip()
    df = df.drop(columns=[c for c in _DROP_COLS if c in df.columns], errors="ignore")
    if LABEL_COL in df.columns:
        df = df.drop(columns=[LABEL_COL])

    df = df.select_dtypes(include=[np.number])
    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.dropna(axis=1, how="all")
    df = df.fillna(df.median(numeric_only=True)).fillna(0)

    missing = [c for c in feature_columns if c not in df.columns]
    extra   = [c for c in df.columns if c not in feature_columns]
    df = df.reindex(columns=feature_columns, fill_value=0)

    print(f"\nAlignement : colonnes manquantes={len(missing)}, extra ignorées={len(extra)}")

    X = scaler.transform(df).astype(np.float32)
    return np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)


# =========================================================
# 6. MODÈLES  (identiques CICIoT2023)
# =========================================================
class Autoencoder(nn.Module):
    def __init__(self, input_dim: int):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 256), nn.ReLU(),
            nn.Linear(256, 128),       nn.ReLU(),
            nn.Linear(128, 64),        nn.ReLU(),
        )
        self.decoder = nn.Sequential(
            nn.Linear(64, 128),        nn.ReLU(),
            nn.Linear(128, 256),       nn.ReLU(),
            nn.Linear(256, input_dim),
        )

    def forward(self, x):
        return self.decoder(self.encoder(x))

    def encode(self, x):
        return self.encoder(x)


class MLPBinaryClassifier(nn.Module):
    def __init__(self, input_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128), nn.ReLU(),
            nn.BatchNorm1d(128), nn.Dropout(0.3),
            nn.Linear(128, 64),  nn.ReLU(),
            nn.BatchNorm1d(64),  nn.Dropout(0.3),
            nn.Linear(64, 32),   nn.ReLU(),
            nn.Linear(32, 2),
        )

    def forward(self, x):
        return self.net(x)


# =========================================================
# 7. DATA LOADERS
# =========================================================
def make_ae_loader(X, shuffle=True):
    t = torch.tensor(X, dtype=torch.float32)
    return DataLoader(TensorDataset(t, t), batch_size=BATCH_SIZE, shuffle=shuffle)


def make_supervised_loader(X, y, shuffle=True):
    Xt = torch.tensor(X, dtype=torch.float32)
    yt = torch.tensor(y, dtype=torch.long)
    return DataLoader(TensorDataset(Xt, yt), batch_size=BATCH_SIZE, shuffle=shuffle)


# =========================================================
# 8. UTILITAIRES FL
# =========================================================
def normalize_proportions(proportions, num_clients):
    if len(proportions) != num_clients:
        raise ValueError("CLIENT_DATA_PROPORTIONS doit avoir la même taille que NUM_CLIENTS.")
    p = np.array(proportions, dtype=np.float64)
    if np.any(p <= 0):
        raise ValueError("Toutes les proportions doivent être positives.")
    return p / p.sum()


def split_clients_unsupervised(X, num_clients, proportions):
    p   = normalize_proportions(proportions, num_clients)
    idx = np.random.permutation(len(X))
    splits = (np.cumsum(p)[:-1] * len(X)).astype(int)
    return [X[i] for i in np.split(idx, splits)]


def split_clients_supervised(X, y, num_clients, proportions):
    p   = normalize_proportions(proportions, num_clients)
    idx = np.random.permutation(len(X))
    X, y = X[idx], y[idx]
    splits = (np.cumsum(p)[:-1] * len(X)).astype(int)
    return list(zip(np.split(X, splits), np.split(y, splits)))


def weighted_average_state_dicts(state_dicts, sizes):
    total = sum(sizes)
    avg   = copy.deepcopy(state_dicts[0])
    for key in avg:
        if not torch.is_floating_point(avg[key]):
            continue
        avg[key] = sum(sd[key] * (s / total) for sd, s in zip(state_dicts, sizes))
    return avg


def fedavg_aggregate(local_weights, local_sizes, model_name="model"):
    print(f"\n  [FedAvg] Agrégation {model_name} | tailles : {local_sizes}")
    return weighted_average_state_dicts(local_weights, local_sizes)


def sample_public_distillation_set(X, y, max_size, random_state=42):
    if len(X) <= max_size:
        return X, y
    try:
        _, Xp, _, yp = train_test_split(X, y, test_size=max_size,
                                        random_state=random_state, stratify=y)
        return Xp, yp
    except Exception:
        rng = np.random.default_rng(random_state)
        idx = rng.choice(len(X), size=max_size, replace=False)
        return X[idx], y[idx]


def collect_soft_targets(client_models, X_public, client_sizes, temperature):
    loader = DataLoader(torch.tensor(X_public, dtype=torch.float32),
                        batch_size=BATCH_SIZE, shuffle=False)
    all_probs = []
    for model in client_models:
        model.eval()
        batches = []
        with torch.no_grad():
            for bx in loader:
                bx = bx.to(DEVICE)
                p  = torch.softmax(model(bx) / temperature, dim=1)
                batches.append(p.cpu().numpy())
        all_probs.append(np.vstack(batches))

    total  = sum(client_sizes)
    soft   = sum(p * (s / total) for p, s in zip(all_probs, client_sizes))
    soft  /= np.clip(soft.sum(axis=1, keepdims=True), 1e-12, None)
    return soft.astype(np.float32)


# =========================================================
# 9. ENTRAÎNEMENTS LOCAUX AVEC BARRE DE PROGRESSION
# =========================================================
def train_local_ae(global_model, client_X, client_id: int):
    local = copy.deepcopy(global_model).to(DEVICE)
    local.train()

    loader    = make_ae_loader(client_X, shuffle=True)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(local.parameters(), lr=LEARNING_RATE_AE)
    losses    = []

    n_batches = len(loader) * LOCAL_EPOCHS_AE
    bar = ProgressBar(n_batches,
                      desc=f"  Client AE {client_id} ({len(client_X)} samples)",
                      unit="batch")

    for epoch in range(LOCAL_EPOCHS_AE):
        running = 0.0
        for bx, bt in loader:
            bx, bt = bx.to(DEVICE), bt.to(DEVICE)
            optimizer.zero_grad()
            out  = local(bx)
            loss = criterion(out, bt)
            if not torch.isnan(loss):
                loss.backward()
                optimizer.step()
                running += loss.item() * bx.size(0)
            bar.update(1)
            bar.set_postfix(epoch=epoch + 1, loss=f"{loss.item():.5f}")
        losses.append(running / len(loader.dataset))

    bar.close()
    return local.state_dict(), len(client_X), float(np.mean(losses))


def train_local_mlp(global_model, client_X, client_y, client_id: int):
    local = copy.deepcopy(global_model).to(DEVICE)
    local.train()

    loader       = make_supervised_loader(client_X, client_y, shuffle=True)
    class_counts = np.bincount(client_y, minlength=2)
    total        = class_counts.sum()
    weights      = torch.tensor(
        total / (2.0 * np.maximum(class_counts, 1)),
        dtype=torch.float32
    ).to(DEVICE)

    criterion = nn.CrossEntropyLoss(weight=weights)
    optimizer = optim.Adam(local.parameters(), lr=LEARNING_RATE_MLP)
    losses    = []

    n_batches = len(loader) * LOCAL_EPOCHS_MLP
    bar = ProgressBar(n_batches,
                      desc=(f"  Client MLP {client_id} "
                            f"(B={np.sum(client_y==0)}, A={np.sum(client_y==1)})"),
                      unit="batch")

    for epoch in range(LOCAL_EPOCHS_MLP):
        running = 0.0
        for bx, by in loader:
            bx, by = bx.to(DEVICE), by.to(DEVICE)
            optimizer.zero_grad()
            loss = criterion(local(bx), by)
            if not torch.isnan(loss):
                loss.backward()
                optimizer.step()
                running += loss.item() * bx.size(0)
            bar.update(1)
            bar.set_postfix(epoch=epoch + 1, loss=f"{loss.item():.5f}")
        losses.append(running / len(loader.dataset))

    bar.close()
    return local.state_dict(), len(client_X), float(np.mean(losses))


def distill_global_mlp(global_model, X_public, y_public, soft_targets):
    model = copy.deepcopy(global_model).to(DEVICE)
    model.train()

    dataset = TensorDataset(
        torch.tensor(X_public,   dtype=torch.float32),
        torch.tensor(y_public,   dtype=torch.long),
        torch.tensor(soft_targets, dtype=torch.float32),
    )
    loader    = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True)
    ce_loss   = nn.CrossEntropyLoss()
    kl_loss   = nn.KLDivLoss(reduction="batchmean")
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE_MLP)
    losses    = []

    n_batches = len(loader) * DISTILL_EPOCHS
    bar = ProgressBar(n_batches, desc="  [Distillation serveur]", unit="batch")

    for epoch in range(DISTILL_EPOCHS):
        running = 0.0
        for bx, by, bs in loader:
            bx, by, bs = bx.to(DEVICE), by.to(DEVICE), bs.to(DEVICE)
            optimizer.zero_grad()
            logits   = model(bx)
            loss_ce  = ce_loss(logits, by)
            log_prob = torch.log_softmax(logits / DISTILL_TEMPERATURE, dim=1)
            loss_kd  = kl_loss(log_prob, bs) * (DISTILL_TEMPERATURE ** 2)
            loss     = (1 - DISTILL_ALPHA) * loss_ce + DISTILL_ALPHA * loss_kd
            if not torch.isnan(loss):
                loss.backward()
                optimizer.step()
                running += loss.item() * bx.size(0)
            bar.update(1)
            bar.set_postfix(epoch=epoch + 1, loss=f"{loss.item():.5f}")
        losses.append(running / len(loader.dataset))

    bar.close()
    return model.state_dict(), float(np.mean(losses))


# =========================================================
# 10. FEATURES AE + PRÉDICTION MLP
# =========================================================
def reconstruction_errors(model, X):
    model.eval()
    loader = DataLoader(torch.tensor(X, dtype=torch.float32),
                        batch_size=BATCH_SIZE, shuffle=False)
    errs = []
    with torch.no_grad():
        for bx in loader:
            bx  = bx.to(DEVICE)
            err = torch.mean((bx - model(bx)) ** 2, dim=1)
            errs.extend(err.cpu().numpy())
    return np.array(errs)


def extract_ae_features(model, X):
    model.eval()
    loader = DataLoader(torch.tensor(X, dtype=torch.float32),
                        batch_size=BATCH_SIZE, shuffle=False)
    zs, errs = [], []
    with torch.no_grad():
        for bx in loader:
            bx  = bx.to(DEVICE)
            z   = model.encode(bx)
            err = torch.mean((bx - model(bx)) ** 2, dim=1, keepdim=True)
            zs.append(z.cpu().numpy())
            errs.append(err.cpu().numpy())

    z_all   = np.vstack(zs).astype(np.float32)
    err_all = np.vstack(errs).astype(np.float32)
    return np.hstack([z_all, err_all]) if USE_RECONSTRUCTION_ERROR_AS_FEATURE else z_all


def predict_mlp(model, X):
    model.eval()
    loader  = DataLoader(torch.tensor(X, dtype=torch.float32),
                         batch_size=BATCH_SIZE, shuffle=False)
    preds, probs_list = [], []
    softmax = nn.Softmax(dim=1)
    with torch.no_grad():
        for bx in loader:
            bx  = bx.to(DEVICE)
            p   = softmax(model(bx))
            preds.extend(torch.argmax(p, dim=1).cpu().numpy())
            probs_list.append(p.cpu().numpy())
    return np.array(preds), np.vstack(probs_list)


# =========================================================
# 11. ÉVALUATION
# =========================================================
def evaluate(name, y_true, y_pred, scores=None):
    acc  = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec  = recall_score(y_true, y_pred, zero_division=0)
    f1   = f1_score(y_true, y_pred, zero_division=0)

    cm             = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()
    fpr  = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    fnr  = fn / (fn + tp) if (fn + tp) > 0 else 0.0
    spec = tn / (tn + fp) if (tn + fp) > 0 else 0.0

    try:
        auc = roc_auc_score(y_true, scores) if scores is not None else np.nan
    except Exception:
        auc = np.nan

    print(f"\n{'='*55}")
    print(f" RÉSULTATS — {name}")
    print(f"{'='*55}")
    print(f"  Accuracy              : {acc:.4f}")
    print(f"  Precision             : {prec:.4f}")
    print(f"  Recall / Detection    : {rec:.4f}")
    print(f"  F1-score              : {f1:.4f}")
    print(f"  Specificity           : {spec:.4f}")
    print(f"  False Positive Rate   : {fpr:.4f}")
    print(f"  False Negative Rate   : {fnr:.4f}")
    print(f"  ROC-AUC               : {auc:.4f}" if not np.isnan(auc) else "  ROC-AUC               : N/A")
    print("\n  Matrice de confusion :")
    print(cm)
    print("\n  Classification report :")
    print(classification_report(y_true, y_pred,
                                target_names=["Benign", "Attack"],
                                digits=4, zero_division=0))
    return {
        "accuracy": acc, "precision": prec, "recall": rec, "f1_score": f1,
        "specificity": spec, "fpr": fpr, "fnr": fnr, "roc_auc": auc,
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
    }


# =========================================================
# 12. CHARGEMENT BENIGN POUR AE
# =========================================================
print("\n" + "="*55)
print(" ÉTAPE 1 — Chargement Benign (AE)")
print("="*55)

df_benign = read_csv_or_tarxz(BENIGN_TRAIN_FILE)
df_benign.columns = df_benign.columns.str.strip()
if LABEL_COL in df_benign.columns:
    df_benign = df_benign.drop(columns=[LABEL_COL])

print("Shape brute benign :", df_benign.shape)
X_benign, scaler, feature_columns = preprocess_fit(df_benign)
print("Shape après prétraitement :", X_benign.shape)
print("Nombre de features        :", len(feature_columns))


# =========================================================
# 13. SPLIT BENIGN AE TRAIN / VALIDATION
# =========================================================
X_ae_train, X_ae_val = train_test_split(
    X_benign, test_size=VALID_SIZE_AE, random_state=RANDOM_STATE
)
print(f"\nAE train : {X_ae_train.shape} | AE val : {X_ae_val.shape}")

clients_ae = split_clients_unsupervised(X_ae_train, NUM_CLIENTS, CLIENT_DATA_PROPORTIONS)
print("\n===== CLIENTS AE =====")
for i, cx in enumerate(clients_ae):
    print(f"  Client {i+1} : {cx.shape}")


# =========================================================
# 14. ENTRAÎNEMENT AUTOENCODEUR FL (FedAvg — benign only)
# =========================================================
print("\n" + "="*55)
print(" ÉTAPE 2 — Entraînement AE FedAvg (benign only)")
print("="*55)

input_dim = X_benign.shape[1]
ae_model  = Autoencoder(input_dim).to(DEVICE)

best_ae_val_loss = float("inf")
best_ae_path     = os.path.join(SAVE_FOLDER, "best_feddistill_autoencoder.pth")

for rnd in range(GLOBAL_ROUNDS):
    print(f"\n{'─'*50}")
    print(f"  Round AE {rnd+1}/{GLOBAL_ROUNDS}")
    print(f"{'─'*50}")

    lw, ls, ll = [], [], []
    for i, cx in enumerate(clients_ae):
        w, size, loss = train_local_ae(ae_model, cx, client_id=i+1)
        lw.append(w); ls.append(size); ll.append(loss)
        print(f"  → Client {i+1} terminé | size={size} | loss={loss:.6f}")

    ae_model.load_state_dict(fedavg_aggregate(lw, ls, "Autoencoder"))

    val_errs = reconstruction_errors(ae_model, X_ae_val)
    val_loss = float(np.mean(val_errs))
    print(f"\n  [Round {rnd+1}] Val loss AE : {val_loss:.6f}  (best={best_ae_val_loss:.6f})")

    if val_loss < best_ae_val_loss:
        best_ae_val_loss = val_loss
        torch.save(ae_model.state_dict(), best_ae_path)
        print("  >> ✓ Meilleur AE sauvegardé.")

best_ae = Autoencoder(input_dim).to(DEVICE)
best_ae.load_state_dict(torch.load(best_ae_path, map_location=DEVICE))
best_ae.eval()
print(f"\nMeilleure validation loss AE : {best_ae_val_loss:.6f}")


# =========================================================
# 15. CHARGEMENT TRAIN + TEST LABELISÉS
# =========================================================
print("\n" + "="*55)
print(" ÉTAPE 3 — Chargement Train / Test labelisés")
print("="*55)

X_train_df, y_train, src_train = load_labeled_folder(TRAIN_FOLDER)
X_test_df,  y_test,  src_test  = load_labeled_folder(TEST_FOLDER)

print(f"\nTrain — total={len(y_train)} | benign={np.sum(y_train==0)} | attack={np.sum(y_train==1)}")
print(f"Test  — total={len(y_test)}  | benign={np.sum(y_test==0)}  | attack={np.sum(y_test==1)}")

X_train = preprocess_transform(X_train_df, scaler, feature_columns)
X_test  = preprocess_transform(X_test_df,  scaler, feature_columns)


# =========================================================
# 16. EXTRACTION FEATURES AE (AE → latent + erreur)
# =========================================================
print("\n" + "="*55)
print(" ÉTAPE 4 — Extraction features AE")
print("="*55)

X_train_mlp = extract_ae_features(best_ae, X_train)
X_test_mlp  = extract_ae_features(best_ae, X_test)

mlp_feature_scaler = StandardScaler()
X_train_mlp = mlp_feature_scaler.fit_transform(X_train_mlp).astype(np.float32)
X_test_mlp  = mlp_feature_scaler.transform(X_test_mlp).astype(np.float32)

print(f"X_train_mlp : {X_train_mlp.shape}")
print(f"X_test_mlp  : {X_test_mlp.shape}")


# =========================================================
# 17. CLIENTS MLP
# =========================================================
clients_mlp = split_clients_supervised(X_train_mlp, y_train, NUM_CLIENTS, CLIENT_DATA_PROPORTIONS)

print("\n===== CLIENTS MLP =====")
for i, (cx, cy) in enumerate(clients_mlp):
    print(f"  Client {i+1} : X={cx.shape} | benign={np.sum(cy==0)} | attack={np.sum(cy==1)}")


# =========================================================
# 18. JEU PUBLIC FEDDISTILL
# =========================================================
X_public, y_public = sample_public_distillation_set(
    X_test_mlp, y_test, max_size=PUBLIC_DISTILL_SIZE, random_state=RANDOM_STATE
)
print(f"\nJeu public distill : {X_public.shape} | benign={np.sum(y_public==0)} | attack={np.sum(y_public==1)}")


# =========================================================
# 19. ENTRAÎNEMENT FEDDISTILL + MLP
# =========================================================
print("\n" + "="*55)
print(" ÉTAPE 5 — FedDistill + MLP")
print("="*55)

mlp_dim    = X_train_mlp.shape[1]
global_mlp = MLPBinaryClassifier(mlp_dim).to(DEVICE)

best_mlp_f1   = -1.0
best_mlp_path = os.path.join(SAVE_FOLDER, "best_feddistill_mlp_binary.pth")

for rnd in range(GLOBAL_ROUNDS):
    print(f"\n{'─'*50}")
    print(f"  Round FedDistill MLP {rnd+1}/{GLOBAL_ROUNDS}")
    print(f"{'─'*50}")

    local_models, lw, ls, ll = [], [], [], []

    # Entraînement local
    for i, (cx, cy) in enumerate(clients_mlp):
        w, size, loss = train_local_mlp(global_mlp, cx, cy, client_id=i+1)
        cm_i = MLPBinaryClassifier(mlp_dim).to(DEVICE)
        cm_i.load_state_dict(w)
        cm_i.eval()
        local_models.append(cm_i)
        lw.append(w); ls.append(size); ll.append(loss)
        print(f"  → Client {i+1} terminé | size={size} | loss={loss:.6f}")

    # Soft targets + distillation
    print(f"\n  Collecte soft labels des clients sur le jeu public...")
    soft = collect_soft_targets(local_models, X_public, ls, DISTILL_TEMPERATURE)

    print(f"  Distillation du modèle global...")
    dw, dloss = distill_global_mlp(global_mlp, X_public, y_public, soft)
    global_mlp.load_state_dict(dw)

    # Validation
    val_pred, val_probs = predict_mlp(global_mlp, X_test_mlp)
    val_f1  = f1_score(y_test, val_pred, zero_division=0)
    val_acc = accuracy_score(y_test, val_pred)

    print(f"\n  [Round {rnd+1}] Loss clients={np.mean(ll):.5f} | Distill={dloss:.5f}")
    print(f"  [Round {rnd+1}] Val Accuracy={val_acc:.4f} | Val F1={val_f1:.4f}  (best={best_mlp_f1:.4f})")

    if val_f1 > best_mlp_f1:
        best_mlp_f1 = val_f1
        torch.save(global_mlp.state_dict(), best_mlp_path)
        print("  >> ✓ Meilleur MLP sauvegardé.")

best_mlp = MLPBinaryClassifier(mlp_dim).to(DEVICE)
best_mlp.load_state_dict(torch.load(best_mlp_path, map_location=DEVICE))
best_mlp.eval()
print(f"\nMeilleur Val F1 MLP : {best_mlp_f1:.4f}")


# =========================================================
# 20. ÉVALUATION FINALE
# =========================================================
print("\n" + "="*55)
print(" ÉTAPE 6 — Évaluation finale sur Test Set")
print("="*55)

test_pred, test_probs = predict_mlp(best_mlp, X_test_mlp)
test_scores = test_probs[:, 1]

test_results = evaluate("FedDistill AE → MLP  (CIC-IoMT 2024)", y_test, test_pred, scores=test_scores)


# =========================================================
# 21. SAUVEGARDE
# =========================================================
print("\n" + "="*55)
print(" ÉTAPE 7 — Sauvegarde")
print("="*55)

torch.save(best_ae.state_dict(),  os.path.join(SAVE_FOLDER, "feddistill_autoencoder_final.pth"))
torch.save(best_mlp.state_dict(), os.path.join(SAVE_FOLDER, "feddistill_mlp_binary_final.pth"))

joblib.dump(scaler,             os.path.join(SAVE_FOLDER, "scaler.pkl"))
joblib.dump(mlp_feature_scaler, os.path.join(SAVE_FOLDER, "mlp_feature_scaler.pkl"))
joblib.dump(feature_columns,    os.path.join(SAVE_FOLDER, "feature_columns.pkl"))

metadata = {
    "architecture"              : "FedDistill + AE + MLP sur CIC-IoMT 2024",
    "num_clients"               : NUM_CLIENTS,
    "client_data_proportions"   : CLIENT_DATA_PROPORTIONS,
    "global_rounds"             : GLOBAL_ROUNDS,
    "local_epochs_ae"           : LOCAL_EPOCHS_AE,
    "local_epochs_mlp"          : LOCAL_EPOCHS_MLP,
    "public_distill_size"       : PUBLIC_DISTILL_SIZE,
    "distill_epochs"            : DISTILL_EPOCHS,
    "distill_temperature"       : DISTILL_TEMPERATURE,
    "distill_alpha"             : DISTILL_ALPHA,
    "batch_size"                : BATCH_SIZE,
    "learning_rate_ae"          : LEARNING_RATE_AE,
    "learning_rate_mlp"         : LEARNING_RATE_MLP,
    "best_ae_val_loss"          : best_ae_val_loss,
    "best_mlp_val_f1"           : best_mlp_f1,
    "input_dim"                 : input_dim,
    "mlp_input_dim"             : mlp_dim,
    "use_reconstruction_error_as_feature": USE_RECONSTRUCTION_ERROR_AS_FEATURE,
}
joblib.dump(metadata,     os.path.join(SAVE_FOLDER, "metadata.pkl"))
joblib.dump(test_results, os.path.join(SAVE_FOLDER, "metrics.pkl"))

ae_errors_test = X_test_mlp[:, -1] if USE_RECONSTRUCTION_ERROR_AS_FEATURE else np.zeros(len(X_test_mlp))

results_df = pd.DataFrame({
    "source_file"              : src_test,
    "y_true"                   : y_test,
    "y_pred"                   : test_pred,
    "attack_score"             : test_scores,
    "ae_reconstruction_error"  : ae_errors_test,
})
results_df.to_csv(os.path.join(SAVE_FOLDER, "detailed_predictions.csv"), index=False)

print("\nTous les artefacts sauvegardés dans :", SAVE_FOLDER)
print("  ├── feddistill_autoencoder_final.pth")
print("  ├── feddistill_mlp_binary_final.pth")
print("  ├── scaler.pkl / mlp_feature_scaler.pkl / feature_columns.pkl")
print("  ├── metadata.pkl / metrics.pkl")
print("  └── detailed_predictions.csv")
print("\n✓ Pipeline FedDistill AE → MLP sur CIC-IoMT 2024 terminé.")