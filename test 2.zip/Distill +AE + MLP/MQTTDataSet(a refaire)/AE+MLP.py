import os
import copy
import random
import joblib
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
    roc_auc_score,
)

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader

try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False


# =========================================================
# 1. PARAMÈTRES
# =========================================================
TRAIN_PATH = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/MQTT Dataset/Data/FINAL_CSV/train70.csv"
TEST_PATH  = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/MQTT Dataset/Data/FINAL_CSV/test30.csv"

SAVE_FOLDER = "C:/Users/anis/Desktop/M2_RMSE/Memoire/Tests/MQTT dataset/FedDistill_AE_MLP/results"
os.makedirs(SAVE_FOLDER, exist_ok=True)

LABEL_COL    = "target"
NORMAL_CLASS = "legitimate"

RANDOM_STATE  = 42
VALID_SIZE_AE = 0.2          # fraction du benign train réservée à la validation AE

NUM_CLIENTS             = 5
CLIENT_DATA_PROPORTIONS = [0.40, 0.25, 0.18, 0.12, 0.05]

GLOBAL_ROUNDS    = 10
LOCAL_EPOCHS_AE  = 5
LOCAL_EPOCHS_MLP = 5

# FedDistill
PUBLIC_DISTILL_SIZE = 10_000
DISTILL_EPOCHS      = 3
DISTILL_TEMPERATURE = 2.0
DISTILL_ALPHA       = 0.7

BATCH_SIZE        = 512
LEARNING_RATE_AE  = 1e-3
LEARNING_RATE_MLP = 1e-3

USE_RECONSTRUCTION_ERROR_AS_FEATURE = True

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device utilisé :", DEVICE)

random.seed(RANDOM_STATE)
np.random.seed(RANDOM_STATE)
torch.manual_seed(RANDOM_STATE)


# =========================================================
# 2. BARRE DE PROGRESSION (tqdm ou fallback ASCII)
# =========================================================
class ProgressBar:
    """Barre d'avancement compatible tqdm ou ASCII pur."""

    def __init__(self, total: int, desc: str = "", unit: str = "batch"):
        self.total   = total
        self.desc    = desc
        self.unit    = unit
        self.current = 0
        self._bar    = None

        if TQDM_AVAILABLE:
            self._bar = tqdm(
                total=total, desc=desc, unit=unit, ncols=95, leave=True,
                bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]",
            )

    def update(self, n: int = 1):
        self.current += n
        if self._bar:
            self._bar.update(n)
        else:
            pct   = self.current / self.total if self.total else 1.0
            width = 40
            done  = int(width * pct)
            bar   = "█" * done + "░" * (width - done)
            print(f"\r{self.desc}: [{bar}] {self.current}/{self.total} {self.unit}",
                  end="", flush=True)
            if self.current >= self.total:
                print()

    def set_postfix(self, **kwargs):
        if self._bar:
            self._bar.set_postfix(**kwargs)

    def close(self):
        if self._bar:
            self._bar.close()
        elif self.current < self.total:
            print()


# =========================================================
# 3. CHARGEMENT & PRÉPARATION MQTT
# =========================================================
def convert_hex_or_numeric(series: pd.Series) -> pd.Series:
    """Convertit les colonnes hex (0x…) ou catégorielles en numérique."""
    if series.dtype == object or str(series.dtype) == "str":
        try:
            return series.apply(
                lambda x: int(str(x), 16) if str(x).startswith("0x") else float(x)
            )
        except Exception:
            return pd.factorize(series.astype(str))[0].astype(float)
    return series


def prepare_mqtt(train_df: pd.DataFrame, test_df: pd.DataFrame):
    """
    - Encode le label (legitimate → 0, reste → 1)
    - Convertit hex/catégorielles
    - Supprime colonnes constantes
    - Retourne X_train, X_test, y_train, y_test sous forme DataFrame/array
    """
    y_train = (train_df[LABEL_COL] != NORMAL_CLASS).astype(int).values
    y_test  = (test_df[LABEL_COL]  != NORMAL_CLASS).astype(int).values

    X_tr = train_df.drop(columns=[LABEL_COL]).copy()
    X_te = test_df.drop(columns=[LABEL_COL]).copy()

    common_cols = sorted(set(X_tr.columns) & set(X_te.columns))
    X_tr = X_tr[common_cols]
    X_te = X_te[common_cols]

    for col in common_cols:
        X_tr[col] = convert_hex_or_numeric(X_tr[col])
        X_te[col] = convert_hex_or_numeric(X_te[col])

    X_tr = X_tr.replace([np.inf, -np.inf], np.nan)
    X_te = X_te.replace([np.inf, -np.inf], np.nan)

    med = X_tr.median(numeric_only=True)
    X_tr = X_tr.fillna(med)
    X_te = X_te.fillna(med)          # on utilise la médiane du train pour le test

    constant_cols = [c for c in X_tr.columns if X_tr[c].nunique() <= 1]
    if constant_cols:
        X_tr = X_tr.drop(columns=constant_cols)
        X_te = X_te.drop(columns=constant_cols)
        print(f"Colonnes constantes supprimées : {len(constant_cols)}")

    return X_tr, X_te, y_train, y_test


# =========================================================
# 4. MODÈLES
# =========================================================
class Autoencoder(nn.Module):
    def __init__(self, input_dim: int):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 256), nn.ReLU(),
            nn.Linear(256, 128),       nn.ReLU(),
            nn.Linear(128, 64),        nn.ReLU(),
        )
        self.decoder = nn.Sequential(
            nn.Linear(64, 128),        nn.ReLU(),
            nn.Linear(128, 256),       nn.ReLU(),
            nn.Linear(256, input_dim),
        )

    def forward(self, x):
        return self.decoder(self.encoder(x))

    def encode(self, x):
        return self.encoder(x)


class MLPBinaryClassifier(nn.Module):
    def __init__(self, input_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128), nn.ReLU(),
            nn.BatchNorm1d(128), nn.Dropout(0.3),
            nn.Linear(128, 64),  nn.ReLU(),
            nn.BatchNorm1d(64),  nn.Dropout(0.3),
            nn.Linear(64, 32),   nn.ReLU(),
            nn.Linear(32, 2),
        )

    def forward(self, x):
        return self.net(x)


# =========================================================
# 5. DATA LOADERS
# =========================================================
def make_ae_loader(X, shuffle=True):
    t = torch.tensor(X, dtype=torch.float32)
    return DataLoader(TensorDataset(t, t), batch_size=BATCH_SIZE, shuffle=shuffle)


def make_supervised_loader(X, y, shuffle=True):
    Xt = torch.tensor(X, dtype=torch.float32)
    yt = torch.tensor(y, dtype=torch.long)
    return DataLoader(TensorDataset(Xt, yt), batch_size=BATCH_SIZE, shuffle=shuffle)


# =========================================================
# 6. UTILITAIRES FL
# =========================================================
def normalize_proportions(props, n):
    p = np.array(props, dtype=np.float64)
    assert len(p) == n and np.all(p > 0)
    return p / p.sum()


def split_clients_unsupervised(X, n, props):
    p   = normalize_proportions(props, n)
    idx = np.random.permutation(len(X))
    cuts = (np.cumsum(p)[:-1] * len(X)).astype(int)
    return [X[i] for i in np.split(idx, cuts)]


def split_clients_supervised(X, y, n, props):
    p   = normalize_proportions(props, n)
    idx = np.random.permutation(len(X))
    X, y = X[idx], y[idx]
    cuts = (np.cumsum(p)[:-1] * len(X)).astype(int)
    return list(zip(np.split(X, cuts), np.split(y, cuts)))


def weighted_fedavg(state_dicts, sizes):
    total = sum(sizes)
    avg   = copy.deepcopy(state_dicts[0])
    for key in avg:
        if not torch.is_floating_point(avg[key]):
            continue
        avg[key] = sum(sd[key] * (s / total) for sd, s in zip(state_dicts, sizes))
    return avg


def sample_public_set(X, y, max_size, rng=42):
    if len(X) <= max_size:
        return X, y
    try:
        _, Xp, _, yp = train_test_split(X, y, test_size=max_size,
                                        random_state=rng, stratify=y)
        return Xp, yp
    except Exception:
        idx = np.random.default_rng(rng).choice(len(X), max_size, replace=False)
        return X[idx], y[idx]


def collect_soft_targets(client_models, X_pub, sizes, temperature):
    loader = DataLoader(torch.tensor(X_pub, dtype=torch.float32),
                        batch_size=BATCH_SIZE, shuffle=False)
    all_probs = []
    for model in client_models:
        model.eval()
        batches = []
        with torch.no_grad():
            for bx in loader:
                p = torch.softmax(model(bx.to(DEVICE)) / temperature, dim=1)
                batches.append(p.cpu().numpy())
        all_probs.append(np.vstack(batches))

    total = sum(sizes)
    soft  = sum(p * (s / total) for p, s in zip(all_probs, sizes))
    soft /= np.clip(soft.sum(axis=1, keepdims=True), 1e-12, None)
    return soft.astype(np.float32)


# =========================================================
# 7. ENTRAÎNEMENTS LOCAUX AVEC BARRE
# =========================================================
def train_local_ae(global_model, client_X, client_id: int):
    local = copy.deepcopy(global_model).to(DEVICE)
    local.train()
    loader    = make_ae_loader(client_X)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(local.parameters(), lr=LEARNING_RATE_AE)
    losses    = []

    bar = ProgressBar(len(loader) * LOCAL_EPOCHS_AE,
                      desc=f"  Client AE {client_id} ({len(client_X)} samples)",
                      unit="batch")

    for epoch in range(LOCAL_EPOCHS_AE):
        run = 0.0
        for bx, bt in loader:
            bx, bt = bx.to(DEVICE), bt.to(DEVICE)
            optimizer.zero_grad()
            loss = criterion(local(bx), bt)
            if not torch.isnan(loss):
                loss.backward(); optimizer.step()
                run += loss.item() * bx.size(0)
            bar.update(1)
            bar.set_postfix(epoch=epoch + 1, loss=f"{loss.item():.5f}")
        losses.append(run / len(loader.dataset))

    bar.close()
    return local.state_dict(), len(client_X), float(np.mean(losses))


def train_local_mlp(global_model, client_X, client_y, client_id: int):
    local = copy.deepcopy(global_model).to(DEVICE)
    local.train()
    loader = make_supervised_loader(client_X, client_y)

    cc     = np.bincount(client_y, minlength=2)
    total  = cc.sum()
    wts    = torch.tensor(total / (2.0 * np.maximum(cc, 1)),
                          dtype=torch.float32).to(DEVICE)

    criterion = nn.CrossEntropyLoss(weight=wts)
    optimizer = optim.Adam(local.parameters(), lr=LEARNING_RATE_MLP)
    losses    = []

    bar = ProgressBar(
        len(loader) * LOCAL_EPOCHS_MLP,
        desc=(f"  Client MLP {client_id} "
              f"(B={np.sum(client_y==0)}, A={np.sum(client_y==1)})"),
        unit="batch",
    )

    for epoch in range(LOCAL_EPOCHS_MLP):
        run = 0.0
        for bx, by in loader:
            bx, by = bx.to(DEVICE), by.to(DEVICE)
            optimizer.zero_grad()
            loss = criterion(local(bx), by)
            if not torch.isnan(loss):
                loss.backward(); optimizer.step()
                run += loss.item() * bx.size(0)
            bar.update(1)
            bar.set_postfix(epoch=epoch + 1, loss=f"{loss.item():.5f}")
        losses.append(run / len(loader.dataset))

    bar.close()
    return local.state_dict(), len(client_X), float(np.mean(losses))


def distill_global_mlp(global_model, X_pub, y_pub, soft_targets):
    model = copy.deepcopy(global_model).to(DEVICE)
    model.train()
    dataset = TensorDataset(
        torch.tensor(X_pub,        dtype=torch.float32),
        torch.tensor(y_pub,        dtype=torch.long),
        torch.tensor(soft_targets, dtype=torch.float32),
    )
    loader    = DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=True)
    ce_loss   = nn.CrossEntropyLoss()
    kl_loss   = nn.KLDivLoss(reduction="batchmean")
    optimizer = optim.Adam(model.parameters(), lr=LEARNING_RATE_MLP)
    losses    = []

    bar = ProgressBar(len(loader) * DISTILL_EPOCHS,
                      desc="  [Distillation serveur]", unit="batch")

    for epoch in range(DISTILL_EPOCHS):
        run = 0.0
        for bx, by, bs in loader:
            bx, by, bs = bx.to(DEVICE), by.to(DEVICE), bs.to(DEVICE)
            optimizer.zero_grad()
            logits  = model(bx)
            l_ce    = ce_loss(logits, by)
            l_kd    = kl_loss(torch.log_softmax(logits / DISTILL_TEMPERATURE, dim=1), bs) \
                      * (DISTILL_TEMPERATURE ** 2)
            loss    = (1 - DISTILL_ALPHA) * l_ce + DISTILL_ALPHA * l_kd
            if not torch.isnan(loss):
                loss.backward(); optimizer.step()
                run += loss.item() * bx.size(0)
            bar.update(1)
            bar.set_postfix(epoch=epoch + 1, loss=f"{loss.item():.5f}")
        losses.append(run / len(loader.dataset))

    bar.close()
    return model.state_dict(), float(np.mean(losses))


# =========================================================
# 8. FEATURES AE / PRÉDICTION MLP
# =========================================================
def reconstruction_errors(model, X):
    model.eval()
    errs = []
    with torch.no_grad():
        for bx in DataLoader(torch.tensor(X, dtype=torch.float32),
                             batch_size=BATCH_SIZE, shuffle=False):
            bx = bx.to(DEVICE)
            errs.extend(torch.mean((bx - model(bx)) ** 2, dim=1).cpu().numpy())
    return np.array(errs)


def extract_ae_features(model, X):
    model.eval()
    zs, errs = [], []
    with torch.no_grad():
        for bx in DataLoader(torch.tensor(X, dtype=torch.float32),
                             batch_size=BATCH_SIZE, shuffle=False):
            bx  = bx.to(DEVICE)
            z   = model.encode(bx)
            err = torch.mean((bx - model(bx)) ** 2, dim=1, keepdim=True)
            zs.append(z.cpu().numpy())
            errs.append(err.cpu().numpy())
    z_all   = np.vstack(zs).astype(np.float32)
    err_all = np.vstack(errs).astype(np.float32)
    return np.hstack([z_all, err_all]) if USE_RECONSTRUCTION_ERROR_AS_FEATURE else z_all


def predict_mlp(model, X):
    model.eval()
    preds, probs_list = [], []
    softmax = nn.Softmax(dim=1)
    with torch.no_grad():
        for bx in DataLoader(torch.tensor(X, dtype=torch.float32),
                             batch_size=BATCH_SIZE, shuffle=False):
            bx = bx.to(DEVICE)
            p  = softmax(model(bx))
            preds.extend(torch.argmax(p, dim=1).cpu().numpy())
            probs_list.append(p.cpu().numpy())
    return np.array(preds), np.vstack(probs_list)


# =========================================================
# 9. ÉVALUATION
# =========================================================
def evaluate(name, y_true, y_pred, scores=None):
    acc  = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec  = recall_score(y_true, y_pred, zero_division=0)
    f1   = f1_score(y_true, y_pred, zero_division=0)

    cm             = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()
    fpr  = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    fnr  = fn / (fn + tp) if (fn + tp) > 0 else 0.0
    spec = tn / (tn + fp) if (tn + fp) > 0 else 0.0

    try:
        auc = roc_auc_score(y_true, scores) if scores is not None else np.nan
    except Exception:
        auc = np.nan

    print(f"\n{'='*57}")
    print(f"  RÉSULTATS — {name}")
    print(f"{'='*57}")
    print(f"  Accuracy              : {acc:.4f}")
    print(f"  Precision             : {prec:.4f}")
    print(f"  Recall / Detection    : {rec:.4f}")
    print(f"  F1-score              : {f1:.4f}")
    print(f"  Specificity           : {spec:.4f}")
    print(f"  False Positive Rate   : {fpr:.4f}")
    print(f"  False Negative Rate   : {fnr:.4f}")
    auc_str = f"{auc:.4f}" if not np.isnan(auc) else "N/A"
    print(f"  ROC-AUC               : {auc_str}")
    print("\n  Matrice de confusion :")
    print(cm)
    print("\n  Classification report :")
    print(classification_report(y_true, y_pred,
                                target_names=["Legitimate", "Attack"],
                                digits=4, zero_division=0))
    return {
        "accuracy": acc, "precision": prec, "recall": rec, "f1_score": f1,
        "specificity": spec, "fpr": fpr, "fnr": fnr, "roc_auc": auc,
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
    }


# =========================================================
# 10. CHARGEMENT DES DONNÉES
# =========================================================
print("\n" + "="*57)
print("  ÉTAPE 1 — Chargement CSV")
print("="*57)

train_df = pd.read_csv(TRAIN_PATH, low_memory=False)
test_df  = pd.read_csv(TEST_PATH,  low_memory=False)
train_df.columns = train_df.columns.str.strip()
test_df.columns  = test_df.columns.str.strip()

print(f"Train brut : {train_df.shape}  |  Test brut : {test_df.shape}")
print("\nDistribution train :")
print(train_df[LABEL_COL].value_counts())
print("\nDistribution test :")
print(test_df[LABEL_COL].value_counts())

X_train_df, X_test_df, y_train, y_test = prepare_mqtt(train_df, test_df)
feature_columns = list(X_train_df.columns)

print(f"\nTrain : {X_train_df.shape}  |  Test : {X_test_df.shape}")
print(f"Features retenues : {len(feature_columns)}")
print(f"\nTrain — benign={np.sum(y_train==0)} | attack={np.sum(y_train==1)}")
print(f"Test  — benign={np.sum(y_test==0)}  | attack={np.sum(y_test==1)}")


# =========================================================
# 11. SCALING GLOBAL
# =========================================================
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_df).astype(np.float32)
X_test_scaled  = scaler.transform(X_test_df).astype(np.float32)
print("\nScaling terminé.")


# =========================================================
# 12. BENIGN SEUL → ENTRAÎNER L'AE
# =========================================================
print("\n" + "="*57)
print("  ÉTAPE 2 — Isolation du trafic légitime pour l'AE")
print("="*57)

benign_mask   = (y_train == 0)
X_benign_all  = X_train_scaled[benign_mask]
print(f"Samples benign disponibles : {len(X_benign_all)}")

X_ae_train, X_ae_val = train_test_split(
    X_benign_all, test_size=VALID_SIZE_AE, random_state=RANDOM_STATE
)
print(f"AE train : {X_ae_train.shape}  |  AE val : {X_ae_val.shape}")

clients_ae = split_clients_unsupervised(X_ae_train, NUM_CLIENTS, CLIENT_DATA_PROPORTIONS)
print("\n===== Clients AE =====")
for i, cx in enumerate(clients_ae):
    print(f"  Client {i+1} : {cx.shape}")


# =========================================================
# 13. ENTRAÎNEMENT AE FEDAVG (benign only)
# =========================================================
print("\n" + "="*57)
print("  ÉTAPE 3 — Entraînement AE FedAvg (benign only)")
print("="*57)

input_dim = X_train_scaled.shape[1]
ae_model  = Autoencoder(input_dim).to(DEVICE)

best_ae_val_loss = float("inf")
best_ae_path     = os.path.join(SAVE_FOLDER, "best_feddistill_autoencoder.pth")

for rnd in range(GLOBAL_ROUNDS):
    print(f"\n{'─'*50}")
    print(f"  Round AE {rnd+1}/{GLOBAL_ROUNDS}")
    print(f"{'─'*50}")

    lw, ls, ll = [], [], []
    for i, cx in enumerate(clients_ae):
        w, size, loss = train_local_ae(ae_model, cx, client_id=i + 1)
        lw.append(w); ls.append(size); ll.append(loss)
        print(f"  → Client {i+1} terminé | size={size} | loss={loss:.6f}")

    ae_model.load_state_dict(weighted_fedavg(lw, ls))

    val_loss = float(np.mean(reconstruction_errors(ae_model, X_ae_val)))
    print(f"\n  [Round {rnd+1}] Val loss AE : {val_loss:.6f}  (best={best_ae_val_loss:.6f})")

    if val_loss < best_ae_val_loss:
        best_ae_val_loss = val_loss
        torch.save(ae_model.state_dict(), best_ae_path)
        print("  >> ✓ Meilleur AE sauvegardé.")

best_ae = Autoencoder(input_dim).to(DEVICE)
best_ae.load_state_dict(torch.load(best_ae_path, map_location=DEVICE))
best_ae.eval()
print(f"\nMeilleure val loss AE : {best_ae_val_loss:.6f}")


# =========================================================
# 14. EXTRACTION FEATURES AE (latent + erreur)
# =========================================================
print("\n" + "="*57)
print("  ÉTAPE 4 — Extraction features AE")
print("="*57)

X_train_mlp = extract_ae_features(best_ae, X_train_scaled)
X_test_mlp  = extract_ae_features(best_ae, X_test_scaled)

mlp_feature_scaler = StandardScaler()
X_train_mlp = mlp_feature_scaler.fit_transform(X_train_mlp).astype(np.float32)
X_test_mlp  = mlp_feature_scaler.transform(X_test_mlp).astype(np.float32)

print(f"X_train_mlp : {X_train_mlp.shape}")
print(f"X_test_mlp  : {X_test_mlp.shape}")


# =========================================================
# 15. CLIENTS MLP + JEU PUBLIC DISTILL
# =========================================================
clients_mlp = split_clients_supervised(
    X_train_mlp, y_train, NUM_CLIENTS, CLIENT_DATA_PROPORTIONS
)
print("\n===== Clients MLP =====")
for i, (cx, cy) in enumerate(clients_mlp):
    print(f"  Client {i+1} : X={cx.shape} | benign={np.sum(cy==0)} | attack={np.sum(cy==1)}")

X_pub, y_pub = sample_public_set(
    X_test_mlp, y_test, max_size=PUBLIC_DISTILL_SIZE, rng=RANDOM_STATE
)
print(f"\nJeu public distill : {X_pub.shape} | benign={np.sum(y_pub==0)} | attack={np.sum(y_pub==1)}")


# =========================================================
# 16. ENTRAÎNEMENT FEDDISTILL + MLP
# =========================================================
print("\n" + "="*57)
print("  ÉTAPE 5 — FedDistill + MLP")
print("="*57)

mlp_dim    = X_train_mlp.shape[1]
global_mlp = MLPBinaryClassifier(mlp_dim).to(DEVICE)

best_mlp_f1   = -1.0
best_mlp_path = os.path.join(SAVE_FOLDER, "best_feddistill_mlp_binary.pth")

for rnd in range(GLOBAL_ROUNDS):
    print(f"\n{'─'*50}")
    print(f"  Round FedDistill MLP {rnd+1}/{GLOBAL_ROUNDS}")
    print(f"{'─'*50}")

    local_models, lw, ls, ll = [], [], [], []

    # --- Entraînement local de chaque client ---
    for i, (cx, cy) in enumerate(clients_mlp):
        w, size, loss = train_local_mlp(global_mlp, cx, cy, client_id=i + 1)
        cm_i = MLPBinaryClassifier(mlp_dim).to(DEVICE)
        cm_i.load_state_dict(w); cm_i.eval()
        local_models.append(cm_i)
        lw.append(w); ls.append(size); ll.append(loss)
        print(f"  → Client {i+1} terminé | size={size} | loss={loss:.6f}")

    # --- Soft labels + distillation ---
    print(f"\n  Collecte soft labels sur le jeu public…")
    soft = collect_soft_targets(local_models, X_pub, ls, DISTILL_TEMPERATURE)

    print(f"  Distillation du modèle global…")
    dw, dloss = distill_global_mlp(global_mlp, X_pub, y_pub, soft)
    global_mlp.load_state_dict(dw)

    # --- Validation ---
    val_pred, val_probs = predict_mlp(global_mlp, X_test_mlp)
    val_f1  = f1_score(y_test, val_pred, zero_division=0)
    val_acc = accuracy_score(y_test, val_pred)

    print(f"\n  [Round {rnd+1}] Loss clients={np.mean(ll):.5f} | Distill={dloss:.5f}")
    print(f"  [Round {rnd+1}] Val Acc={val_acc:.4f} | Val F1={val_f1:.4f}  (best={best_mlp_f1:.4f})")

    if val_f1 > best_mlp_f1:
        best_mlp_f1 = val_f1
        torch.save(global_mlp.state_dict(), best_mlp_path)
        print("  >> ✓ Meilleur MLP sauvegardé.")

best_mlp = MLPBinaryClassifier(mlp_dim).to(DEVICE)
best_mlp.load_state_dict(torch.load(best_mlp_path, map_location=DEVICE))
best_mlp.eval()
print(f"\nMeilleur Val F1 MLP : {best_mlp_f1:.4f}")


# =========================================================
# 17. ÉVALUATION FINALE
# =========================================================
print("\n" + "="*57)
print("  ÉTAPE 6 — Évaluation finale sur Test Set")
print("="*57)

test_pred, test_probs = predict_mlp(best_mlp, X_test_mlp)
test_scores = test_probs[:, 1]

test_results = evaluate(
    "FedDistill AE → MLP  (MQTT Dataset)",
    y_test, test_pred, scores=test_scores
)


# =========================================================
# 18. SAUVEGARDE
# =========================================================
print("\n" + "="*57)
print("  ÉTAPE 7 — Sauvegarde des artefacts")
print("="*57)

torch.save(best_ae.state_dict(),  os.path.join(SAVE_FOLDER, "feddistill_autoencoder_final.pth"))
torch.save(best_mlp.state_dict(), os.path.join(SAVE_FOLDER, "feddistill_mlp_binary_final.pth"))

joblib.dump(scaler,             os.path.join(SAVE_FOLDER, "scaler_mqtt.pkl"))
joblib.dump(mlp_feature_scaler, os.path.join(SAVE_FOLDER, "mlp_feature_scaler_mqtt.pkl"))
joblib.dump(feature_columns,    os.path.join(SAVE_FOLDER, "feature_columns_mqtt.pkl"))

metadata = {
    "architecture"              : "FedDistill + AE + MLP sur MQTT Dataset",
    "num_clients"               : NUM_CLIENTS,
    "client_data_proportions"   : CLIENT_DATA_PROPORTIONS,
    "global_rounds"             : GLOBAL_ROUNDS,
    "local_epochs_ae"           : LOCAL_EPOCHS_AE,
    "local_epochs_mlp"          : LOCAL_EPOCHS_MLP,
    "public_distill_size"       : PUBLIC_DISTILL_SIZE,
    "distill_epochs"            : DISTILL_EPOCHS,
    "distill_temperature"       : DISTILL_TEMPERATURE,
    "distill_alpha"             : DISTILL_ALPHA,
    "batch_size"                : BATCH_SIZE,
    "learning_rate_ae"          : LEARNING_RATE_AE,
    "learning_rate_mlp"         : LEARNING_RATE_MLP,
    "best_ae_val_loss"          : best_ae_val_loss,
    "best_mlp_val_f1"           : best_mlp_f1,
    "input_dim"                 : input_dim,
    "mlp_input_dim"             : mlp_dim,
    "use_reconstruction_error_as_feature": USE_RECONSTRUCTION_ERROR_AS_FEATURE,
}
joblib.dump(metadata,     os.path.join(SAVE_FOLDER, "metadata_mqtt.pkl"))
joblib.dump(test_results, os.path.join(SAVE_FOLDER, "metrics_mqtt.pkl"))

ae_err_test = X_test_mlp[:, -1] if USE_RECONSTRUCTION_ERROR_AS_FEATURE else np.zeros(len(X_test_mlp))

results_df = pd.DataFrame({
    "y_true"                  : y_test,
    "y_pred"                  : test_pred,
    "attack_score"            : test_scores,
    "ae_reconstruction_error" : ae_err_test,
})
results_df.to_csv(os.path.join(SAVE_FOLDER, "detailed_predictions_mqtt.csv"), index=False)

print("\nTous les artefacts sauvegardés dans :", SAVE_FOLDER)
print("  ├── feddistill_autoencoder_final.pth")
print("  ├── feddistill_mlp_binary_final.pth")
print("  ├── scaler_mqtt.pkl / mlp_feature_scaler_mqtt.pkl / feature_columns_mqtt.pkl")
print("  ├── metadata_mqtt.pkl / metrics_mqtt.pkl")
print("  └── detailed_predictions_mqtt.csv")
print("\n✓ Pipeline FedDistill AE → MLP sur MQTT Dataset terminé.")