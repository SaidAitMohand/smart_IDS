import os
import copy
import random
import joblib
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    confusion_matrix,
    classification_report,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    fbeta_score,
    roc_auc_score
)

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader

try:
    from tqdm.auto import tqdm
except Exception:
    tqdm = None


# =========================================================
# 1. PARAMETRES
# =========================================================
TRAIN_FILE = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/KDD2/KDDTrain+.txt"
TEST_FILE = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/KDD2/KDDTest+.txt"

SAVE_FOLDER = "C:/Users/anis/Desktop/M2_RMSE/Memoire/Tests/KDD/HFL_AE_MLP_AUTO_THRESHOLD_MLP_THRESHOLD"
os.makedirs(SAVE_FOLDER, exist_ok=True)

NUM_CLIENTS = 5
CLIENT_DATA_PROPORTIONS = [0.40, 0.25, 0.18, 0.12, 0.05]

NUM_EDGE_SERVERS = 2
CLIENT_EDGE_ASSIGNMENTS = [0, 0, 1, 1, 1]

GLOBAL_ROUNDS = 10
LOCAL_EPOCHS_AE = 20
LOCAL_EPOCHS_MLP = 20

BATCH_SIZE = 256
LEARNING_RATE_AE = 1e-3
LEARNING_RATE_MLP = 1e-3

VALID_SIZE = 0.2
RANDOM_STATE = 42

AUTO_THRESHOLD_PERCENTILES = np.concatenate([
    np.arange(80.0, 99.0, 0.5),
    np.arange(99.0, 99.95, 0.05)
])

# Objectif du seuil MLP : "f2" favorise le recall, donc moins de FN.
MLP_THRESHOLD_METRIC = "f2"
MLP_THRESHOLD_GRID = np.arange(0.05, 0.96, 0.01)

USE_RECONSTRUCTION_ERROR_AS_FEATURE = True
USE_AE_DECISION_AS_MLP_FEATURE = True

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device utilise :", DEVICE)

random.seed(RANDOM_STATE)
np.random.seed(RANDOM_STATE)
torch.manual_seed(RANDOM_STATE)


def progress(iterable, **kwargs):
    if tqdm is None:
        return iterable
    kwargs.setdefault("dynamic_ncols", True)
    return tqdm(iterable, **kwargs)


def validate_hfl_config():
    if len(CLIENT_DATA_PROPORTIONS) != NUM_CLIENTS:
        raise ValueError("CLIENT_DATA_PROPORTIONS doit avoir la meme longueur que NUM_CLIENTS.")
    if not np.isclose(sum(CLIENT_DATA_PROPORTIONS), 1.0):
        raise ValueError("La somme de CLIENT_DATA_PROPORTIONS doit etre egale a 1.0.")
    if len(CLIENT_EDGE_ASSIGNMENTS) != NUM_CLIENTS:
        raise ValueError("CLIENT_EDGE_ASSIGNMENTS doit avoir la meme longueur que NUM_CLIENTS.")
    if min(CLIENT_EDGE_ASSIGNMENTS) < 0 or max(CLIENT_EDGE_ASSIGNMENTS) >= NUM_EDGE_SERVERS:
        raise ValueError("Chaque edge id doit etre entre 0 et NUM_EDGE_SERVERS - 1.")


validate_hfl_config()


# =========================================================
# 2. COLONNES NSL-KDD
# =========================================================
KDD_COLUMNS = [
    "duration", "protocol_type", "service", "flag", "src_bytes", "dst_bytes",
    "land", "wrong_fragment", "urgent", "hot", "num_failed_logins",
    "logged_in", "num_compromised", "root_shell", "su_attempted",
    "num_root", "num_file_creations", "num_shells", "num_access_files",
    "num_outbound_cmds", "is_host_login", "is_guest_login", "count",
    "srv_count", "serror_rate", "srv_serror_rate", "rerror_rate",
    "srv_rerror_rate", "same_srv_rate", "diff_srv_rate",
    "srv_diff_host_rate", "dst_host_count", "dst_host_srv_count",
    "dst_host_same_srv_rate", "dst_host_diff_srv_rate",
    "dst_host_same_src_port_rate", "dst_host_srv_diff_host_rate",
    "dst_host_serror_rate", "dst_host_srv_serror_rate",
    "dst_host_rerror_rate", "dst_host_srv_rerror_rate", "label", "difficulty"
]


# =========================================================
# 3. PRETRAITEMENT
# =========================================================
def encode_kdd_dataframe(df, feature_columns=None, scaler=None, fit=False):
    df = df.copy()
    df.columns = df.columns.str.strip()
    df["label"] = df["label"].astype(str).str.strip()

    y = df["label"].apply(lambda x: 0 if x == "normal" else 1).astype(np.int64).values
    original_labels = df["label"].copy().values

    df = df.drop(columns=["label", "difficulty"])
    df = pd.get_dummies(df, columns=["protocol_type", "service", "flag"])

    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.dropna(axis=1, how="all")
    df = df.fillna(df.median(numeric_only=True)).fillna(0)

    if fit:
        constant_cols = [col for col in df.columns if df[col].nunique() <= 1]
        if constant_cols:
            df = df.drop(columns=constant_cols)
            print("Colonnes constantes supprimees :", len(constant_cols))

        feature_columns = list(df.columns)
        scaler = StandardScaler()
        X = scaler.fit_transform(df).astype(np.float32)
    else:
        missing_cols = [col for col in feature_columns if col not in df.columns]
        extra_cols = [col for col in df.columns if col not in feature_columns]
        df = df.reindex(columns=feature_columns, fill_value=0)

        print("\n===== ALIGNEMENT DATA =====")
        print("Shape apres alignement :", df.shape)
        print("Colonnes manquantes ajoutees :", len(missing_cols))
        print("Colonnes extra ignorees      :", len(extra_cols))

        X = scaler.transform(df).astype(np.float32)

    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    return X, y, original_labels, feature_columns, scaler


def load_train_all_classes(file_path):
    df = pd.read_csv(file_path, names=KDD_COLUMNS)
    df.columns = df.columns.str.strip()
    df["label"] = df["label"].astype(str).str.strip()

    print("\n===== TRAIN BRUT =====")
    print("Shape train brut :", df.shape)
    print("Repartition initiale des labels :")
    print(df["label"].value_counts().head(15))

    X, y, labels, feature_columns, scaler = encode_kdd_dataframe(df, fit=True)

    print("\n===== TRAIN APRES PRETRAITEMENT =====")
    print("Shape X :", X.shape)
    print("Nombre de features :", len(feature_columns))
    print("Normaux train  :", np.sum(y == 0))
    print("Attaques train :", np.sum(y == 1))
    return X, y, labels, feature_columns, scaler


def load_test_all_classes(file_path, feature_columns, scaler):
    df = pd.read_csv(file_path, names=KDD_COLUMNS)
    df.columns = df.columns.str.strip()
    df["label"] = df["label"].astype(str).str.strip()

    print("\n===== TEST BRUT =====")
    print("Shape test brut :", df.shape)
    print("Repartition initiale des labels :")
    print(df["label"].value_counts().head(15))

    X, y, labels, _, _ = encode_kdd_dataframe(
        df,
        feature_columns=feature_columns,
        scaler=scaler,
        fit=False
    )
    return X, y, labels


# =========================================================
# 4. MODELES
# =========================================================
class KDDAutoencoder(nn.Module):
    def __init__(self, input_dim):
        super(KDDAutoencoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 16),
            nn.ReLU()
        )
        self.decoder = nn.Sequential(
            nn.Linear(16, 64),
            nn.ReLU(),
            nn.Linear(64, 128),
            nn.ReLU(),
            nn.Linear(128, input_dim)
        )

    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z)

    def encode(self, x):
        return self.encoder(x)


class MLPClassifier(nn.Module):
    def __init__(self, input_dim):
        super(MLPClassifier, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.BatchNorm1d(128),
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.BatchNorm1d(64),
            nn.Dropout(0.3),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 2)
        )

    def forward(self, x):
        return self.net(x)


# =========================================================
# 5. OUTILS HFL
# =========================================================
def split_indices_by_proportions(n_samples, proportions):
    indices = np.random.permutation(n_samples)
    sizes = [int(p * n_samples) for p in proportions]
    sizes[0] += n_samples - sum(sizes)

    splits = []
    start = 0
    for size in sizes:
        end = start + size
        splits.append(indices[start:end])
        start = end
    return splits, sizes


def split_clients_supervised(X, y):
    index_splits, sizes = split_indices_by_proportions(len(X), CLIENT_DATA_PROPORTIONS)
    clients = [(X[idx], y[idx]) for idx in index_splits]

    print("\n===== REPARTITION NON EQUITABLE SUPERVISEE =====")
    for i, ((client_X, client_y), size) in enumerate(zip(clients, sizes)):
        edge_id = CLIENT_EDGE_ASSIGNMENTS[i]
        print(f"Client {i + 1} -> Edge {edge_id + 1}: {size} echantillons ({size / len(X):.2%})")
        print(pd.Series(client_y).value_counts().sort_index())

    return clients


def make_ae_loader(X, shuffle=True):
    X_tensor = torch.tensor(X, dtype=torch.float32)
    dataset = TensorDataset(X_tensor, X_tensor)
    return DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=shuffle)


def make_supervised_loader(X, y, shuffle=True):
    X_tensor = torch.tensor(X, dtype=torch.float32)
    y_tensor = torch.tensor(y, dtype=torch.long)
    dataset = TensorDataset(X_tensor, y_tensor)
    return DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=shuffle)


def fedavg_state_dicts(state_dicts, sizes):
    total_size = sum(sizes)
    if total_size == 0:
        raise ValueError("Impossible d'agreger avec total_size = 0.")

    avg_weights = copy.deepcopy(state_dicts[0])
    for key in avg_weights.keys():
        if not torch.is_floating_point(avg_weights[key]):
            avg_weights[key] = state_dicts[0][key]
            continue

        avg_weights[key] = torch.zeros_like(avg_weights[key])
        for weights, size in zip(state_dicts, sizes):
            avg_weights[key] += weights[key] * (size / total_size)
    return avg_weights


def hfl_aggregate(local_weights, local_sizes, model_name="model"):
    print(f"\n===== AGREGATION HFL : {model_name} =====")

    edge_weights = []
    edge_sizes = []

    for edge_id in range(NUM_EDGE_SERVERS):
        client_ids = [
            i for i, assigned_edge in enumerate(CLIENT_EDGE_ASSIGNMENTS)
            if assigned_edge == edge_id and local_sizes[i] > 0
        ]

        if not client_ids:
            print(f"Edge {edge_id + 1}: aucun client actif.")
            continue

        edge_state = fedavg_state_dicts(
            [local_weights[i] for i in client_ids],
            [local_sizes[i] for i in client_ids]
        )
        edge_size = sum(local_sizes[i] for i in client_ids)

        edge_weights.append(edge_state)
        edge_sizes.append(edge_size)

        print(f"Edge {edge_id + 1}: clients={[i + 1 for i in client_ids]} | total_size={edge_size}")

    global_state = fedavg_state_dicts(edge_weights, edge_sizes)
    print("Serveur central: tailles edges =", edge_sizes)
    return global_state


# =========================================================
# 6. ENTRAINEMENT AE + DETECTION
# =========================================================
def train_local_ae(global_model, client_X_normal, client_idx):
    local_model = copy.deepcopy(global_model).to(DEVICE)
    local_model.train()

    loader = make_ae_loader(client_X_normal, shuffle=True)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(local_model.parameters(), lr=LEARNING_RATE_AE)

    losses = []
    for epoch_idx in range(LOCAL_EPOCHS_AE):
        running_loss = 0.0
        iterator = progress(
            loader,
            desc=f"AE Client {client_idx + 1} E{epoch_idx + 1}/{LOCAL_EPOCHS_AE}",
            leave=False
        )

        for batch_x, batch_target in iterator:
            batch_x = batch_x.to(DEVICE)
            batch_target = batch_target.to(DEVICE)

            optimizer.zero_grad()
            outputs = local_model(batch_x)
            loss = criterion(outputs, batch_target)

            if torch.isnan(loss):
                continue

            loss.backward()
            optimizer.step()
            running_loss += loss.item() * batch_x.size(0)

            if tqdm is not None:
                iterator.set_postfix(loss=f"{loss.item():.4f}")

        losses.append(running_loss / len(loader.dataset))

    return local_model.state_dict(), len(client_X_normal), float(np.mean(losses))


def compute_reconstruction_errors(model, X):
    model.eval()
    loader = DataLoader(
        torch.tensor(X, dtype=torch.float32),
        batch_size=BATCH_SIZE,
        shuffle=False
    )

    errors = []
    with torch.no_grad():
        for batch_x in loader:
            batch_x = batch_x.to(DEVICE)
            outputs = model(batch_x)
            batch_errors = torch.mean((batch_x - outputs) ** 2, dim=1)
            errors.extend(batch_errors.cpu().numpy())

    return np.array(errors, dtype=np.float32)


def choose_auto_threshold_percentile(normal_reference_errors, validation_errors, validation_y):
    best = {
        "percentile": None,
        "threshold": None,
        "accuracy": -1.0,
        "precision": 0.0,
        "recall": 0.0,
        "f1": -1.0,
        "fpr": 1.0
    }

    for percentile in AUTO_THRESHOLD_PERCENTILES:
        threshold = float(np.percentile(normal_reference_errors, percentile))
        pred = (validation_errors > threshold).astype(np.int64)

        acc = accuracy_score(validation_y, pred)
        prec = precision_score(validation_y, pred, zero_division=0)
        rec = recall_score(validation_y, pred, zero_division=0)
        f1 = f1_score(validation_y, pred, zero_division=0)
        cm = confusion_matrix(validation_y, pred, labels=[0, 1])
        tn, fp, fn, tp = cm.ravel()
        fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0

        better = f1 > best["f1"]
        same_f1_better_fpr = np.isclose(f1, best["f1"]) and fpr < best["fpr"]
        if better or same_f1_better_fpr:
            best = {
                "percentile": float(percentile),
                "threshold": threshold,
                "accuracy": float(acc),
                "precision": float(prec),
                "recall": float(rec),
                "f1": float(f1),
                "fpr": float(fpr)
            }

    return best


def extract_ae_features_and_detection(model, X, threshold, normal_error_std):
    model.eval()
    loader = DataLoader(
        torch.tensor(X, dtype=torch.float32),
        batch_size=BATCH_SIZE,
        shuffle=False
    )

    all_z = []
    all_errors = []

    with torch.no_grad():
        for batch_x in loader:
            batch_x = batch_x.to(DEVICE)
            z = model.encode(batch_x)
            x_hat = model(batch_x)
            err = torch.mean((batch_x - x_hat) ** 2, dim=1, keepdim=True)
            all_z.append(z.cpu().numpy())
            all_errors.append(err.cpu().numpy())

    z_all = np.vstack(all_z).astype(np.float32)
    err_all = np.vstack(all_errors).astype(np.float32)

    features = [z_all]
    if USE_RECONSTRUCTION_ERROR_AS_FEATURE:
        features.append(err_all)

    ae_pred = (err_all > threshold).astype(np.float32)
    ae_score = ((err_all - threshold) / max(normal_error_std, 1e-12)).astype(np.float32)

    if USE_AE_DECISION_AS_MLP_FEATURE:
        features.extend([ae_pred, ae_score])

    X_mlp = np.hstack(features).astype(np.float32)
    return X_mlp, err_all.ravel(), ae_pred.ravel().astype(np.int64), ae_score.ravel()


# =========================================================
# 7. ENTRAINEMENT LOCAL MLP
# =========================================================
def train_local_mlp(global_model, client_X, client_y, client_idx):
    local_model = copy.deepcopy(global_model).to(DEVICE)
    local_model.train()

    loader = make_supervised_loader(client_X, client_y, shuffle=True)

    class_counts = np.bincount(client_y, minlength=2)
    total = class_counts.sum()
    weights = total / (2.0 * np.maximum(class_counts, 1))
    weights = torch.tensor(weights, dtype=torch.float32).to(DEVICE)

    criterion = nn.CrossEntropyLoss(weight=weights)
    optimizer = optim.Adam(local_model.parameters(), lr=LEARNING_RATE_MLP)

    losses = []
    for epoch_idx in range(LOCAL_EPOCHS_MLP):
        running_loss = 0.0
        iterator = progress(
            loader,
            desc=f"MLP Client {client_idx + 1} E{epoch_idx + 1}/{LOCAL_EPOCHS_MLP}",
            leave=False
        )

        for batch_x, batch_y in iterator:
            batch_x = batch_x.to(DEVICE)
            batch_y = batch_y.to(DEVICE)

            optimizer.zero_grad()
            logits = local_model(batch_x)
            loss = criterion(logits, batch_y)

            if torch.isnan(loss):
                continue

            loss.backward()
            optimizer.step()
            running_loss += loss.item() * batch_x.size(0)

            if tqdm is not None:
                iterator.set_postfix(loss=f"{loss.item():.4f}")

        losses.append(running_loss / len(loader.dataset))

    return local_model.state_dict(), len(client_X), float(np.mean(losses))


def predict_mlp(model, X):
    model.eval()
    loader = DataLoader(
        torch.tensor(X, dtype=torch.float32),
        batch_size=BATCH_SIZE,
        shuffle=False
    )

    probs = []
    preds = []
    softmax = nn.Softmax(dim=1)

    with torch.no_grad():
        for batch_x in loader:
            batch_x = batch_x.to(DEVICE)
            logits = model(batch_x)
            p = softmax(logits)[:, 1]
            y = torch.argmax(logits, dim=1)
            probs.extend(p.cpu().numpy())
            preds.extend(y.cpu().numpy())

    return np.array(preds), np.array(probs)


def choose_mlp_decision_threshold(y_true, scores):
    best = {
        "threshold": 0.5,
        "accuracy": 0.0,
        "precision": 0.0,
        "recall": 0.0,
        "f1": 0.0,
        "f2": 0.0,
        "fpr": 1.0
    }

    for threshold in MLP_THRESHOLD_GRID:
        pred = (scores >= threshold).astype(np.int64)

        acc = accuracy_score(y_true, pred)
        prec = precision_score(y_true, pred, zero_division=0)
        rec = recall_score(y_true, pred, zero_division=0)
        f1 = f1_score(y_true, pred, zero_division=0)
        f2 = fbeta_score(y_true, pred, beta=2, zero_division=0)
        tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
        fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0

        current_score = f2 if MLP_THRESHOLD_METRIC == "f2" else f1
        best_score = best["f2"] if MLP_THRESHOLD_METRIC == "f2" else best["f1"]

        better = current_score > best_score
        same_score_better_fpr = np.isclose(current_score, best_score) and fpr < best["fpr"]

        if better or same_score_better_fpr:
            best = {
                "threshold": float(threshold),
                "accuracy": float(acc),
                "precision": float(prec),
                "recall": float(rec),
                "f1": float(f1),
                "f2": float(f2),
                "fpr": float(fpr)
            }

    return best


# =========================================================
# 8. CHARGEMENT DATASET
# =========================================================
print("\nChargement et preparation du train...")
X_all, y_all, train_original_labels, feature_columns, scaler = load_train_all_classes(TRAIN_FILE)

X_train_full, X_val_full, y_train_full, y_val_full = train_test_split(
    X_all,
    y_all,
    test_size=VALID_SIZE,
    random_state=RANDOM_STATE,
    stratify=y_all
)

print("\n===== SPLIT TRAIN/VALIDATION =====")
print("Train shape      :", X_train_full.shape)
print("Validation shape :", X_val_full.shape)
print("Train normaux    :", np.sum(y_train_full == 0))
print("Train attaques   :", np.sum(y_train_full == 1))
print("Val normaux      :", np.sum(y_val_full == 0))
print("Val attaques     :", np.sum(y_val_full == 1))

print("\n===== CONFIGURATION HFL =====")
print("NUM_CLIENTS :", NUM_CLIENTS)
print("NUM_EDGE_SERVERS :", NUM_EDGE_SERVERS)
print("CLIENT_EDGE_ASSIGNMENTS :", CLIENT_EDGE_ASSIGNMENTS)
print("CLIENT_DATA_PROPORTIONS :", CLIENT_DATA_PROPORTIONS)


# =========================================================
# 9. HFL + AE SUR TRAFIC NORMAL
# =========================================================
X_train_normal = X_train_full[y_train_full == 0]
X_val_normal = X_val_full[y_val_full == 0]

if len(X_train_normal) == 0:
    raise ValueError("Aucune donnee normale detectee dans le train.")
if len(X_val_normal) == 0:
    raise ValueError("Aucune donnee normale detectee dans la validation.")

normal_index_splits, normal_client_sizes = split_indices_by_proportions(
    len(X_train_normal),
    CLIENT_DATA_PROPORTIONS
)
clients_normal = [X_train_normal[idx] for idx in normal_index_splits]

print("\n===== CLIENTS AE NORMAL ONLY - HFL =====")
for i, client_X in enumerate(clients_normal):
    print(
        f"Client AE {i + 1} -> Edge {CLIENT_EDGE_ASSIGNMENTS[i] + 1}: "
        f"X={client_X.shape} ({len(client_X) / len(X_train_normal):.2%})"
    )

input_dim = X_train_full.shape[1]
global_ae = KDDAutoencoder(input_dim).to(DEVICE)

best_ae_val_loss = float("inf")
best_ae_path = os.path.join(SAVE_FOLDER, "best_hfl_autoencoder_auto_threshold.pth")

print("\n===== DEBUT ENTRAINEMENT HFL + AE =====")

for round_idx in range(GLOBAL_ROUNDS):
    local_weights = []
    local_sizes = []
    local_losses = []

    print(f"\n--- Round AE HFL {round_idx + 1}/{GLOBAL_ROUNDS} ---")

    for client_idx, client_X in enumerate(clients_normal):
        weights, size, loss = train_local_ae(global_ae, client_X, client_idx)
        local_weights.append(weights)
        local_sizes.append(size)
        local_losses.append(loss)
        print(
            f"Client {client_idx + 1} -> Edge {CLIENT_EDGE_ASSIGNMENTS[client_idx] + 1} "
            f"| size={size} | loss={loss:.6f}"
        )

    global_ae.load_state_dict(hfl_aggregate(local_weights, local_sizes, model_name="Autoencoder"))

    val_errors_normal = compute_reconstruction_errors(global_ae, X_val_normal)
    val_loss = float(np.mean(val_errors_normal))

    print(f"Loss moyenne clients AE       : {np.mean(local_losses):.6f}")
    print(f"Validation AE normal loss     : {val_loss:.6f}")

    if val_loss < best_ae_val_loss:
        best_ae_val_loss = val_loss
        torch.save(global_ae.state_dict(), best_ae_path)
        print(">> Meilleur AE HFL sauvegarde.")

best_ae = KDDAutoencoder(input_dim).to(DEVICE)
best_ae.load_state_dict(torch.load(best_ae_path, map_location=DEVICE))
best_ae.eval()


# =========================================================
# 10. SEUIL AUTOMATIQUE AE + FEATURES MLP
# =========================================================
print("\n===== CHOIX AUTOMATIQUE DU THRESHOLD_PERCENTILE AE =====")

train_normal_errors = compute_reconstruction_errors(best_ae, X_train_normal)
val_errors_all = compute_reconstruction_errors(best_ae, X_val_full)

ae_threshold_info = choose_auto_threshold_percentile(
    normal_reference_errors=train_normal_errors,
    validation_errors=val_errors_all,
    validation_y=y_val_full
)

AE_THRESHOLD_PERCENTILE = ae_threshold_info["percentile"]
AE_THRESHOLD = ae_threshold_info["threshold"]
AE_NORMAL_ERROR_STD = float(np.std(train_normal_errors))

print("threshold_percentile choisi :", AE_THRESHOLD_PERCENTILE)
print("threshold AE                :", AE_THRESHOLD)
print("Accuracy validation AE      :", ae_threshold_info["accuracy"])
print("Precision validation AE     :", ae_threshold_info["precision"])
print("Recall validation AE        :", ae_threshold_info["recall"])
print("F1 validation AE            :", ae_threshold_info["f1"])
print("FPR validation AE           :", ae_threshold_info["fpr"])

print("\n===== EXTRACTION FEATURES AE + DECISION AE POUR MLP =====")

X_train_mlp, train_errors, train_ae_pred, train_ae_score = extract_ae_features_and_detection(
    best_ae,
    X_train_full,
    threshold=AE_THRESHOLD,
    normal_error_std=AE_NORMAL_ERROR_STD
)
X_val_mlp, val_errors, val_ae_pred, val_ae_score = extract_ae_features_and_detection(
    best_ae,
    X_val_full,
    threshold=AE_THRESHOLD,
    normal_error_std=AE_NORMAL_ERROR_STD
)

print("\n===== PERFORMANCE DU PREMIER DETECTEUR AE =====")
print("Train AE F1 binaire :", f1_score(y_train_full, train_ae_pred, zero_division=0))
print("Val AE F1 binaire   :", f1_score(y_val_full, val_ae_pred, zero_division=0))
print("Val AE confusion    :")
print(confusion_matrix(y_val_full, val_ae_pred, labels=[0, 1]))

mlp_scaler = StandardScaler()
X_train_mlp = mlp_scaler.fit_transform(X_train_mlp).astype(np.float32)
X_val_mlp = mlp_scaler.transform(X_val_mlp).astype(np.float32)


# =========================================================
# 11. HFL + MLP CONFIRMATION/CLASSIFICATION
# =========================================================
clients_mlp = split_clients_supervised(X_train_mlp, y_train_full)

mlp_input_dim = X_train_mlp.shape[1]
global_mlp = MLPClassifier(mlp_input_dim).to(DEVICE)

best_val_f1 = -1.0
best_mlp_path = os.path.join(SAVE_FOLDER, "best_hfl_mlp_confirm_classifier.pth")

print("\n===== DEBUT ENTRAINEMENT HFL + MLP =====")

for round_idx in range(GLOBAL_ROUNDS):
    local_weights = []
    local_sizes = []
    local_losses = []

    print(f"\n--- Round MLP HFL {round_idx + 1}/{GLOBAL_ROUNDS} ---")

    for client_idx, (client_X, client_y) in enumerate(clients_mlp):
        weights, size, loss = train_local_mlp(global_mlp, client_X, client_y, client_idx)
        local_weights.append(weights)
        local_sizes.append(size)
        local_losses.append(loss)
        print(
            f"Client {client_idx + 1} -> Edge {CLIENT_EDGE_ASSIGNMENTS[client_idx] + 1} "
            f"| size={size} | loss={loss:.6f}"
        )

    global_mlp.load_state_dict(hfl_aggregate(local_weights, local_sizes, model_name="MLP"))

    val_pred_argmax, val_scores = predict_mlp(global_mlp, X_val_mlp)
    val_f1 = f1_score(y_val_full, val_pred_argmax, zero_division=0)
    val_rec = recall_score(y_val_full, val_pred_argmax, zero_division=0)
    val_acc = accuracy_score(y_val_full, val_pred_argmax)

    print(f"Loss moyenne clients MLP : {np.mean(local_losses):.6f}")
    print(f"Validation Accuracy argmax: {val_acc:.6f}")
    print(f"Validation F1 argmax      : {val_f1:.6f}")
    print(f"Validation Recall argmax  : {val_rec:.6f}")

    if val_f1 > best_val_f1:
        best_val_f1 = val_f1
        torch.save(global_mlp.state_dict(), best_mlp_path)
        print(">> Meilleur MLP HFL sauvegarde.")

best_mlp = MLPClassifier(mlp_input_dim).to(DEVICE)
best_mlp.load_state_dict(torch.load(best_mlp_path, map_location=DEVICE))
best_mlp.eval()


# =========================================================
# 12. SEUIL AUTOMATIQUE MLP SUR VALIDATION
# =========================================================
print("\n===== CHOIX AUTOMATIQUE DU SEUIL MLP =====")

val_pred_argmax, val_scores = predict_mlp(best_mlp, X_val_mlp)
mlp_threshold_info = choose_mlp_decision_threshold(y_val_full, val_scores)
MLP_DECISION_THRESHOLD = mlp_threshold_info["threshold"]

val_pred_threshold = (val_scores >= MLP_DECISION_THRESHOLD).astype(np.int64)

print("Metric seuil MLP choisie :", MLP_THRESHOLD_METRIC)
print("MLP decision threshold   :", MLP_DECISION_THRESHOLD)
print("Validation Accuracy      :", accuracy_score(y_val_full, val_pred_threshold))
print("Validation Precision     :", precision_score(y_val_full, val_pred_threshold, zero_division=0))
print("Validation Recall        :", recall_score(y_val_full, val_pred_threshold, zero_division=0))
print("Validation F1            :", f1_score(y_val_full, val_pred_threshold, zero_division=0))
print("Validation F2            :", fbeta_score(y_val_full, val_pred_threshold, beta=2, zero_division=0))
print("Validation confusion     :")
print(confusion_matrix(y_val_full, val_pred_threshold, labels=[0, 1]))


# =========================================================
# 13. TEST FINAL : AE DETECTE -> MLP CONFIRME AVEC SEUIL
# =========================================================
print("\nChargement et preparation du test...")
X_test, y_test, original_labels = load_test_all_classes(TEST_FILE, feature_columns, scaler)

X_test_mlp, test_errors, ae_pred, ae_score = extract_ae_features_and_detection(
    best_ae,
    X_test,
    threshold=AE_THRESHOLD,
    normal_error_std=AE_NORMAL_ERROR_STD
)
X_test_mlp = mlp_scaler.transform(X_test_mlp).astype(np.float32)

mlp_pred_argmax, scores_attack = predict_mlp(best_mlp, X_test_mlp)
y_pred = (scores_attack >= MLP_DECISION_THRESHOLD).astype(np.int64)

print("\n===== PIPELINE FINAL =====")
print("1) AE HFL detecte les attaques par seuil automatique.")
print("2) MLP HFL recoit les sorties AE et confirme avec un seuil MLP automatique.")

print("\n===== REPARTITION TEST =====")
print("Normaux reels              :", np.sum(y_test == 0))
print("Attaques reelles           :", np.sum(y_test == 1))
print("Normaux predits MLP seuil   :", np.sum(y_pred == 0))
print("Attaques pred. MLP seuil    :", np.sum(y_pred == 1))
print("Attaques detectees par AE seul :", np.sum(ae_pred == 1))
print("Attaques pred. MLP argmax   :", np.sum(mlp_pred_argmax == 1))


# =========================================================
# 14. METRIQUES TEST
# =========================================================
ae_acc = accuracy_score(y_test, ae_pred)
ae_prec = precision_score(y_test, ae_pred, zero_division=0)
ae_rec = recall_score(y_test, ae_pred, zero_division=0)
ae_f1 = f1_score(y_test, ae_pred, zero_division=0)
ae_cm = confusion_matrix(y_test, ae_pred, labels=[0, 1])

argmax_acc = accuracy_score(y_test, mlp_pred_argmax)
argmax_rec = recall_score(y_test, mlp_pred_argmax, zero_division=0)
argmax_f1 = f1_score(y_test, mlp_pred_argmax, zero_division=0)

acc = accuracy_score(y_test, y_pred)
prec = precision_score(y_test, y_pred, zero_division=0)
rec = recall_score(y_test, y_pred, zero_division=0)
f1 = f1_score(y_test, y_pred, zero_division=0)
f2 = fbeta_score(y_test, y_pred, beta=2, zero_division=0)

cm = confusion_matrix(y_test, y_pred, labels=[0, 1])
tn, fp, fn, tp = cm.ravel()

fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
fnr = fn / (fn + tp) if (fn + tp) > 0 else 0.0
specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0

try:
    roc_auc = roc_auc_score(y_test, scores_attack)
except Exception:
    roc_auc = np.nan

print("\n===== RESULTATS PREMIER DETECTEUR AE =====")
print("AE threshold_percentile :", AE_THRESHOLD_PERCENTILE)
print("AE threshold            :", AE_THRESHOLD)
print("Accuracy AE             :", ae_acc)
print("Precision AE            :", ae_prec)
print("Recall AE               :", ae_rec)
print("F1 AE                   :", ae_f1)
print("Matrice AE              :")
print(ae_cm)

print("\n===== COMPARAISON MLP ARGMAX VS SEUIL AUTO =====")
print("Argmax Accuracy :", argmax_acc)
print("Argmax Recall   :", argmax_rec)
print("Argmax F1       :", argmax_f1)
print("Seuil auto      :", MLP_DECISION_THRESHOLD)

print("\n===== RESULTATS TEST FINAL : HFL + AE -> MLP SEUIL AUTO =====")
print("Accuracy              :", acc)
print("Precision             :", prec)
print("Recall / DetectionRate:", rec)
print("F1-score              :", f1)
print("F2-score              :", f2)
print("Specificity           :", specificity)
print("False Positive Rate   :", fpr)
print("False Negative Rate   :", fnr)
print("ROC-AUC               :", roc_auc)

print("\n===== MATRICE DE CONFUSION MLP FINAL =====")
print(cm)

print("\n===== DETAILS MATRICE DE CONFUSION =====")
print("TN (normaux bien predits)    :", tn)
print("FP (normaux predits attaque) :", fp)
print("FN (attaques ratees)         :", fn)
print("TP (attaques detectees)      :", tp)

print("\n===== CLASSIFICATION REPORT =====")
print(classification_report(
    y_test,
    y_pred,
    target_names=["Normal", "Attack"],
    digits=4,
    zero_division=0
))

print("\n===== ERREURS DE RECONSTRUCTION TEST =====")
print(pd.Series(test_errors).describe())

print("\n===== SCORES AE TEST =====")
print(pd.Series(ae_score).describe())

print("\n===== SCORES MLP TEST =====")
print(pd.Series(scores_attack).describe())


# =========================================================
# 15. SAUVEGARDE
# =========================================================
results_df = pd.DataFrame({
    "label_original": original_labels,
    "y_true": y_test,
    "ae_pred": ae_pred,
    "mlp_pred_argmax": mlp_pred_argmax,
    "mlp_pred_threshold": y_pred,
    "reconstruction_error": test_errors,
    "ae_score": ae_score,
    "mlp_attack_score": scores_attack
})

results_path = os.path.join(SAVE_FOLDER, "results_test_hfl_ae_mlp_auto_threshold_kdd_mlp_threshold.csv")
results_df.to_csv(results_path, index=False)

metrics = {
    "ae_threshold_percentile": AE_THRESHOLD_PERCENTILE,
    "ae_threshold": AE_THRESHOLD,
    "ae_validation_metrics": ae_threshold_info,
    "mlp_decision_threshold": MLP_DECISION_THRESHOLD,
    "mlp_threshold_metric": MLP_THRESHOLD_METRIC,
    "mlp_validation_threshold_metrics": mlp_threshold_info,
    "ae_test_accuracy": ae_acc,
    "ae_test_precision": ae_prec,
    "ae_test_recall": ae_rec,
    "ae_test_f1": ae_f1,
    "argmax_accuracy": argmax_acc,
    "argmax_recall": argmax_rec,
    "argmax_f1": argmax_f1,
    "accuracy": acc,
    "precision": prec,
    "recall_detection_rate": rec,
    "f1_score": f1,
    "f2_score": f2,
    "specificity": specificity,
    "fpr": fpr,
    "fnr": fnr,
    "roc_auc": roc_auc,
    "best_ae_val_loss": best_ae_val_loss,
    "best_mlp_val_f1_argmax": best_val_f1,
    "tn": int(tn),
    "fp": int(fp),
    "fn": int(fn),
    "tp": int(tp)
}

metadata = {
    "architecture": (
        "HFL AE trained on normal traffic only. Clients are aggregated first by edge "
        "servers, then edge models are aggregated by a global server. AE first detects "
        "attacks using an automatically selected reconstruction-error percentile. "
        "MLP receives latent AE features, reconstruction error, AE binary decision "
        "and AE score. Final MLP decision threshold is selected automatically on validation."
    ),
    "input_dim": input_dim,
    "mlp_input_dim": mlp_input_dim,
    "num_clients": NUM_CLIENTS,
    "num_edge_servers": NUM_EDGE_SERVERS,
    "client_edge_assignments": CLIENT_EDGE_ASSIGNMENTS,
    "client_data_proportions": CLIENT_DATA_PROPORTIONS,
    "global_rounds": GLOBAL_ROUNDS,
    "local_epochs_ae": LOCAL_EPOCHS_AE,
    "local_epochs_mlp": LOCAL_EPOCHS_MLP,
    "batch_size": BATCH_SIZE,
    "learning_rate_ae": LEARNING_RATE_AE,
    "learning_rate_mlp": LEARNING_RATE_MLP,
    "auto_threshold_percentiles": AUTO_THRESHOLD_PERCENTILES.tolist(),
    "mlp_threshold_metric": MLP_THRESHOLD_METRIC,
    "mlp_threshold_grid": MLP_THRESHOLD_GRID.tolist(),
    "use_reconstruction_error_as_feature": USE_RECONSTRUCTION_ERROR_AS_FEATURE,
    "use_ae_decision_as_mlp_feature": USE_AE_DECISION_AS_MLP_FEATURE
}

joblib.dump(scaler, os.path.join(SAVE_FOLDER, "scaler_kdd.pkl"))
joblib.dump(mlp_scaler, os.path.join(SAVE_FOLDER, "mlp_feature_scaler.pkl"))
joblib.dump(feature_columns, os.path.join(SAVE_FOLDER, "feature_columns_kdd.pkl"))
joblib.dump(AE_THRESHOLD, os.path.join(SAVE_FOLDER, "ae_threshold.pkl"))
joblib.dump(ae_threshold_info, os.path.join(SAVE_FOLDER, "ae_threshold_info.pkl"))
joblib.dump(MLP_DECISION_THRESHOLD, os.path.join(SAVE_FOLDER, "mlp_decision_threshold.pkl"))
joblib.dump(mlp_threshold_info, os.path.join(SAVE_FOLDER, "mlp_threshold_info.pkl"))
joblib.dump(metrics, os.path.join(SAVE_FOLDER, "metrics_hfl_ae_mlp_auto_threshold_kdd_mlp_threshold.pkl"))
joblib.dump(metadata, os.path.join(SAVE_FOLDER, "metadata_hfl_ae_mlp_auto_threshold_kdd_mlp_threshold.pkl"))

torch.save(best_ae.state_dict(), os.path.join(SAVE_FOLDER, "final_hfl_autoencoder_auto_threshold.pth"))
torch.save(best_mlp.state_dict(), os.path.join(SAVE_FOLDER, "final_hfl_mlp_confirm_classifier.pth"))

print("\n===== SAUVEGARDE TERMINEE =====")
print("Dossier resultats :", SAVE_FOLDER)
print("Fichier resultats :", results_path)
