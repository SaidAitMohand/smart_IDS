import os
import glob
import copy
import random
import joblib
import tarfile
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
    roc_auc_score
)

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader

try:
    from tqdm import tqdm
    TQDM_AVAILABLE = True
except ImportError:
    TQDM_AVAILABLE = False


# =========================================================
# 1. PARAMETRES CIC-IoMT 2024
# =========================================================
BENIGN_TRAIN_FILE = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/CIC IOMT 24/Train/Benign_train.pcap.csv"
TRAIN_FOLDER = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/CIC IOMT 24/Train"
TEST_FOLDER = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/CIC IOMT 24/Test"

SAVE_FOLDER = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/CIC IOMT 24/HFL_AE_MLP_AUTO_THRESHOLD"
os.makedirs(SAVE_FOLDER, exist_ok=True)

LABEL_COL = "label"
NORMAL_VALUES = ["benign", "normal", "0", 0]

RANDOM_STATE = 42
VALID_SIZE_AE = 0.2
MLP_VALID_SIZE = 0.2

NUM_CLIENTS = 5
CLIENT_DATA_PROPORTIONS = [0.40, 0.25, 0.18, 0.12, 0.05]

# HFL = clients -> edge servers -> global server
NUM_EDGE_SERVERS = 2
CLIENT_EDGE_ASSIGNMENTS = [0, 0, 1, 1, 1]

GLOBAL_ROUNDS = 10
LOCAL_EPOCHS_AE = 5
LOCAL_EPOCHS_MLP = 5

BATCH_SIZE = 256
LEARNING_RATE_AE = 1e-3
LEARNING_RATE_MLP = 1e-3

AUTO_THRESHOLD_PERCENTILES = np.concatenate([
    np.arange(80.0, 99.0, 0.5),
    np.arange(99.0, 99.95, 0.05)
])

USE_RECONSTRUCTION_ERROR_AS_FEATURE = True
USE_AE_DECISION_AS_MLP_FEATURE = True

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device utilise :", DEVICE)

random.seed(RANDOM_STATE)
np.random.seed(RANDOM_STATE)
torch.manual_seed(RANDOM_STATE)


def validate_hfl_config():
    if len(CLIENT_DATA_PROPORTIONS) != NUM_CLIENTS:
        raise ValueError("CLIENT_DATA_PROPORTIONS doit avoir la meme taille que NUM_CLIENTS.")
    if not np.isclose(sum(CLIENT_DATA_PROPORTIONS), 1.0):
        raise ValueError("La somme de CLIENT_DATA_PROPORTIONS doit etre egale a 1.0.")
    if len(CLIENT_EDGE_ASSIGNMENTS) != NUM_CLIENTS:
        raise ValueError("CLIENT_EDGE_ASSIGNMENTS doit avoir la meme taille que NUM_CLIENTS.")
    if min(CLIENT_EDGE_ASSIGNMENTS) < 0 or max(CLIENT_EDGE_ASSIGNMENTS) >= NUM_EDGE_SERVERS:
        raise ValueError("Chaque edge id doit etre entre 0 et NUM_EDGE_SERVERS - 1.")


validate_hfl_config()


# =========================================================
# 2. BARRE DE PROGRESSION
# =========================================================
class ProgressBar:
    def __init__(self, total: int, desc: str = "", unit: str = "batch"):
        self.total = total
        self.desc = desc
        self.unit = unit
        self.current = 0
        self._bar = None

        if TQDM_AVAILABLE:
            self._bar = tqdm(
                total=total,
                desc=desc,
                unit=unit,
                ncols=90,
                leave=True,
                bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]"
            )

    def update(self, n: int = 1):
        self.current += n
        if self._bar:
            self._bar.update(n)
            return

        pct = self.current / self.total if self.total else 1
        width = 40
        done = int(width * pct)
        bar = "#" * done + "." * (width - done)
        print(f"\r{self.desc}: [{bar}] {self.current}/{self.total} {self.unit}", end="", flush=True)
        if self.current >= self.total:
            print()

    def set_postfix(self, **kwargs):
        if self._bar:
            self._bar.set_postfix(**kwargs)

    def close(self):
        if self._bar:
            self._bar.close()
        elif self.current < self.total:
            print()


# =========================================================
# 3. LECTURE CSV / TAR.XZ
# =========================================================
def read_csv_or_tarxz(path: str) -> pd.DataFrame:
    if path.endswith(".tar.xz"):
        with tarfile.open(path, "r:xz") as tar:
            members = [m for m in tar.getmembers() if m.name.endswith(".csv")]
            if not members:
                raise ValueError(f"Aucun CSV dans {path}")
            file_obj = tar.extractfile(members[0])
            return pd.read_csv(file_obj)
    return pd.read_csv(path)


def list_data_files(folder: str):
    files = []
    files.extend(glob.glob(os.path.join(folder, "*.csv")))
    files.extend(glob.glob(os.path.join(folder, "*.csv.tar.xz")))
    return sorted(files)


def load_labeled_folder(folder: str):
    files = list_data_files(folder)
    if not files:
        raise FileNotFoundError(f"Aucun fichier CSV ou csv.tar.xz dans : {folder}")

    dfs, labels, source_files = [], [], []
    normal_set = [str(v).lower() for v in NORMAL_VALUES]

    print(f"\nChargement dossier : {folder}")
    print("Nombre de fichiers :", len(files))

    for path in files:
        filename = os.path.basename(path)
        df = read_csv_or_tarxz(path)
        df.columns = df.columns.str.strip()

        if LABEL_COL in df.columns:
            y_file = df[LABEL_COL].apply(
                lambda x: 0 if str(x).strip().lower() in normal_set else 1
            ).astype(int).values
            df = df.drop(columns=[LABEL_COL])
        else:
            if "benign" in filename.lower() or "normal" in filename.lower():
                y_file = np.zeros(len(df), dtype=int)
            else:
                y_file = np.ones(len(df), dtype=int)

        dfs.append(df)
        labels.append(y_file)
        source_files.extend([filename] * len(df))

        print(f"[OK] {filename} -> {df.shape} | benign={np.sum(y_file == 0)} | attack={np.sum(y_file == 1)}")

    X_df = pd.concat(dfs, ignore_index=True)
    y = np.concatenate(labels)
    return X_df, y, source_files


# =========================================================
# 4. PRETRAITEMENT
# =========================================================
DROP_COLS = [
    "Flow ID", "flow_id", "Timestamp", "timestamp",
    "Src IP", "Dst IP", "Source IP", "Destination IP", "Unnamed: 0"
]


def preprocess_fit(df: pd.DataFrame):
    df = df.copy()
    df.columns = df.columns.str.strip()
    df = df.drop(columns=[c for c in DROP_COLS if c in df.columns], errors="ignore")
    if LABEL_COL in df.columns:
        df = df.drop(columns=[LABEL_COL])

    df = df.select_dtypes(include=[np.number])
    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.dropna(axis=1, how="all")
    df = df.fillna(df.median(numeric_only=True)).fillna(0)

    constant_cols = [c for c in df.columns if df[c].nunique() <= 1]
    if constant_cols:
        df = df.drop(columns=constant_cols)
    print("Colonnes constantes supprimees :", len(constant_cols))

    feature_columns = list(df.columns)
    scaler = StandardScaler()
    X = scaler.fit_transform(df).astype(np.float32)
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)
    return X, scaler, feature_columns


def preprocess_transform(df: pd.DataFrame, scaler, feature_columns):
    df = df.copy()
    df.columns = df.columns.str.strip()
    df = df.drop(columns=[c for c in DROP_COLS if c in df.columns], errors="ignore")
    if LABEL_COL in df.columns:
        df = df.drop(columns=[LABEL_COL])

    df = df.select_dtypes(include=[np.number])
    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.dropna(axis=1, how="all")
    df = df.fillna(df.median(numeric_only=True)).fillna(0)

    missing = [c for c in feature_columns if c not in df.columns]
    extra = [c for c in df.columns if c not in feature_columns]
    df = df.reindex(columns=feature_columns, fill_value=0)

    print(f"\nAlignement : colonnes manquantes={len(missing)}, extra ignorees={len(extra)}")

    X = scaler.transform(df).astype(np.float32)
    return np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)


# =========================================================
# 5. MODELES
# =========================================================
class Autoencoder(nn.Module):
    def __init__(self, input_dim: int):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 256), nn.ReLU(),
            nn.Linear(256, 128), nn.ReLU(),
            nn.Linear(128, 64), nn.ReLU(),
        )
        self.decoder = nn.Sequential(
            nn.Linear(64, 128), nn.ReLU(),
            nn.Linear(128, 256), nn.ReLU(),
            nn.Linear(256, input_dim),
        )

    def forward(self, x):
        return self.decoder(self.encoder(x))

    def encode(self, x):
        return self.encoder(x)


class MLPBinaryClassifier(nn.Module):
    def __init__(self, input_dim: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128), nn.ReLU(),
            nn.BatchNorm1d(128), nn.Dropout(0.3),
            nn.Linear(128, 64), nn.ReLU(),
            nn.BatchNorm1d(64), nn.Dropout(0.3),
            nn.Linear(64, 32), nn.ReLU(),
            nn.Linear(32, 2),
        )

    def forward(self, x):
        return self.net(x)


# =========================================================
# 6. DATA LOADERS / OUTILS HFL
# =========================================================
def make_ae_loader(X, shuffle=True):
    tensor = torch.tensor(X, dtype=torch.float32)
    return DataLoader(TensorDataset(tensor, tensor), batch_size=BATCH_SIZE, shuffle=shuffle)


def make_supervised_loader(X, y, shuffle=True):
    X_tensor = torch.tensor(X, dtype=torch.float32)
    y_tensor = torch.tensor(y, dtype=torch.long)
    return DataLoader(TensorDataset(X_tensor, y_tensor), batch_size=BATCH_SIZE, shuffle=shuffle)


def normalize_proportions(proportions, num_clients):
    if len(proportions) != num_clients:
        raise ValueError("CLIENT_DATA_PROPORTIONS doit avoir la meme taille que NUM_CLIENTS.")
    p = np.array(proportions, dtype=np.float64)
    if np.any(p <= 0):
        raise ValueError("Toutes les proportions doivent etre positives.")
    return p / p.sum()


def split_clients_unsupervised(X, num_clients, proportions):
    p = normalize_proportions(proportions, num_clients)
    idx = np.random.permutation(len(X))
    X = X[idx]
    split_points = (np.cumsum(p)[:-1] * len(X)).astype(int)
    return np.split(X, split_points)


def split_clients_supervised(X, y, num_clients, proportions):
    p = normalize_proportions(proportions, num_clients)
    idx = np.random.permutation(len(X))
    X = X[idx]
    y = y[idx]
    split_points = (np.cumsum(p)[:-1] * len(X)).astype(int)
    return list(zip(np.split(X, split_points), np.split(y, split_points)))


def weighted_average_state_dicts(state_dicts, sizes):
    total = sum(sizes)
    if total == 0:
        raise ValueError("Impossible d'agreger avec total = 0.")

    avg = copy.deepcopy(state_dicts[0])
    for key in avg:
        if not torch.is_floating_point(avg[key]):
            avg[key] = state_dicts[0][key]
            continue

        avg[key] = torch.zeros_like(avg[key])
        for sd, size in zip(state_dicts, sizes):
            avg[key] += sd[key] * (size / total)
    return avg


def hfl_aggregate(local_weights, local_sizes, model_name="model"):
    print(f"\n===== AGREGATION HFL : {model_name} =====")

    edge_weights = []
    edge_sizes = []

    for edge_id in range(NUM_EDGE_SERVERS):
        client_ids = [
            i for i, assigned_edge in enumerate(CLIENT_EDGE_ASSIGNMENTS)
            if assigned_edge == edge_id and local_sizes[i] > 0
        ]

        if not client_ids:
            print(f"Edge {edge_id + 1}: aucun client actif.")
            continue

        weights_for_edge = [local_weights[i] for i in client_ids]
        sizes_for_edge = [local_sizes[i] for i in client_ids]

        edge_state = weighted_average_state_dicts(weights_for_edge, sizes_for_edge)
        edge_size = sum(sizes_for_edge)

        edge_weights.append(edge_state)
        edge_sizes.append(edge_size)

        print(f"Edge {edge_id + 1}: clients={[i + 1 for i in client_ids]} | total_size={edge_size}")

    global_state = weighted_average_state_dicts(edge_weights, edge_sizes)
    print("Serveur central: tailles edges =", edge_sizes)
    return global_state


# =========================================================
# 7. ENTRAINEMENTS LOCAUX
# =========================================================
def train_local_ae(global_model, client_X, client_id: int):
    local = copy.deepcopy(global_model).to(DEVICE)
    local.train()

    loader = make_ae_loader(client_X, shuffle=True)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(local.parameters(), lr=LEARNING_RATE_AE)
    losses = []

    bar = ProgressBar(
        len(loader) * LOCAL_EPOCHS_AE,
        desc=f"  Client AE {client_id} -> Edge {CLIENT_EDGE_ASSIGNMENTS[client_id - 1] + 1} ({len(client_X)} samples)",
        unit="batch"
    )

    for epoch in range(LOCAL_EPOCHS_AE):
        running = 0.0
        for bx, bt in loader:
            bx = bx.to(DEVICE)
            bt = bt.to(DEVICE)

            optimizer.zero_grad()
            out = local(bx)
            loss = criterion(out, bt)

            if not torch.isnan(loss):
                loss.backward()
                optimizer.step()
                running += loss.item() * bx.size(0)

            bar.update(1)
            bar.set_postfix(epoch=epoch + 1, loss=f"{loss.item():.5f}")

        losses.append(running / len(loader.dataset))

    bar.close()
    return local.state_dict(), len(client_X), float(np.mean(losses))


def train_local_mlp(global_model, client_X, client_y, client_id: int):
    local = copy.deepcopy(global_model).to(DEVICE)
    local.train()

    loader = make_supervised_loader(client_X, client_y, shuffle=True)
    class_counts = np.bincount(client_y, minlength=2)
    total = class_counts.sum()
    weights = torch.tensor(
        total / (2.0 * np.maximum(class_counts, 1)),
        dtype=torch.float32
    ).to(DEVICE)

    criterion = nn.CrossEntropyLoss(weight=weights)
    optimizer = optim.Adam(local.parameters(), lr=LEARNING_RATE_MLP)
    losses = []

    bar = ProgressBar(
        len(loader) * LOCAL_EPOCHS_MLP,
        desc=(
            f"  Client MLP {client_id} -> Edge {CLIENT_EDGE_ASSIGNMENTS[client_id - 1] + 1} "
            f"(B={np.sum(client_y == 0)}, A={np.sum(client_y == 1)})"
        ),
        unit="batch"
    )

    for epoch in range(LOCAL_EPOCHS_MLP):
        running = 0.0
        for bx, by in loader:
            bx = bx.to(DEVICE)
            by = by.to(DEVICE)

            optimizer.zero_grad()
            loss = criterion(local(bx), by)

            if not torch.isnan(loss):
                loss.backward()
                optimizer.step()
                running += loss.item() * bx.size(0)

            bar.update(1)
            bar.set_postfix(epoch=epoch + 1, loss=f"{loss.item():.5f}")

        losses.append(running / len(loader.dataset))

    bar.close()
    return local.state_dict(), len(client_X), float(np.mean(losses))


# =========================================================
# 8. AE DETECTION / FEATURES / PREDICTION
# =========================================================
def reconstruction_errors(model, X):
    model.eval()
    loader = DataLoader(
        torch.tensor(X, dtype=torch.float32),
        batch_size=BATCH_SIZE,
        shuffle=False
    )
    errors = []

    with torch.no_grad():
        for bx in loader:
            bx = bx.to(DEVICE)
            err = torch.mean((bx - model(bx)) ** 2, dim=1)
            errors.extend(err.cpu().numpy())

    return np.array(errors, dtype=np.float32)


def choose_auto_threshold(normal_reference_errors, validation_errors, validation_y):
    best = {
        "percentile": None,
        "threshold": None,
        "accuracy": -1.0,
        "precision": 0.0,
        "recall": 0.0,
        "f1": -1.0,
        "fpr": 1.0
    }

    for percentile in AUTO_THRESHOLD_PERCENTILES:
        threshold = float(np.percentile(normal_reference_errors, percentile))
        pred = (validation_errors > threshold).astype(int)

        acc = accuracy_score(validation_y, pred)
        prec = precision_score(validation_y, pred, zero_division=0)
        rec = recall_score(validation_y, pred, zero_division=0)
        f1 = f1_score(validation_y, pred, zero_division=0)
        tn, fp, fn, tp = confusion_matrix(validation_y, pred, labels=[0, 1]).ravel()
        fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0

        better = f1 > best["f1"]
        same_f1_better_fpr = np.isclose(f1, best["f1"]) and fpr < best["fpr"]
        if better or same_f1_better_fpr:
            best = {
                "percentile": float(percentile),
                "threshold": threshold,
                "accuracy": float(acc),
                "precision": float(prec),
                "recall": float(rec),
                "f1": float(f1),
                "fpr": float(fpr)
            }

    return best


def extract_ae_features_and_detection(model, X, threshold, normal_error_std):
    model.eval()
    loader = DataLoader(
        torch.tensor(X, dtype=torch.float32),
        batch_size=BATCH_SIZE,
        shuffle=False
    )

    zs, errors = [], []
    with torch.no_grad():
        for bx in loader:
            bx = bx.to(DEVICE)
            z = model.encode(bx)
            x_hat = model(bx)
            err = torch.mean((bx - x_hat) ** 2, dim=1, keepdim=True)

            zs.append(z.cpu().numpy())
            errors.append(err.cpu().numpy())

    z_all = np.vstack(zs).astype(np.float32)
    err_all = np.vstack(errors).astype(np.float32)

    ae_pred = (err_all > threshold).astype(np.float32)
    ae_score = ((err_all - threshold) / max(normal_error_std, 1e-12)).astype(np.float32)

    features = [z_all]
    if USE_RECONSTRUCTION_ERROR_AS_FEATURE:
        features.append(err_all)
    if USE_AE_DECISION_AS_MLP_FEATURE:
        features.extend([ae_pred, ae_score])

    X_mlp = np.hstack(features).astype(np.float32)
    return X_mlp, err_all.ravel(), ae_pred.ravel().astype(int), ae_score.ravel()


def predict_mlp(model, X):
    model.eval()
    loader = DataLoader(
        torch.tensor(X, dtype=torch.float32),
        batch_size=BATCH_SIZE,
        shuffle=False
    )

    preds, probs_list = [], []
    softmax = nn.Softmax(dim=1)

    with torch.no_grad():
        for bx in loader:
            bx = bx.to(DEVICE)
            probs = softmax(model(bx))
            preds.extend(torch.argmax(probs, dim=1).cpu().numpy())
            probs_list.append(probs.cpu().numpy())

    return np.array(preds), np.vstack(probs_list)


# =========================================================
# 9. EVALUATION
# =========================================================
def evaluate(name, y_true, y_pred, scores=None):
    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)

    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    fnr = fn / (fn + tp) if (fn + tp) > 0 else 0.0
    spec = tn / (tn + fp) if (tn + fp) > 0 else 0.0

    try:
        auc = roc_auc_score(y_true, scores) if scores is not None else np.nan
    except Exception:
        auc = np.nan

    print(f"\n{'=' * 55}")
    print(f" RESULTATS - {name}")
    print(f"{'=' * 55}")
    print(f"  Accuracy              : {acc:.4f}")
    print(f"  Precision             : {prec:.4f}")
    print(f"  Recall / Detection    : {rec:.4f}")
    print(f"  F1-score              : {f1:.4f}")
    print(f"  Specificity           : {spec:.4f}")
    print(f"  False Positive Rate   : {fpr:.4f}")
    print(f"  False Negative Rate   : {fnr:.4f}")
    print(f"  ROC-AUC               : {auc:.4f}" if not np.isnan(auc) else "  ROC-AUC               : N/A")
    print("\n  Matrice de confusion :")
    print(cm)
    print("\n  Classification report :")
    print(classification_report(
        y_true,
        y_pred,
        target_names=["Benign", "Attack"],
        digits=4,
        zero_division=0
    ))

    return {
        "accuracy": float(acc),
        "precision": float(prec),
        "recall": float(rec),
        "f1_score": float(f1),
        "specificity": float(spec),
        "fpr": float(fpr),
        "fnr": float(fnr),
        "roc_auc": float(auc) if not np.isnan(auc) else np.nan,
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp)
    }


# =========================================================
# 10. CHARGEMENT BENIGN POUR AE
# =========================================================
print("\n" + "=" * 55)
print(" ETAPE 1 - Chargement Benign pour AE")
print("=" * 55)

df_benign = read_csv_or_tarxz(BENIGN_TRAIN_FILE)
df_benign.columns = df_benign.columns.str.strip()
if LABEL_COL in df_benign.columns:
    df_benign = df_benign.drop(columns=[LABEL_COL])

print("Shape brute benign :", df_benign.shape)
X_benign, scaler, feature_columns = preprocess_fit(df_benign)
print("Shape apres pretraitement :", X_benign.shape)
print("Nombre de features       :", len(feature_columns))

X_ae_train, X_ae_val = train_test_split(
    X_benign,
    test_size=VALID_SIZE_AE,
    random_state=RANDOM_STATE
)

print(f"\nAE train : {X_ae_train.shape} | AE val : {X_ae_val.shape}")

clients_ae = split_clients_unsupervised(X_ae_train, NUM_CLIENTS, CLIENT_DATA_PROPORTIONS)
print("\n===== CLIENTS AE HFL =====")
for i, cx in enumerate(clients_ae):
    print(f"  Client AE {i + 1} -> Edge {CLIENT_EDGE_ASSIGNMENTS[i] + 1} : {cx.shape}")

print("\n===== CONFIGURATION HFL =====")
print("NUM_CLIENTS :", NUM_CLIENTS)
print("NUM_EDGE_SERVERS :", NUM_EDGE_SERVERS)
print("CLIENT_EDGE_ASSIGNMENTS :", CLIENT_EDGE_ASSIGNMENTS)
print("CLIENT_DATA_PROPORTIONS :", CLIENT_DATA_PROPORTIONS)


# =========================================================
# 11. ENTRAINEMENT AE HFL
# =========================================================
print("\n" + "=" * 55)
print(" ETAPE 2 - Entrainement AE HFL (benign only)")
print("=" * 55)

input_dim = X_benign.shape[1]
ae_model = Autoencoder(input_dim).to(DEVICE)

best_ae_val_loss = float("inf")
best_ae_path = os.path.join(SAVE_FOLDER, "best_hfl_autoencoder_auto_threshold.pth")

for rnd in range(GLOBAL_ROUNDS):
    print(f"\n{'-' * 50}")
    print(f"  Round AE HFL {rnd + 1}/{GLOBAL_ROUNDS}")
    print(f"{'-' * 50}")

    local_weights, local_sizes, local_losses = [], [], []
    for i, cx in enumerate(clients_ae):
        w, size, loss = train_local_ae(ae_model, cx, client_id=i + 1)
        local_weights.append(w)
        local_sizes.append(size)
        local_losses.append(loss)
        print(
            f"  -> Client AE {i + 1} -> Edge {CLIENT_EDGE_ASSIGNMENTS[i] + 1} "
            f"termine | size={size} | loss={loss:.6f}"
        )

    ae_model.load_state_dict(hfl_aggregate(local_weights, local_sizes, "Autoencoder"))

    val_errs = reconstruction_errors(ae_model, X_ae_val)
    val_loss = float(np.mean(val_errs))
    print(f"\n  [Round {rnd + 1}] Val loss AE : {val_loss:.6f} (best={best_ae_val_loss:.6f})")

    if val_loss < best_ae_val_loss:
        best_ae_val_loss = val_loss
        torch.save(ae_model.state_dict(), best_ae_path)
        print("  >> Meilleur AE HFL sauvegarde.")

best_ae = Autoencoder(input_dim).to(DEVICE)
best_ae.load_state_dict(torch.load(best_ae_path, map_location=DEVICE))
best_ae.eval()
print(f"\nMeilleure validation loss AE : {best_ae_val_loss:.6f}")


# =========================================================
# 12. CHARGEMENT TRAIN + TEST LABELISES
# =========================================================
print("\n" + "=" * 55)
print(" ETAPE 3 - Chargement Train / Test labelises")
print("=" * 55)

X_train_df, y_train_all, src_train = load_labeled_folder(TRAIN_FOLDER)
X_test_df, y_test, src_test = load_labeled_folder(TEST_FOLDER)

print(f"\nTrain total={len(y_train_all)} | benign={np.sum(y_train_all == 0)} | attack={np.sum(y_train_all == 1)}")
print(f"Test  total={len(y_test)} | benign={np.sum(y_test == 0)} | attack={np.sum(y_test == 1)}")

X_train_all = preprocess_transform(X_train_df, scaler, feature_columns)
X_test = preprocess_transform(X_test_df, scaler, feature_columns)

X_train_raw, X_val_raw, y_train, y_val, src_train_used, src_val = train_test_split(
    X_train_all,
    y_train_all,
    src_train,
    test_size=MLP_VALID_SIZE,
    random_state=RANDOM_STATE,
    stratify=y_train_all
)

print("\n===== Split train/validation MLP =====")
print("Train MLP raw :", X_train_raw.shape, "| benign=", np.sum(y_train == 0), "| attack=", np.sum(y_train == 1))
print("Val MLP raw   :", X_val_raw.shape, "| benign=", np.sum(y_val == 0), "| attack=", np.sum(y_val == 1))


# =========================================================
# 13. SEUIL AUTOMATIQUE AE + FEATURES POUR MLP
# =========================================================
print("\n" + "=" * 55)
print(" ETAPE 4 - Seuil AE automatique + extraction features")
print("=" * 55)

normal_reference_errors = reconstruction_errors(best_ae, X_ae_train)
val_errors_for_threshold = reconstruction_errors(best_ae, X_val_raw)

ae_threshold_info = choose_auto_threshold(
    normal_reference_errors=normal_reference_errors,
    validation_errors=val_errors_for_threshold,
    validation_y=y_val
)

AE_THRESHOLD_PERCENTILE = ae_threshold_info["percentile"]
AE_THRESHOLD = ae_threshold_info["threshold"]
AE_NORMAL_ERROR_STD = float(np.std(normal_reference_errors))

print("Percentile AE choisi :", AE_THRESHOLD_PERCENTILE)
print("Threshold AE         :", AE_THRESHOLD)
print("Validation AE Acc    :", ae_threshold_info["accuracy"])
print("Validation AE Prec   :", ae_threshold_info["precision"])
print("Validation AE Recall :", ae_threshold_info["recall"])
print("Validation AE F1     :", ae_threshold_info["f1"])
print("Validation AE FPR    :", ae_threshold_info["fpr"])

X_train_mlp, train_errors, train_ae_pred, train_ae_score = extract_ae_features_and_detection(
    best_ae,
    X_train_raw,
    threshold=AE_THRESHOLD,
    normal_error_std=AE_NORMAL_ERROR_STD
)
X_val_mlp, val_errors, val_ae_pred, val_ae_score = extract_ae_features_and_detection(
    best_ae,
    X_val_raw,
    threshold=AE_THRESHOLD,
    normal_error_std=AE_NORMAL_ERROR_STD
)
X_test_mlp, test_errors, test_ae_pred, test_ae_score = extract_ae_features_and_detection(
    best_ae,
    X_test,
    threshold=AE_THRESHOLD,
    normal_error_std=AE_NORMAL_ERROR_STD
)

print("\n===== Performance AE seul sur validation =====")
print("F1 AE validation :", f1_score(y_val, val_ae_pred, zero_division=0))
print(confusion_matrix(y_val, val_ae_pred, labels=[0, 1]))

mlp_feature_scaler = StandardScaler()
X_train_mlp = mlp_feature_scaler.fit_transform(X_train_mlp).astype(np.float32)
X_val_mlp = mlp_feature_scaler.transform(X_val_mlp).astype(np.float32)
X_test_mlp = mlp_feature_scaler.transform(X_test_mlp).astype(np.float32)

print(f"X_train_mlp : {X_train_mlp.shape}")
print(f"X_val_mlp   : {X_val_mlp.shape}")
print(f"X_test_mlp  : {X_test_mlp.shape}")


# =========================================================
# 14. CLIENTS MLP + HFL
# =========================================================
clients_mlp = split_clients_supervised(X_train_mlp, y_train, NUM_CLIENTS, CLIENT_DATA_PROPORTIONS)

print("\n===== CLIENTS MLP HFL =====")
for i, (cx, cy) in enumerate(clients_mlp):
    print(
        f"  Client MLP {i + 1} -> Edge {CLIENT_EDGE_ASSIGNMENTS[i] + 1} : "
        f"X={cx.shape} | benign={np.sum(cy == 0)} | attack={np.sum(cy == 1)}"
    )


# =========================================================
# 15. ENTRAINEMENT HFL + MLP
# =========================================================
print("\n" + "=" * 55)
print(" ETAPE 5 - HFL + MLP")
print("=" * 55)

mlp_dim = X_train_mlp.shape[1]
global_mlp = MLPBinaryClassifier(mlp_dim).to(DEVICE)

best_mlp_f1 = -1.0
best_mlp_path = os.path.join(SAVE_FOLDER, "best_hfl_mlp_binary_auto_threshold.pth")

for rnd in range(GLOBAL_ROUNDS):
    print(f"\n{'-' * 50}")
    print(f"  Round MLP HFL {rnd + 1}/{GLOBAL_ROUNDS}")
    print(f"{'-' * 50}")

    local_weights, local_sizes, local_losses = [], [], []

    for i, (cx, cy) in enumerate(clients_mlp):
        w, size, loss = train_local_mlp(global_mlp, cx, cy, client_id=i + 1)
        local_weights.append(w)
        local_sizes.append(size)
        local_losses.append(loss)
        print(
            f"  -> Client MLP {i + 1} -> Edge {CLIENT_EDGE_ASSIGNMENTS[i] + 1} "
            f"termine | size={size} | loss={loss:.6f}"
        )

    global_mlp.load_state_dict(hfl_aggregate(local_weights, local_sizes, "MLP"))

    val_pred, val_probs = predict_mlp(global_mlp, X_val_mlp)
    val_scores = val_probs[:, 1]
    val_f1 = f1_score(y_val, val_pred, zero_division=0)
    val_acc = accuracy_score(y_val, val_pred)
    val_rec = recall_score(y_val, val_pred, zero_division=0)

    print(f"\n  [Round {rnd + 1}] Loss clients={np.mean(local_losses):.5f}")
    print(f"  [Round {rnd + 1}] Val Accuracy={val_acc:.4f} | Val F1={val_f1:.4f} | Val Recall={val_rec:.4f} (best={best_mlp_f1:.4f})")

    if val_f1 > best_mlp_f1:
        best_mlp_f1 = val_f1
        torch.save(global_mlp.state_dict(), best_mlp_path)
        print("  >> Meilleur MLP HFL sauvegarde.")

best_mlp = MLPBinaryClassifier(mlp_dim).to(DEVICE)
best_mlp.load_state_dict(torch.load(best_mlp_path, map_location=DEVICE))
best_mlp.eval()
print(f"\nMeilleur Val F1 MLP : {best_mlp_f1:.4f}")


# =========================================================
# 16. EVALUATION FINALE
# =========================================================
print("\n" + "=" * 55)
print(" ETAPE 6 - Evaluation finale sur Test Set")
print("=" * 55)

ae_results = evaluate(
    "AE HFL seul avec threshold automatique",
    y_test,
    test_ae_pred,
    scores=test_errors
)

test_pred, test_probs = predict_mlp(best_mlp, X_test_mlp)
test_scores = test_probs[:, 1]

test_results = evaluate(
    "HFL AE -> MLP (CIC-IoMT 2024)",
    y_test,
    test_pred,
    scores=test_scores
)

print("\n===== Resume erreurs AE test =====")
print(pd.Series(test_errors).describe())

print("\n===== Resume scores MLP test =====")
print(pd.Series(test_scores).describe())


# =========================================================
# 17. SAUVEGARDE
# =========================================================
print("\n" + "=" * 55)
print(" ETAPE 7 - Sauvegarde")
print("=" * 55)

torch.save(best_ae.state_dict(), os.path.join(SAVE_FOLDER, "hfl_autoencoder_auto_threshold_final.pth"))
torch.save(best_mlp.state_dict(), os.path.join(SAVE_FOLDER, "hfl_mlp_binary_auto_threshold_final.pth"))

joblib.dump(scaler, os.path.join(SAVE_FOLDER, "scaler.pkl"))
joblib.dump(mlp_feature_scaler, os.path.join(SAVE_FOLDER, "mlp_feature_scaler.pkl"))
joblib.dump(feature_columns, os.path.join(SAVE_FOLDER, "feature_columns.pkl"))
joblib.dump(ae_threshold_info, os.path.join(SAVE_FOLDER, "ae_threshold_info.pkl"))

metadata = {
    "architecture": (
        "HFL + AE + MLP sur CIC-IoMT 2024. AE entraine sur benign only avec HFL. "
        "Seuil AE choisi automatiquement sur validation. MLP recoit latent AE, erreur de reconstruction, "
        "decision AE et score AE, puis est entraine avec HFL."
    ),
    "num_clients": NUM_CLIENTS,
    "num_edge_servers": NUM_EDGE_SERVERS,
    "client_edge_assignments": CLIENT_EDGE_ASSIGNMENTS,
    "client_data_proportions": CLIENT_DATA_PROPORTIONS,
    "global_rounds": GLOBAL_ROUNDS,
    "local_epochs_ae": LOCAL_EPOCHS_AE,
    "local_epochs_mlp": LOCAL_EPOCHS_MLP,
    "batch_size": BATCH_SIZE,
    "learning_rate_ae": LEARNING_RATE_AE,
    "learning_rate_mlp": LEARNING_RATE_MLP,
    "best_ae_val_loss": best_ae_val_loss,
    "best_mlp_val_f1": best_mlp_f1,
    "input_dim": input_dim,
    "mlp_input_dim": mlp_dim,
    "ae_threshold_percentile": AE_THRESHOLD_PERCENTILE,
    "ae_threshold": AE_THRESHOLD,
    "use_reconstruction_error_as_feature": USE_RECONSTRUCTION_ERROR_AS_FEATURE,
    "use_ae_decision_as_mlp_feature": USE_AE_DECISION_AS_MLP_FEATURE
}

all_metrics = {
    "ae_results": ae_results,
    "mlp_results": test_results,
    "ae_threshold_info": ae_threshold_info
}

joblib.dump(metadata, os.path.join(SAVE_FOLDER, "metadata_hfl_auto_threshold.pkl"))
joblib.dump(all_metrics, os.path.join(SAVE_FOLDER, "metrics_hfl_auto_threshold.pkl"))

results_df = pd.DataFrame({
    "source_file": src_test,
    "y_true": y_test,
    "ae_pred": test_ae_pred,
    "mlp_pred": test_pred,
    "mlp_attack_score": test_scores,
    "ae_reconstruction_error": test_errors,
    "ae_score": test_ae_score
})

results_path = os.path.join(SAVE_FOLDER, "detailed_predictions_hfl_auto_threshold.csv")
results_df.to_csv(results_path, index=False)

print("\nTous les artefacts sauvegardes dans :", SAVE_FOLDER)
print("Fichier predictions :", results_path)
print("\nPipeline HFL AE -> MLP sur CIC-IoMT 2024 termine.")
