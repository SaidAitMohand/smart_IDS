import os
import copy
import random
import pickle

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    confusion_matrix,
    classification_report,
    roc_auc_score
)

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader

try:
    import joblib
except Exception:
    joblib = None

try:
    from tqdm.auto import tqdm
except Exception:
    tqdm = None


# =========================================================
# 1. PARAMETRES
# =========================================================
FILE_PATH = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/KDD/BoTNeTIoT-L01-v2.csv"
SAVE_FOLDER = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/BoTNeTIoT_HFL_AE_MLP_AUTO_THRESHOLD"
os.makedirs(SAVE_FOLDER, exist_ok=True)

LABEL_COL = "label"
NORMAL_LABEL = 0
ATTACK_LABEL = 1

TEST_SIZE = 0.30
MLP_VALID_SIZE = 0.20
AE_VALID_SIZE = 0.20

NUM_CLIENTS = 5
CLIENT_DATA_PROPORTIONS = [0.40, 0.25, 0.18, 0.12, 0.05]

# HFL = clients -> edge servers -> serveur global
NUM_EDGE_SERVERS = 2
CLIENT_EDGE_ASSIGNMENTS = [0, 0, 1, 1, 1]

GLOBAL_ROUNDS = 10
LOCAL_EPOCHS_AE = 2
LOCAL_EPOCHS_MLP = 5

BATCH_SIZE = 256
LEARNING_RATE_AE = 1e-3
LEARNING_RATE_MLP = 1e-3

RANDOM_STATE = 42

AUTO_THRESHOLD_PERCENTILES = np.concatenate([
    np.arange(80.0, 99.0, 0.5),
    np.arange(99.0, 99.95, 0.05)
])

USE_RECONSTRUCTION_ERROR_AS_FEATURE = True
USE_AE_DECISION_AS_MLP_FEATURE = True

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device utilise :", DEVICE)

random.seed(RANDOM_STATE)
np.random.seed(RANDOM_STATE)
torch.manual_seed(RANDOM_STATE)


def progress(iterable, **kwargs):
    if tqdm is None:
        return iterable
    kwargs.setdefault("dynamic_ncols", True)
    return tqdm(iterable, **kwargs)


def save_object(obj, path):
    if joblib is not None:
        joblib.dump(obj, path)
        return
    with open(path, "wb") as file:
        pickle.dump(obj, file)


def validate_config():
    if len(CLIENT_DATA_PROPORTIONS) != NUM_CLIENTS:
        raise ValueError("CLIENT_DATA_PROPORTIONS doit avoir la meme longueur que NUM_CLIENTS.")
    if any(p <= 0 for p in CLIENT_DATA_PROPORTIONS):
        raise ValueError("Toutes les proportions clients doivent etre positives.")
    if not np.isclose(sum(CLIENT_DATA_PROPORTIONS), 1.0):
        raise ValueError("La somme de CLIENT_DATA_PROPORTIONS doit etre egale a 1.0.")
    if len(CLIENT_EDGE_ASSIGNMENTS) != NUM_CLIENTS:
        raise ValueError("CLIENT_EDGE_ASSIGNMENTS doit avoir la meme longueur que NUM_CLIENTS.")
    if min(CLIENT_EDGE_ASSIGNMENTS) < 0 or max(CLIENT_EDGE_ASSIGNMENTS) >= NUM_EDGE_SERVERS:
        raise ValueError("Chaque edge id doit etre entre 0 et NUM_EDGE_SERVERS - 1.")


validate_config()


# =========================================================
# 2. PRETRAITEMENT BoT-IoT
# =========================================================
def load_bot_iot_dataset(file_path):
    df = pd.read_csv(file_path)
    df.columns = df.columns.str.strip()

    print("\n===== DATASET BRUT BoT-IoT =====")
    print("Shape :", df.shape)

    if LABEL_COL not in df.columns:
        raise ValueError(f"Colonne label introuvable : {LABEL_COL}")

    y = df[LABEL_COL].astype(int).values
    original_labels = df[LABEL_COL].values

    print("\n===== DISTRIBUTION LABELS =====")
    print(pd.Series(y).value_counts().sort_index())

    X_df = df.drop(columns=[LABEL_COL])

    cols_to_drop = [
        "Unnamed: 0", "pkSeqID", "stime", "ltime",
        "saddr", "daddr", "sport", "dport",
        "proto", "state", "flgs", "category", "subcategory"
    ]
    existing_to_drop = [col for col in cols_to_drop if col in X_df.columns]
    if existing_to_drop:
        X_df = X_df.drop(columns=existing_to_drop)
        print("Colonnes non numeriques/identifiants supprimees :", existing_to_drop)

    X_df = X_df.select_dtypes(include=[np.number])
    X_df = X_df.replace([np.inf, -np.inf], np.nan)
    X_df = X_df.dropna(axis=1, how="all")
    X_df = X_df.fillna(X_df.median(numeric_only=True))
    X_df = X_df.fillna(0)

    constant_cols = [col for col in X_df.columns if X_df[col].nunique() <= 1]
    if constant_cols:
        X_df = X_df.drop(columns=constant_cols)
        print("Colonnes constantes supprimees :", len(constant_cols))

    feature_columns = list(X_df.columns)

    print("\n===== FEATURES =====")
    print("Shape X :", X_df.shape)
    print("Nombre de features :", len(feature_columns))

    return X_df, y, original_labels, feature_columns


# =========================================================
# 3. OUTILS SPLIT / HFL
# =========================================================
def split_clients_unsupervised(X, proportions):
    indices = np.random.permutation(len(X))
    X = X[indices]

    counts = [int(len(X) * p) for p in proportions]
    counts[-1] = len(X) - sum(counts[:-1])

    clients = []
    start = 0
    for count in counts:
        end = start + count
        clients.append(X[start:end])
        start = end
    return clients


def split_clients_supervised(X, y, proportions):
    indices = np.random.permutation(len(X))
    X = X[indices]
    y = y[indices]

    counts = [int(len(X) * p) for p in proportions]
    counts[-1] = len(X) - sum(counts[:-1])

    clients = []
    start = 0
    for count in counts:
        end = start + count
        clients.append((X[start:end], y[start:end]))
        start = end
    return clients


def weighted_average_state_dicts(state_dicts, sizes):
    total_size = sum(sizes)
    if total_size == 0:
        raise ValueError("Impossible d'agreger avec total_size = 0.")

    avg_state = copy.deepcopy(state_dicts[0])
    for key in avg_state.keys():
        if not torch.is_floating_point(avg_state[key]):
            avg_state[key] = state_dicts[0][key]
            continue

        avg_state[key] = torch.zeros_like(avg_state[key])
        for state, size in zip(state_dicts, sizes):
            avg_state[key] += state[key] * (size / total_size)
    return avg_state


def hfl_aggregate(local_weights, local_sizes, model_name):
    """
    HFL en deux niveaux :
    1) chaque serveur edge agrege ses clients avec FedAvg ;
    2) le serveur global agrege les modeles edge avec FedAvg.
    """
    print(f"\n===== AGREGATION HFL : {model_name} =====")

    edge_weights = []
    edge_sizes = []

    for edge_id in range(NUM_EDGE_SERVERS):
        client_ids = [
            i for i, assigned_edge in enumerate(CLIENT_EDGE_ASSIGNMENTS)
            if assigned_edge == edge_id and local_sizes[i] > 0
        ]

        if not client_ids:
            print(f"Edge {edge_id + 1}: aucun client actif.")
            continue

        weights_for_edge = [local_weights[i] for i in client_ids]
        sizes_for_edge = [local_sizes[i] for i in client_ids]
        edge_state = weighted_average_state_dicts(weights_for_edge, sizes_for_edge)
        edge_size = sum(sizes_for_edge)

        edge_weights.append(edge_state)
        edge_sizes.append(edge_size)

        print(f"Edge {edge_id + 1}: clients={[i + 1 for i in client_ids]} | total_size={edge_size}")

    global_state = weighted_average_state_dicts(edge_weights, edge_sizes)
    print("Serveur global: tailles edges =", edge_sizes)
    return global_state


# =========================================================
# 4. MODELES
# =========================================================
class Autoencoder(nn.Module):
    def __init__(self, input_dim):
        super(Autoencoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 16),
            nn.ReLU()
        )
        self.decoder = nn.Sequential(
            nn.Linear(16, 32),
            nn.ReLU(),
            nn.Linear(32, 64),
            nn.ReLU(),
            nn.Linear(64, input_dim)
        )

    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z)

    def encode(self, x):
        return self.encoder(x)


class MLPBinaryClassifier(nn.Module):
    def __init__(self, input_dim):
        super(MLPBinaryClassifier, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.BatchNorm1d(128),
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.BatchNorm1d(64),
            nn.Dropout(0.3),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, 2)
        )

    def forward(self, x):
        return self.net(x)


# =========================================================
# 5. DATA LOADERS
# =========================================================
def make_ae_loader(X, shuffle=True):
    X_tensor = torch.tensor(X, dtype=torch.float32)
    dataset = TensorDataset(X_tensor, X_tensor)
    return DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=shuffle)


def make_supervised_loader(X, y, shuffle=True):
    X_tensor = torch.tensor(X, dtype=torch.float32)
    y_tensor = torch.tensor(y, dtype=torch.long)
    dataset = TensorDataset(X_tensor, y_tensor)
    return DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=shuffle)


# =========================================================
# 6. ENTRAINEMENT LOCAL
# =========================================================
def train_local_autoencoder(global_model, client_X, client_idx):
    local_model = copy.deepcopy(global_model).to(DEVICE)
    local_model.train()

    loader = make_ae_loader(client_X, shuffle=True)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(local_model.parameters(), lr=LEARNING_RATE_AE)

    losses = []
    for epoch_idx in range(LOCAL_EPOCHS_AE):
        running_loss = 0.0
        iterator = progress(
            loader,
            desc=f"AE Client {client_idx + 1}->E{CLIENT_EDGE_ASSIGNMENTS[client_idx] + 1} E{epoch_idx + 1}/{LOCAL_EPOCHS_AE}",
            leave=False
        )

        for batch_x, batch_target in iterator:
            batch_x = batch_x.to(DEVICE)
            batch_target = batch_target.to(DEVICE)

            optimizer.zero_grad()
            output = local_model(batch_x)
            loss = criterion(output, batch_target)

            if torch.isnan(loss):
                continue

            loss.backward()
            optimizer.step()
            running_loss += loss.item() * batch_x.size(0)

            if tqdm is not None:
                iterator.set_postfix(loss=f"{loss.item():.4f}")

        losses.append(running_loss / len(loader.dataset))

    return local_model.state_dict(), len(client_X), float(np.mean(losses))


def train_local_mlp(global_model, client_X, client_y, client_idx):
    local_model = copy.deepcopy(global_model).to(DEVICE)
    local_model.train()

    loader = make_supervised_loader(client_X, client_y, shuffle=True)

    class_counts = np.bincount(client_y, minlength=2)
    total = class_counts.sum()
    class_weights = total / (2.0 * np.maximum(class_counts, 1))
    class_weights = torch.tensor(class_weights, dtype=torch.float32).to(DEVICE)

    criterion = nn.CrossEntropyLoss(weight=class_weights)
    optimizer = optim.Adam(local_model.parameters(), lr=LEARNING_RATE_MLP)

    losses = []
    for epoch_idx in range(LOCAL_EPOCHS_MLP):
        running_loss = 0.0
        iterator = progress(
            loader,
            desc=f"MLP Client {client_idx + 1}->E{CLIENT_EDGE_ASSIGNMENTS[client_idx] + 1} E{epoch_idx + 1}/{LOCAL_EPOCHS_MLP}",
            leave=False
        )

        for batch_x, batch_y in iterator:
            batch_x = batch_x.to(DEVICE)
            batch_y = batch_y.to(DEVICE)

            optimizer.zero_grad()
            logits = local_model(batch_x)
            loss = criterion(logits, batch_y)

            if torch.isnan(loss):
                continue

            loss.backward()
            optimizer.step()
            running_loss += loss.item() * batch_x.size(0)

            if tqdm is not None:
                iterator.set_postfix(loss=f"{loss.item():.4f}")

        losses.append(running_loss / len(loader.dataset))

    return local_model.state_dict(), len(client_X), float(np.mean(losses))


# =========================================================
# 7. FEATURES AE / PREDICTION / METRIQUES
# =========================================================
def compute_reconstruction_errors(model, X):
    model.eval()
    loader = DataLoader(
        torch.tensor(X, dtype=torch.float32),
        batch_size=BATCH_SIZE,
        shuffle=False
    )

    errors = []
    with torch.no_grad():
        for batch_x in loader:
            batch_x = batch_x.to(DEVICE)
            output = model(batch_x)
            err = torch.mean((batch_x - output) ** 2, dim=1)
            errors.extend(err.cpu().numpy())

    return np.array(errors, dtype=np.float32)


def choose_auto_threshold_percentile(normal_reference_errors, validation_errors, validation_y):
    best = {
        "percentile": None,
        "threshold": None,
        "accuracy": -1.0,
        "precision": 0.0,
        "recall": 0.0,
        "f1": -1.0,
        "fpr": 1.0
    }

    for percentile in AUTO_THRESHOLD_PERCENTILES:
        threshold = float(np.percentile(normal_reference_errors, percentile))
        pred = (validation_errors > threshold).astype(np.int64)

        acc = accuracy_score(validation_y, pred)
        prec = precision_score(validation_y, pred, zero_division=0)
        rec = recall_score(validation_y, pred, zero_division=0)
        f1 = f1_score(validation_y, pred, zero_division=0)
        cm = confusion_matrix(validation_y, pred, labels=[NORMAL_LABEL, ATTACK_LABEL])
        tn, fp, fn, tp = cm.ravel()
        fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0

        better = f1 > best["f1"]
        same_f1_better_fpr = np.isclose(f1, best["f1"]) and fpr < best["fpr"]
        if better or same_f1_better_fpr:
            best = {
                "percentile": float(percentile),
                "threshold": threshold,
                "accuracy": float(acc),
                "precision": float(prec),
                "recall": float(rec),
                "f1": float(f1),
                "fpr": float(fpr)
            }

    return best


def extract_ae_features_and_detection(model, X, threshold, normal_error_std):
    model.eval()
    loader = DataLoader(
        torch.tensor(X, dtype=torch.float32),
        batch_size=BATCH_SIZE,
        shuffle=False
    )

    all_z = []
    all_errors = []

    with torch.no_grad():
        for batch_x in loader:
            batch_x = batch_x.to(DEVICE)
            z = model.encode(batch_x)
            x_hat = model(batch_x)
            err = torch.mean((batch_x - x_hat) ** 2, dim=1, keepdim=True)

            all_z.append(z.cpu().numpy())
            all_errors.append(err.cpu().numpy())

    z_all = np.vstack(all_z).astype(np.float32)
    err_all = np.vstack(all_errors).astype(np.float32)

    features = [z_all]
    if USE_RECONSTRUCTION_ERROR_AS_FEATURE:
        features.append(err_all)

    ae_pred = (err_all > threshold).astype(np.float32)
    ae_score = ((err_all - threshold) / max(normal_error_std, 1e-12)).astype(np.float32)

    if USE_AE_DECISION_AS_MLP_FEATURE:
        features.extend([ae_pred, ae_score])

    X_mlp = np.hstack(features).astype(np.float32)
    return X_mlp, err_all.ravel(), ae_pred.ravel().astype(np.int64), ae_score.ravel()


def predict_mlp(model, X):
    model.eval()
    loader = DataLoader(
        torch.tensor(X, dtype=torch.float32),
        batch_size=BATCH_SIZE,
        shuffle=False
    )

    preds = []
    probs = []
    softmax = nn.Softmax(dim=1)

    with torch.no_grad():
        for batch_x in loader:
            batch_x = batch_x.to(DEVICE)
            logits = model(batch_x)
            p = softmax(logits)
            y_pred = torch.argmax(p, dim=1)

            preds.extend(y_pred.cpu().numpy())
            probs.append(p.cpu().numpy())

    return np.array(preds), np.vstack(probs)


def evaluate_binary(name, y_true, y_pred, scores=None):
    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)

    cm = confusion_matrix(y_true, y_pred, labels=[NORMAL_LABEL, ATTACK_LABEL])
    tn, fp, fn, tp = cm.ravel()

    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    fnr = fn / (fn + tp) if (fn + tp) > 0 else 0.0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0

    try:
        auc = roc_auc_score(y_true, scores) if scores is not None else np.nan
    except Exception:
        auc = np.nan

    print(f"\n===== RESULTATS {name} =====")
    print("Accuracy              :", acc)
    print("Precision             :", prec)
    print("Recall / DetectionRate:", rec)
    print("F1-score              :", f1)
    print("Specificity           :", specificity)
    print("False Positive Rate   :", fpr)
    print("False Negative Rate   :", fnr)
    print("ROC-AUC               :", auc)
    print("\nMatrice de confusion :")
    print(cm)
    print("\nClassification report :")
    print(classification_report(
        y_true,
        y_pred,
        target_names=["Normal", "Attack"],
        digits=4,
        zero_division=0
    ))

    return {
        "accuracy": float(acc),
        "precision": float(prec),
        "recall_detection_rate": float(rec),
        "f1_score": float(f1),
        "specificity": float(specificity),
        "fpr": float(fpr),
        "fnr": float(fnr),
        "roc_auc": float(auc) if not np.isnan(auc) else np.nan,
        "tn": int(tn),
        "fp": int(fp),
        "fn": int(fn),
        "tp": int(tp)
    }


# =========================================================
# 8. CHARGEMENT + SPLIT
# =========================================================
X_df, y_all, original_labels, feature_columns = load_bot_iot_dataset(FILE_PATH)

X_train_df, X_test_df, y_train_full, y_test, labels_train, labels_test = train_test_split(
    X_df,
    y_all,
    original_labels,
    test_size=TEST_SIZE,
    random_state=RANDOM_STATE,
    stratify=y_all
)

print("\n===== SPLIT TRAIN/TEST =====")
print("Train :", X_train_df.shape)
print("Test  :", X_test_df.shape)
print("Train normal :", np.sum(y_train_full == NORMAL_LABEL))
print("Train attack :", np.sum(y_train_full == ATTACK_LABEL))
print("Test normal  :", np.sum(y_test == NORMAL_LABEL))
print("Test attack  :", np.sum(y_test == ATTACK_LABEL))

print("\n===== CONFIGURATION HFL =====")
print("NUM_CLIENTS :", NUM_CLIENTS)
print("NUM_EDGE_SERVERS :", NUM_EDGE_SERVERS)
print("CLIENT_EDGE_ASSIGNMENTS :", CLIENT_EDGE_ASSIGNMENTS)
print("CLIENT_DATA_PROPORTIONS :", CLIENT_DATA_PROPORTIONS)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train_df).astype(np.float32)
X_test_scaled = scaler.transform(X_test_df).astype(np.float32)
X_train_scaled = np.nan_to_num(X_train_scaled, nan=0.0, posinf=0.0, neginf=0.0)
X_test_scaled = np.nan_to_num(X_test_scaled, nan=0.0, posinf=0.0, neginf=0.0)

X_mlp_train_raw, X_mlp_val_raw, y_mlp_train, y_mlp_val = train_test_split(
    X_train_scaled,
    y_train_full,
    test_size=MLP_VALID_SIZE,
    random_state=RANDOM_STATE,
    stratify=y_train_full
)

X_train_normal = X_mlp_train_raw[y_mlp_train == NORMAL_LABEL]

if len(X_train_normal) == 0:
    raise ValueError("Aucune donnee normale pour entrainer l'autoencodeur.")

X_ae_train, X_ae_val = train_test_split(
    X_train_normal,
    test_size=AE_VALID_SIZE,
    random_state=RANDOM_STATE
)

print("\n===== DONNEES AUTOENCODEUR =====")
print("AE train normal :", X_ae_train.shape)
print("AE val normal   :", X_ae_val.shape)


# =========================================================
# 9. CLIENTS AE + ENTRAINEMENT HFL
# =========================================================
clients_ae = split_clients_unsupervised(X_ae_train, CLIENT_DATA_PROPORTIONS)

print("\n===== CLIENTS AE HFL NON EQUITABLES =====")
for i, client_X in enumerate(clients_ae):
    print(f"Client AE {i + 1} -> Edge {CLIENT_EDGE_ASSIGNMENTS[i] + 1}: X={client_X.shape}")

input_dim = X_train_scaled.shape[1]
global_ae = Autoencoder(input_dim).to(DEVICE)

best_ae_val_loss = float("inf")
best_ae_path = os.path.join(SAVE_FOLDER, "best_hfl_autoencoder_bot_iot.pth")

print("\n===== DEBUT ENTRAINEMENT HFL + AE =====")

for round_idx in range(GLOBAL_ROUNDS):
    print(f"\n--- Round AE HFL {round_idx + 1}/{GLOBAL_ROUNDS} ---")

    local_weights = []
    local_sizes = []
    local_losses = []

    client_iterator = progress(
        list(enumerate(clients_ae)),
        desc=f"Round AE HFL {round_idx + 1}/{GLOBAL_ROUNDS} - Clients",
        leave=True
    )

    for client_idx, client_X in client_iterator:
        weights, size, loss = train_local_autoencoder(global_ae, client_X, client_idx)
        local_weights.append(weights)
        local_sizes.append(size)
        local_losses.append(loss)

        print(
            f"Client AE {client_idx + 1} -> Edge {CLIENT_EDGE_ASSIGNMENTS[client_idx] + 1} "
            f"| size={size} | loss={loss:.6f}"
        )

    new_weights = hfl_aggregate(local_weights, local_sizes, model_name="Autoencoder")
    global_ae.load_state_dict(new_weights)

    val_errors = compute_reconstruction_errors(global_ae, X_ae_val)
    val_loss = float(np.mean(val_errors))

    print(f"Loss moyenne clients AE : {np.mean(local_losses):.6f}")
    print(f"Validation loss AE      : {val_loss:.6f}")

    if val_loss < best_ae_val_loss:
        best_ae_val_loss = val_loss
        torch.save(global_ae.state_dict(), best_ae_path)
        print(">> Meilleur AE HFL sauvegarde.")

best_ae = Autoencoder(input_dim).to(DEVICE)
best_ae.load_state_dict(torch.load(best_ae_path, map_location=DEVICE))
best_ae.eval()


# =========================================================
# 10. SEUIL AUTOMATIQUE AE + FEATURES MLP
# =========================================================
print("\n===== CHOIX AUTOMATIQUE DU SEUIL AE =====")

normal_reference_errors = compute_reconstruction_errors(best_ae, X_ae_train)
val_errors_for_threshold = compute_reconstruction_errors(best_ae, X_mlp_val_raw)

ae_threshold_info = choose_auto_threshold_percentile(
    normal_reference_errors=normal_reference_errors,
    validation_errors=val_errors_for_threshold,
    validation_y=y_mlp_val
)

AE_THRESHOLD_PERCENTILE = ae_threshold_info["percentile"]
AE_THRESHOLD = ae_threshold_info["threshold"]
AE_NORMAL_ERROR_STD = float(np.std(normal_reference_errors))

print("threshold_percentile choisi :", AE_THRESHOLD_PERCENTILE)
print("threshold AE                :", AE_THRESHOLD)
print("Validation AE Accuracy      :", ae_threshold_info["accuracy"])
print("Validation AE Precision     :", ae_threshold_info["precision"])
print("Validation AE Recall        :", ae_threshold_info["recall"])
print("Validation AE F1            :", ae_threshold_info["f1"])
print("Validation AE FPR           :", ae_threshold_info["fpr"])

print("\n===== EXTRACTION FEATURES AE POUR MLP =====")

X_mlp_train, train_errors, train_ae_pred, train_ae_score = extract_ae_features_and_detection(
    best_ae,
    X_mlp_train_raw,
    threshold=AE_THRESHOLD,
    normal_error_std=AE_NORMAL_ERROR_STD
)
X_mlp_val, val_errors, val_ae_pred, val_ae_score = extract_ae_features_and_detection(
    best_ae,
    X_mlp_val_raw,
    threshold=AE_THRESHOLD,
    normal_error_std=AE_NORMAL_ERROR_STD
)
X_test_mlp, test_errors, test_ae_pred, test_ae_score = extract_ae_features_and_detection(
    best_ae,
    X_test_scaled,
    threshold=AE_THRESHOLD,
    normal_error_std=AE_NORMAL_ERROR_STD
)

print("\n===== PERFORMANCE AE SEUL =====")
print("Train AE F1 :", f1_score(y_mlp_train, train_ae_pred, zero_division=0))
print("Val AE F1   :", f1_score(y_mlp_val, val_ae_pred, zero_division=0))
print("Val AE confusion :")
print(confusion_matrix(y_mlp_val, val_ae_pred, labels=[NORMAL_LABEL, ATTACK_LABEL]))

mlp_feature_scaler = StandardScaler()
X_mlp_train = mlp_feature_scaler.fit_transform(X_mlp_train).astype(np.float32)
X_mlp_val = mlp_feature_scaler.transform(X_mlp_val).astype(np.float32)
X_test_mlp = mlp_feature_scaler.transform(X_test_mlp).astype(np.float32)

print("X_mlp_train :", X_mlp_train.shape)
print("X_mlp_val   :", X_mlp_val.shape)
print("X_test_mlp  :", X_test_mlp.shape)


# =========================================================
# 11. CLIENTS MLP + HFL
# =========================================================
clients_mlp = split_clients_supervised(
    X_mlp_train,
    y_mlp_train,
    CLIENT_DATA_PROPORTIONS
)

print("\n===== CLIENTS MLP HFL NON EQUITABLES =====")
for i, (client_X, client_y) in enumerate(clients_mlp):
    print(
        f"Client MLP {i + 1} -> Edge {CLIENT_EDGE_ASSIGNMENTS[i] + 1}: X={client_X.shape} | "
        f"normal={np.sum(client_y == NORMAL_LABEL)} | attack={np.sum(client_y == ATTACK_LABEL)}"
    )

mlp_input_dim = X_mlp_train.shape[1]
global_mlp = MLPBinaryClassifier(mlp_input_dim).to(DEVICE)

best_mlp_val_f1 = -1.0
best_mlp_path = os.path.join(SAVE_FOLDER, "best_hfl_mlp_bot_iot.pth")

print("\n===== DEBUT ENTRAINEMENT HFL + MLP =====")

for round_idx in range(GLOBAL_ROUNDS):
    print(f"\n--- Round MLP HFL {round_idx + 1}/{GLOBAL_ROUNDS} ---")

    local_weights = []
    local_sizes = []
    local_losses = []

    client_iterator = progress(
        list(enumerate(clients_mlp)),
        desc=f"Round MLP HFL {round_idx + 1}/{GLOBAL_ROUNDS} - Clients",
        leave=True
    )

    for client_idx, (client_X, client_y) in client_iterator:
        weights, size, loss = train_local_mlp(global_mlp, client_X, client_y, client_idx)
        local_weights.append(weights)
        local_sizes.append(size)
        local_losses.append(loss)

        print(
            f"Client MLP {client_idx + 1} -> Edge {CLIENT_EDGE_ASSIGNMENTS[client_idx] + 1} "
            f"| size={size} | loss={loss:.6f}"
        )

    new_weights = hfl_aggregate(local_weights, local_sizes, model_name="MLP")
    global_mlp.load_state_dict(new_weights)

    val_pred, val_probs = predict_mlp(global_mlp, X_mlp_val)
    val_f1 = f1_score(y_mlp_val, val_pred, zero_division=0)
    val_acc = accuracy_score(y_mlp_val, val_pred)
    val_rec = recall_score(y_mlp_val, val_pred, zero_division=0)

    print(f"Loss moyenne clients MLP  : {np.mean(local_losses):.6f}")
    print(f"Validation Accuracy MLP   : {val_acc:.6f}")
    print(f"Validation Recall MLP     : {val_rec:.6f}")
    print(f"Validation F1 MLP         : {val_f1:.6f}")

    if val_f1 > best_mlp_val_f1:
        best_mlp_val_f1 = val_f1
        torch.save(global_mlp.state_dict(), best_mlp_path)
        print(">> Meilleur MLP HFL sauvegarde.")

best_mlp = MLPBinaryClassifier(mlp_input_dim).to(DEVICE)
best_mlp.load_state_dict(torch.load(best_mlp_path, map_location=DEVICE))
best_mlp.eval()


# =========================================================
# 12. TEST FINAL
# =========================================================
print("\n===== TEST FINAL AE -> MLP HFL SUR BoT-IoT =====")

test_pred, test_probs = predict_mlp(best_mlp, X_test_mlp)
test_scores = test_probs[:, 1]

ae_test_metrics = evaluate_binary(
    "AE HFL SEUL",
    y_test,
    test_ae_pred,
    scores=test_errors
)

final_metrics = evaluate_binary(
    "HFL AE -> MLP",
    y_test,
    test_pred,
    scores=test_scores
)

print("\n===== RESUME ERREURS RECONSTRUCTION TEST =====")
print(pd.Series(test_errors).describe())

print("\n===== RESUME SCORES MLP TEST =====")
print(pd.Series(test_scores).describe())


# =========================================================
# 13. SAUVEGARDE
# =========================================================
torch.save(best_ae.state_dict(), os.path.join(SAVE_FOLDER, "hfl_autoencoder_bot_iot_final.pth"))
torch.save(best_mlp.state_dict(), os.path.join(SAVE_FOLDER, "hfl_mlp_bot_iot_final.pth"))

save_object(scaler, os.path.join(SAVE_FOLDER, "scaler_bot_iot.pkl"))
save_object(mlp_feature_scaler, os.path.join(SAVE_FOLDER, "mlp_feature_scaler_bot_iot.pkl"))
save_object(feature_columns, os.path.join(SAVE_FOLDER, "feature_columns_bot_iot.pkl"))
save_object(ae_threshold_info, os.path.join(SAVE_FOLDER, "ae_threshold_info_bot_iot.pkl"))

metadata = {
    "architecture": (
        "BoT-IoT HFL + AE + MLP. AE trained with HFL on normal traffic only. "
        "AE threshold selected automatically on validation. MLP receives AE latent features, "
        "reconstruction error, AE decision and AE score. MLP trained with HFL."
    ),
    "file_path": FILE_PATH,
    "label_col": LABEL_COL,
    "normal_label": NORMAL_LABEL,
    "attack_label": ATTACK_LABEL,
    "num_clients": NUM_CLIENTS,
    "num_edge_servers": NUM_EDGE_SERVERS,
    "client_edge_assignments": CLIENT_EDGE_ASSIGNMENTS,
    "client_data_proportions": CLIENT_DATA_PROPORTIONS,
    "global_rounds": GLOBAL_ROUNDS,
    "local_epochs_ae": LOCAL_EPOCHS_AE,
    "local_epochs_mlp": LOCAL_EPOCHS_MLP,
    "batch_size": BATCH_SIZE,
    "learning_rate_ae": LEARNING_RATE_AE,
    "learning_rate_mlp": LEARNING_RATE_MLP,
    "best_ae_val_loss": best_ae_val_loss,
    "best_mlp_val_f1": best_mlp_val_f1,
    "input_dim": input_dim,
    "mlp_input_dim": mlp_input_dim,
    "ae_threshold_percentile": AE_THRESHOLD_PERCENTILE,
    "ae_threshold": AE_THRESHOLD,
    "use_reconstruction_error_as_feature": USE_RECONSTRUCTION_ERROR_AS_FEATURE,
    "use_ae_decision_as_mlp_feature": USE_AE_DECISION_AS_MLP_FEATURE
}

all_metrics = {
    "ae_test_metrics": ae_test_metrics,
    "final_hfl_ae_mlp_metrics": final_metrics,
    "ae_threshold_info": ae_threshold_info
}

save_object(metadata, os.path.join(SAVE_FOLDER, "metadata_hfl_ae_mlp_bot_iot.pkl"))
save_object(all_metrics, os.path.join(SAVE_FOLDER, "metrics_hfl_ae_mlp_bot_iot.pkl"))

results_df = pd.DataFrame({
    "label_original": labels_test,
    "y_true": y_test,
    "ae_pred": test_ae_pred,
    "mlp_pred": test_pred,
    "reconstruction_error": test_errors,
    "ae_score": test_ae_score,
    "mlp_attack_score": test_scores
})

results_path = os.path.join(SAVE_FOLDER, "detailed_predictions_hfl_ae_mlp_bot_iot.csv")
results_df.to_csv(results_path, index=False)

print("\n===== SAUVEGARDE TERMINEE =====")
print("Dossier resultats :", SAVE_FOLDER)
print("Fichier predictions :", results_path)
