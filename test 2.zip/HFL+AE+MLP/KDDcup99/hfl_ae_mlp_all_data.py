import os
import copy
import random
import joblib
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (
    confusion_matrix,
    classification_report,
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score
)

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader


# =========================================================
# 1. PARAMÈTRES
# =========================================================
# Adaptez ces chemins à votre machine
TRAIN_FILE = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/KDD cup99/kddcup.data/kddcup.data"
TEST_FILE  = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/KDD cup99/corrected/corrected"

SAVE_FOLDER = "C:/Users/anis/Desktop/M2_RMSE/Memoire/Tests/KDD/HFL_AE_MLP_ALL_DATA"
os.makedirs(SAVE_FOLDER, exist_ok=True)

NUM_CLIENTS = 5
NUM_EDGE_SERVERS = 2

CLIENT_DATA_PROPORTIONS = [0.40, 0.25, 0.18, 0.12, 0.05]
EDGE_GROUPS = [[0, 1, 2], [3, 4]]

GLOBAL_ROUNDS = 10
LOCAL_EPOCHS_AE = 5
LOCAL_EPOCHS_MLP = 5

BATCH_SIZE = 256
LEARNING_RATE_AE = 1e-3
LEARNING_RATE_MLP = 1e-3

VALID_SIZE = 0.2
RANDOM_STATE = 42

# IMPORTANT :
# binary         : MLP prédit Normal / Attack
# multiclass_all : MLP prédit normal + tous les types d'attaques connus dans le train
TASK_MODE = "binary"

USE_RECONSTRUCTION_ERROR_AS_FEATURE = True

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device utilisé :", DEVICE)

random.seed(RANDOM_STATE)
np.random.seed(RANDOM_STATE)
torch.manual_seed(RANDOM_STATE)


def validate_hfl_config():
    if len(CLIENT_DATA_PROPORTIONS) != NUM_CLIENTS:
        raise ValueError("CLIENT_DATA_PROPORTIONS doit avoir la même longueur que NUM_CLIENTS.")
    if not np.isclose(sum(CLIENT_DATA_PROPORTIONS), 1.0):
        raise ValueError("La somme de CLIENT_DATA_PROPORTIONS doit être égale à 1.0.")

    all_clients = sorted([client for group in EDGE_GROUPS for client in group])
    expected_clients = list(range(NUM_CLIENTS))
    if all_clients != expected_clients:
        raise ValueError("EDGE_GROUPS doit contenir chaque client exactement une seule fois.")

    if len(EDGE_GROUPS) != NUM_EDGE_SERVERS:
        raise ValueError("NUM_EDGE_SERVERS doit correspondre au nombre de groupes dans EDGE_GROUPS.")


validate_hfl_config()


# =========================================================
# 2. COLONNES NSL-KDD
# =========================================================
KDD_COLUMNS = [
    "duration", "protocol_type", "service", "flag", "src_bytes", "dst_bytes",
    "land", "wrong_fragment", "urgent", "hot", "num_failed_logins",
    "logged_in", "num_compromised", "root_shell", "su_attempted",
    "num_root", "num_file_creations", "num_shells", "num_access_files",
    "num_outbound_cmds", "is_host_login", "is_guest_login", "count",
    "srv_count", "serror_rate", "srv_serror_rate", "rerror_rate",
    "srv_rerror_rate", "same_srv_rate", "diff_srv_rate",
    "srv_diff_host_rate", "dst_host_count", "dst_host_srv_count",
    "dst_host_same_srv_rate", "dst_host_diff_srv_rate",
    "dst_host_same_src_port_rate", "dst_host_srv_diff_host_rate",
    "dst_host_serror_rate", "dst_host_srv_serror_rate",
    "dst_host_rerror_rate", "dst_host_srv_rerror_rate", "label", "difficulty"
]


# =========================================================
# 3. PRÉTRAITEMENT
# =========================================================
def encode_kdd_dataframe(df, feature_columns=None, scaler=None, fit=False):
    df = df.copy()
    df.columns = df.columns.str.strip()
    df["label"] = df["label"].astype(str).str.strip()

    y_binary = df["label"].apply(lambda x: 0 if x == "normal" else 1).astype(np.int64).values
    original_labels = df["label"].values

    df = df.drop(columns=["label", "difficulty"])

    categorical_cols = ["protocol_type", "service", "flag"]
    df = pd.get_dummies(df, columns=categorical_cols)

    for col in df.columns:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.replace([np.inf, -np.inf], np.nan)
    df = df.dropna(axis=1, how="all")
    df = df.fillna(df.median(numeric_only=True))
    df = df.fillna(0)

    if fit:
        constant_cols = [col for col in df.columns if df[col].nunique() <= 1]
        if constant_cols:
            df = df.drop(columns=constant_cols)
            print("Colonnes constantes supprimées :", len(constant_cols))

        feature_columns = list(df.columns)
        scaler = StandardScaler()
        X = scaler.fit_transform(df).astype(np.float32)

    else:
        missing_cols = [col for col in feature_columns if col not in df.columns]
        extra_cols = [col for col in df.columns if col not in feature_columns]

        df = df.reindex(columns=feature_columns, fill_value=0)

        print("\n===== ALIGNEMENT DATA =====")
        print("Shape après alignement :", df.shape)
        print("Colonnes manquantes ajoutées :", len(missing_cols))
        print("Colonnes extra ignorées      :", len(extra_cols))

        X = scaler.transform(df).astype(np.float32)

    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)

    return X, y_binary, original_labels, feature_columns, scaler


def load_train(file_path):
    df = pd.read_csv(file_path, names=KDD_COLUMNS)
    df.columns = df.columns.str.strip()
    df["label"] = df["label"].astype(str).str.strip()

    print("\n===== TRAIN BRUT =====")
    print("Shape train brut :", df.shape)
    print(df["label"].value_counts().head(20))

    X, y_binary, labels, feature_columns, scaler = encode_kdd_dataframe(df, fit=True)

    print("\n===== TRAIN APRÈS PRÉTRAITEMENT =====")
    print("Shape X :", X.shape)
    print("Nombre de features :", len(feature_columns))
    print("Normaux  :", np.sum(y_binary == 0))
    print("Attaques :", np.sum(y_binary == 1))

    return X, y_binary, labels, feature_columns, scaler


def load_test(file_path, feature_columns, scaler):
    df = pd.read_csv(file_path, names=KDD_COLUMNS)
    df.columns = df.columns.str.strip()
    df["label"] = df["label"].astype(str).str.strip()

    print("\n===== TEST BRUT =====")
    print("Shape test brut :", df.shape)
    print(df["label"].value_counts().head(20))

    X, y_binary, labels, _, _ = encode_kdd_dataframe(
        df,
        feature_columns=feature_columns,
        scaler=scaler,
        fit=False
    )

    return X, y_binary, labels


# =========================================================
# 4. MODÈLES
# =========================================================
class KDDAutoencoder(nn.Module):
    def __init__(self, input_dim):
        super(KDDAutoencoder, self).__init__()

        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU()
        )

        self.decoder = nn.Sequential(
            nn.Linear(64, 128),
            nn.ReLU(),
            nn.Linear(128, 256),
            nn.ReLU(),
            nn.Linear(256, input_dim)
        )

    def forward(self, x):
        z = self.encoder(x)
        x_hat = self.decoder(z)
        return x_hat

    def encode(self, x):
        return self.encoder(x)


class MLPClassifier(nn.Module):
    def __init__(self, input_dim, num_classes):
        super(MLPClassifier, self).__init__()

        self.net = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.BatchNorm1d(128),
            nn.Dropout(0.3),

            nn.Linear(128, 64),
            nn.ReLU(),
            nn.BatchNorm1d(64),
            nn.Dropout(0.3),

            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Linear(32, num_classes)
        )

    def forward(self, x):
        return self.net(x)


# =========================================================
# 5. OUTILS HFL
# =========================================================
def split_by_proportions_unsupervised(X, proportions, shuffle=True):
    if shuffle:
        indices = np.random.permutation(len(X))
        X = X[indices]

    n = len(X)
    counts = [int(n * p) for p in proportions]
    counts[-1] = n - sum(counts[:-1])

    splits = []
    start = 0
    for count in counts:
        end = start + count
        splits.append(X[start:end])
        start = end

    return splits


def split_clients_supervised_non_equal(X, y, proportions, shuffle=True):
    if shuffle:
        indices = np.random.permutation(len(X))
        X = X[indices]
        y = y[indices]

    n = len(X)
    counts = [int(n * p) for p in proportions]
    counts[-1] = n - sum(counts[:-1])

    clients = []
    start = 0
    for count in counts:
        end = start + count
        clients.append((X[start:end], y[start:end]))
        start = end

    return clients


def make_ae_loader(X, shuffle=True):
    X_tensor = torch.tensor(X, dtype=torch.float32)
    dataset = TensorDataset(X_tensor, X_tensor)
    return DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=shuffle)


def make_supervised_loader(X, y, shuffle=True):
    X_tensor = torch.tensor(X, dtype=torch.float32)
    y_tensor = torch.tensor(y, dtype=torch.long)
    dataset = TensorDataset(X_tensor, y_tensor)
    return DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=shuffle)


def weighted_average_state_dicts(state_dicts, sizes):
    total_size = sum(sizes)
    if total_size == 0:
        raise ValueError("Impossible d'agréger avec total_size = 0.")

    avg_weights = copy.deepcopy(state_dicts[0])

    for key in avg_weights.keys():
        if not torch.is_floating_point(avg_weights[key]):
            avg_weights[key] = state_dicts[0][key]
            continue

        avg_weights[key] = torch.zeros_like(avg_weights[key])
        for weights, size in zip(state_dicts, sizes):
            avg_weights[key] += weights[key] * (size / total_size)

    return avg_weights


def hfl_aggregate(local_weights, local_sizes, edge_groups):
    edge_weights = []
    edge_sizes = []

    print("\n===== AGRÉGATION HFL =====")

    for edge_idx, group in enumerate(edge_groups):
        group_weights = [local_weights[i] for i in group]
        group_sizes = [local_sizes[i] for i in group]
        edge_size = sum(group_sizes)

        edge_model_weights = weighted_average_state_dicts(group_weights, group_sizes)
        edge_weights.append(edge_model_weights)
        edge_sizes.append(edge_size)

        print(f"Edge Server {edge_idx + 1} | Clients={ [i + 1 for i in group] } | total_size={edge_size}")

    global_weights = weighted_average_state_dicts(edge_weights, edge_sizes)
    print("Global Server | Edge sizes=", edge_sizes)

    return global_weights, edge_sizes


# =========================================================
# 6. AE LOCAL + FEATURES AE
# =========================================================
def train_local_ae(global_model, client_X):
    local_model = copy.deepcopy(global_model).to(DEVICE)
    local_model.train()

    loader = make_ae_loader(client_X, shuffle=True)

    criterion = nn.MSELoss()
    optimizer = optim.Adam(local_model.parameters(), lr=LEARNING_RATE_AE)

    losses = []

    for _ in range(LOCAL_EPOCHS_AE):
        running_loss = 0.0

        for batch_x, batch_target in loader:
            batch_x = batch_x.to(DEVICE)
            batch_target = batch_target.to(DEVICE)

            optimizer.zero_grad()
            outputs = local_model(batch_x)
            loss = criterion(outputs, batch_target)

            if torch.isnan(loss):
                continue

            loss.backward()
            optimizer.step()

            running_loss += loss.item() * batch_x.size(0)

        losses.append(running_loss / len(loader.dataset))

    return local_model.state_dict(), len(client_X), float(np.mean(losses))


def compute_reconstruction_errors(model, X):
    model.eval()
    loader = DataLoader(
        torch.tensor(X, dtype=torch.float32),
        batch_size=BATCH_SIZE,
        shuffle=False
    )

    errors = []

    with torch.no_grad():
        for batch_x in loader:
            batch_x = batch_x.to(DEVICE)
            outputs = model(batch_x)
            batch_errors = torch.mean((batch_x - outputs) ** 2, dim=1)
            errors.extend(batch_errors.cpu().numpy())

    return np.array(errors)


def extract_ae_features(model, X):
    """
    Ici, TOUTES les données passent par l'AE.
    La sortie utilisée par le MLP = représentation latente z + erreur de reconstruction.
    """
    model.eval()
    loader = DataLoader(
        torch.tensor(X, dtype=torch.float32),
        batch_size=BATCH_SIZE,
        shuffle=False
    )

    all_z = []
    all_errors = []

    with torch.no_grad():
        for batch_x in loader:
            batch_x = batch_x.to(DEVICE)
            z = model.encode(batch_x)
            x_hat = model(batch_x)
            err = torch.mean((batch_x - x_hat) ** 2, dim=1, keepdim=True)

            all_z.append(z.cpu().numpy())
            all_errors.append(err.cpu().numpy())

    z_all = np.vstack(all_z).astype(np.float32)
    err_all = np.vstack(all_errors).astype(np.float32)

    if USE_RECONSTRUCTION_ERROR_AS_FEATURE:
        return np.hstack([z_all, err_all]).astype(np.float32)

    return z_all.astype(np.float32)


# =========================================================
# 7. MLP LOCAL
# =========================================================
def train_local_mlp(global_model, client_X, client_y, num_classes):
    local_model = copy.deepcopy(global_model).to(DEVICE)
    local_model.train()

    loader = make_supervised_loader(client_X, client_y, shuffle=True)

    class_counts = np.bincount(client_y, minlength=num_classes)
    total = class_counts.sum()
    class_weights = total / (num_classes * np.maximum(class_counts, 1))
    class_weights = torch.tensor(class_weights, dtype=torch.float32).to(DEVICE)

    criterion = nn.CrossEntropyLoss(weight=class_weights)
    optimizer = optim.Adam(local_model.parameters(), lr=LEARNING_RATE_MLP)

    losses = []

    for _ in range(LOCAL_EPOCHS_MLP):
        running_loss = 0.0

        for batch_x, batch_y in loader:
            batch_x = batch_x.to(DEVICE)
            batch_y = batch_y.to(DEVICE)

            optimizer.zero_grad()
            logits = local_model(batch_x)
            loss = criterion(logits, batch_y)

            if torch.isnan(loss):
                continue

            loss.backward()
            optimizer.step()

            running_loss += loss.item() * batch_x.size(0)

        losses.append(running_loss / len(loader.dataset))

    return local_model.state_dict(), len(client_X), float(np.mean(losses))


def predict_mlp(model, X):
    model.eval()
    loader = DataLoader(
        torch.tensor(X, dtype=torch.float32),
        batch_size=BATCH_SIZE,
        shuffle=False
    )

    preds = []
    probs = []
    softmax = nn.Softmax(dim=1)

    with torch.no_grad():
        for batch_x in loader:
            batch_x = batch_x.to(DEVICE)
            logits = model(batch_x)
            p = softmax(logits)
            y = torch.argmax(logits, dim=1)

            preds.extend(y.cpu().numpy())
            probs.append(p.cpu().numpy())

    return np.array(preds), np.vstack(probs)


# =========================================================
# 8. CHARGEMENT DATA
# =========================================================
print("\nChargement et préparation du train...")
X_all, y_binary_all, train_original_labels, feature_columns, scaler = load_train(TRAIN_FILE)

if TASK_MODE == "binary":
    y_all = y_binary_all
    label_encoder = None
    class_names = ["normal", "attack"]
else:
    label_encoder = LabelEncoder()
    y_all = label_encoder.fit_transform(train_original_labels)
    class_names = list(label_encoder.classes_)

print("\n===== MODE DE CLASSIFICATION =====")
print("TASK_MODE :", TASK_MODE)
print("Classes :", class_names)
print("Nombre de classes :", len(class_names))

X_train_full, X_val_full, y_train, y_val, labels_train, labels_val, y_train_binary, y_val_binary = train_test_split(
    X_all,
    y_all,
    train_original_labels,
    y_binary_all,
    test_size=VALID_SIZE,
    random_state=RANDOM_STATE,
    stratify=y_all
)

print("\n===== SPLIT TRAIN/VALIDATION =====")
print("Train shape      :", X_train_full.shape)
print("Validation shape :", X_val_full.shape)
print("Train normaux    :", np.sum(y_train_binary == 0))
print("Train attaques   :", np.sum(y_train_binary == 1))
print("Val normaux      :", np.sum(y_val_binary == 0))
print("Val attaques     :", np.sum(y_val_binary == 1))

print("\n===== CONFIGURATION HFL =====")
print("Nombre de clients      :", NUM_CLIENTS)
print("Nombre de Edge servers :", NUM_EDGE_SERVERS)
print("Proportions clients    :", CLIENT_DATA_PROPORTIONS)
print("Groupes Edge           :", [[c + 1 for c in group] for group in EDGE_GROUPS])


# =========================================================
# 9. ÉTAPE 1 : HFL + AE SUR TOUTES LES DONNÉES TRAIN
# =========================================================
clients_ae = split_by_proportions_unsupervised(
    X_train_full,
    CLIENT_DATA_PROPORTIONS,
    shuffle=True
)

print("\n===== CLIENTS AE - TOUTES LES DONNÉES =====")
for i, client_X in enumerate(clients_ae):
    print(f"Client AE {i + 1}: X={client_X.shape}")

input_dim = X_train_full.shape[1]
global_ae = KDDAutoencoder(input_dim).to(DEVICE)

best_ae_val_loss = float("inf")
best_ae_path = os.path.join(SAVE_FOLDER, "best_hfl_autoencoder_all_data.pth")

print("\n===== DÉBUT ENTRAÎNEMENT HFL + AE =====")

for round_idx in range(GLOBAL_ROUNDS):
    local_weights = []
    local_sizes = []
    local_losses = []

    print(f"\n--- Round AE {round_idx + 1}/{GLOBAL_ROUNDS} ---")

    for client_idx, client_X in enumerate(clients_ae):
        weights, size, loss = train_local_ae(global_ae, client_X)
        local_weights.append(weights)
        local_sizes.append(size)
        local_losses.append(loss)
        print(f"Client {client_idx + 1} | size={size} | loss={loss:.6f}")

    new_weights, edge_sizes_ae = hfl_aggregate(
        local_weights=local_weights,
        local_sizes=local_sizes,
        edge_groups=EDGE_GROUPS
    )
    global_ae.load_state_dict(new_weights)

    val_errors = compute_reconstruction_errors(global_ae, X_val_full)
    val_loss = float(np.mean(val_errors))

    print(f"Loss moyenne clients AE   : {np.mean(local_losses):.6f}")
    print(f"Validation AE loss totale : {val_loss:.6f}")

    if val_loss < best_ae_val_loss:
        best_ae_val_loss = val_loss
        torch.save(global_ae.state_dict(), best_ae_path)
        print(">> Meilleur AE sauvegardé.")

best_ae = KDDAutoencoder(input_dim).to(DEVICE)
best_ae.load_state_dict(torch.load(best_ae_path, map_location=DEVICE))
best_ae.eval()


# =========================================================
# 10. ÉTAPE 2 : EXTRACTION FEATURES AE POUR TOUTES LES DONNÉES
# =========================================================
print("\n===== EXTRACTION FEATURES AE POUR TOUT LE TRAIN/VAL =====")

X_train_mlp = extract_ae_features(best_ae, X_train_full)
X_val_mlp = extract_ae_features(best_ae, X_val_full)

mlp_feature_scaler = StandardScaler()
X_train_mlp = mlp_feature_scaler.fit_transform(X_train_mlp).astype(np.float32)
X_val_mlp = mlp_feature_scaler.transform(X_val_mlp).astype(np.float32)

print("X_train_mlp :", X_train_mlp.shape)
print("X_val_mlp   :", X_val_mlp.shape)


# =========================================================
# 11. ÉTAPE 3 : HFL + MLP SUR TOUTES LES DONNÉES
# =========================================================
clients_mlp = split_clients_supervised_non_equal(
    X_train_mlp,
    y_train,
    CLIENT_DATA_PROPORTIONS,
    shuffle=True
)

print("\n===== CLIENTS MLP - TOUTES LES DONNÉES =====")
for i, (client_X, client_y) in enumerate(clients_mlp):
    print(f"\nClient MLP {i + 1}: X={client_X.shape}")
    print(pd.Series(client_y).value_counts().sort_index())

mlp_input_dim = X_train_mlp.shape[1]
num_classes = len(class_names)
global_mlp = MLPClassifier(mlp_input_dim, num_classes).to(DEVICE)

best_val_f1 = -1.0
best_mlp_path = os.path.join(SAVE_FOLDER, "best_hfl_mlp_all_data.pth")

print("\n===== DÉBUT ENTRAÎNEMENT HFL + MLP =====")

for round_idx in range(GLOBAL_ROUNDS):
    local_weights = []
    local_sizes = []
    local_losses = []

    print(f"\n--- Round MLP {round_idx + 1}/{GLOBAL_ROUNDS} ---")

    for client_idx, (client_X, client_y) in enumerate(clients_mlp):
        weights, size, loss = train_local_mlp(global_mlp, client_X, client_y, num_classes)
        local_weights.append(weights)
        local_sizes.append(size)
        local_losses.append(loss)
        print(f"Client {client_idx + 1} | size={size} | loss={loss:.6f}")

    new_weights, edge_sizes_mlp = hfl_aggregate(
        local_weights=local_weights,
        local_sizes=local_sizes,
        edge_groups=EDGE_GROUPS
    )
    global_mlp.load_state_dict(new_weights)

    val_pred, val_probs = predict_mlp(global_mlp, X_val_mlp)
    val_f1 = f1_score(y_val, val_pred, average="macro", zero_division=0)
    val_acc = accuracy_score(y_val, val_pred)

    print(f"Loss moyenne clients MLP : {np.mean(local_losses):.6f}")
    print(f"Validation Accuracy      : {val_acc:.6f}")
    print(f"Validation Macro-F1      : {val_f1:.6f}")

    if val_f1 > best_val_f1:
        best_val_f1 = val_f1
        torch.save(global_mlp.state_dict(), best_mlp_path)
        print(">> Meilleur MLP sauvegardé.")

best_mlp = MLPClassifier(mlp_input_dim, num_classes).to(DEVICE)
best_mlp.load_state_dict(torch.load(best_mlp_path, map_location=DEVICE))
best_mlp.eval()


# =========================================================
# 12. TEST FINAL : INPUT -> AE -> FEATURES AE -> MLP
# =========================================================
print("\nChargement et préparation du test...")
X_test, y_test_binary, original_labels_test = load_test(TEST_FILE, feature_columns, scaler)

if TASK_MODE == "binary":
    y_test = y_test_binary
else:
    known_mask = np.array([lab in set(label_encoder.classes_) for lab in original_labels_test])
    X_test = X_test[known_mask]
    y_test_binary = y_test_binary[known_mask]
    original_labels_test = original_labels_test[known_mask]
    y_test = label_encoder.transform(original_labels_test)

print("\n===== PIPELINE FINAL =====")
print("Toutes les données test passent vers l'AE, puis vers le MLP.")
print("X_test :", X_test.shape)

X_test_mlp = extract_ae_features(best_ae, X_test)
X_test_mlp = mlp_feature_scaler.transform(X_test_mlp).astype(np.float32)

test_pred, test_probs = predict_mlp(best_mlp, X_test_mlp)

if TASK_MODE == "binary":
    y_pred_binary = test_pred
else:
    pred_labels = label_encoder.inverse_transform(test_pred)
    y_pred_binary = np.where(pred_labels == "normal", 0, 1)

test_confidence = np.max(test_probs, axis=1)
test_errors = compute_reconstruction_errors(best_ae, X_test)


# =========================================================
# 13. MÉTRIQUES
# =========================================================
print("\n===== RÉSULTATS GLOBAUX MLP =====")
print("Accuracy :", accuracy_score(y_test, test_pred))
print("Macro-F1 :", f1_score(y_test, test_pred, average="macro", zero_division=0))

print("\n===== CLASSIFICATION REPORT =====")
print(classification_report(
    y_test,
    test_pred,
    target_names=class_names,
    digits=4,
    zero_division=0
))

if TASK_MODE == "binary":
    acc = accuracy_score(y_test_binary, y_pred_binary)
    prec = precision_score(y_test_binary, y_pred_binary, zero_division=0)
    rec = recall_score(y_test_binary, y_pred_binary, zero_division=0)
    f1 = f1_score(y_test_binary, y_pred_binary, zero_division=0)

    cm = confusion_matrix(y_test_binary, y_pred_binary, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()

    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    fnr = fn / (fn + tp) if (fn + tp) > 0 else 0.0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0

    try:
        roc_auc = roc_auc_score(y_test_binary, test_probs[:, 1])
    except Exception:
        roc_auc = np.nan

    print("\n===== MÉTRIQUES BINAIRES TEST =====")
    print("Accuracy              :", acc)
    print("Precision             :", prec)
    print("Recall / DetectionRate:", rec)
    print("F1-score              :", f1)
    print("Specificity           :", specificity)
    print("False Positive Rate   :", fpr)
    print("False Negative Rate   :", fnr)
    print("ROC-AUC MLP prob      :", roc_auc)
    print("\nMatrice de confusion :")
    print(cm)

else:
    acc = accuracy_score(y_test_binary, y_pred_binary)
    prec = precision_score(y_test_binary, y_pred_binary, zero_division=0)
    rec = recall_score(y_test_binary, y_pred_binary, zero_division=0)
    f1 = f1_score(y_test_binary, y_pred_binary, zero_division=0)
    cm = confusion_matrix(y_test_binary, y_pred_binary, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()

    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    fnr = fn / (fn + tp) if (fn + tp) > 0 else 0.0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    roc_auc = np.nan

    print("\n===== MÉTRIQUES BINAIRES DÉRIVÉES DU MULTICLASSE =====")
    print("Accuracy              :", acc)
    print("Precision             :", prec)
    print("Recall / DetectionRate:", rec)
    print("F1-score              :", f1)
    print("Specificity           :", specificity)
    print("False Positive Rate   :", fpr)
    print("False Negative Rate   :", fnr)
    print("\nMatrice de confusion binaire :")
    print(cm)


# =========================================================
# 14. SAUVEGARDE
# =========================================================
if TASK_MODE == "binary":
    final_pred_label = np.where(test_pred == 0, "normal", "attack")
    y_true_label = np.where(y_test == 0, "normal", "attack")
else:
    final_pred_label = label_encoder.inverse_transform(test_pred)
    y_true_label = original_labels_test

results_df = pd.DataFrame({
    "label_original": original_labels_test,
    "y_true_label": y_true_label,
    "predicted_label": final_pred_label,
    "y_true_binary": y_test_binary,
    "predicted_binary": y_pred_binary,
    "reconstruction_error": test_errors,
    "mlp_confidence": test_confidence
})

results_path = os.path.join(SAVE_FOLDER, "results_test_hfl_ae_mlp_all_data.csv")
results_df.to_csv(results_path, index=False)

metrics = {
    "task_mode": TASK_MODE,
    "global_accuracy": accuracy_score(y_test, test_pred),
    "global_macro_f1": f1_score(y_test, test_pred, average="macro", zero_division=0),
    "binary_accuracy": acc,
    "binary_precision": prec,
    "binary_recall_detection_rate": rec,
    "binary_f1_score": f1,
    "binary_specificity": specificity,
    "binary_fpr": fpr,
    "binary_fnr": fnr,
    "binary_roc_auc": roc_auc,
    "best_ae_val_loss": best_ae_val_loss,
    "best_mlp_val_macro_f1": best_val_f1,
    "tn": int(tn),
    "fp": int(fp),
    "fn": int(fn),
    "tp": int(tp)
}

metadata = {
    "architecture": "HFL: clients -> edge servers -> global server ; Input -> AE -> latent features + reconstruction error -> MLP ; all samples pass to MLP",
    "input_dim": input_dim,
    "mlp_input_dim": mlp_input_dim,
    "num_classes": num_classes,
    "class_names": class_names,
    "num_clients": NUM_CLIENTS,
    "num_edge_servers": NUM_EDGE_SERVERS,
    "edge_groups": [[c + 1 for c in group] for group in EDGE_GROUPS],
    "client_data_proportions": CLIENT_DATA_PROPORTIONS,
    "global_rounds": GLOBAL_ROUNDS,
    "local_epochs_ae": LOCAL_EPOCHS_AE,
    "local_epochs_mlp": LOCAL_EPOCHS_MLP,
    "batch_size": BATCH_SIZE,
    "learning_rate_ae": LEARNING_RATE_AE,
    "learning_rate_mlp": LEARNING_RATE_MLP,
    "use_reconstruction_error_as_feature": USE_RECONSTRUCTION_ERROR_AS_FEATURE
}

joblib.dump(scaler, os.path.join(SAVE_FOLDER, "scaler_kdd.pkl"))
joblib.dump(mlp_feature_scaler, os.path.join(SAVE_FOLDER, "mlp_feature_scaler.pkl"))
joblib.dump(feature_columns, os.path.join(SAVE_FOLDER, "feature_columns_kdd.pkl"))
joblib.dump(metrics, os.path.join(SAVE_FOLDER, "metrics_hfl_ae_mlp_all_data.pkl"))
joblib.dump(metadata, os.path.join(SAVE_FOLDER, "metadata_hfl_ae_mlp_all_data.pkl"))

if label_encoder is not None:
    joblib.dump(label_encoder, os.path.join(SAVE_FOLDER, "label_encoder.pkl"))

torch.save(best_ae.state_dict(), os.path.join(SAVE_FOLDER, "final_hfl_autoencoder_all_data.pth"))
torch.save(best_mlp.state_dict(), os.path.join(SAVE_FOLDER, "final_hfl_mlp_all_data.pth"))

print("\n===== SAUVEGARDE TERMINÉE =====")
print("Dossier résultats :", SAVE_FOLDER)
print("Fichier résultats :", results_path)
