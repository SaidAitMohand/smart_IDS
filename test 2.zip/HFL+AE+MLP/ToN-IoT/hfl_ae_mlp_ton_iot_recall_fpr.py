import os
import copy
import random
import pickle
import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    fbeta_score,
    confusion_matrix,
    classification_report,
    roc_auc_score,
)

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader

try:
    import joblib
except Exception:
    joblib = None

try:
    from tqdm.auto import tqdm
except Exception:
    tqdm = None


# =========================================================
# 1. PARAMETRES ToN-IoT
# =========================================================
DATA_FILE = "C:/Users/anis/Desktop/M2_RMSE/Memoire/DataSets/TON_IoT/train_test_network.csv"
SAVE_FOLDER = "C:/Users/anis/Desktop/M2_RMSE/Memoire/Tests/TON_IoT/HFL_AE_MLP_RECALL_FPR"
os.makedirs(SAVE_FOLDER, exist_ok=True)

LABEL_CANDIDATES = ["label", "Label", "target", "Target", "class", "Class", "attack", "Attack"]
NORMAL_TEXT_VALUES = {"normal", "benign", "legitimate", "0", "false", "no"}

TEST_SIZE = 0.30
VALID_SIZE = 0.20
AE_VALID_SIZE = 0.20

NUM_CLIENTS = 5
CLIENT_DATA_PROPORTIONS = [0.40, 0.25, 0.18, 0.12, 0.05]

# HFL = clients -> edge servers -> serveur global
NUM_EDGE_SERVERS = 2
CLIENT_EDGE_ASSIGNMENTS = [0, 0, 1, 1, 1]

GLOBAL_ROUNDS = 10
LOCAL_EPOCHS_AE = 5
LOCAL_EPOCHS_MLP = 8

BATCH_SIZE = 512
LEARNING_RATE_AE = 1e-3
LEARNING_RATE_MLP = 8e-4
WEIGHT_DECAY_MLP = 1e-4

RANDOM_STATE = 42

AUTO_THRESHOLD_PERCENTILES = np.concatenate([
    np.arange(80.0, 99.0, 0.5),
    np.arange(99.0, 99.95, 0.05),
])

MAX_ALLOWED_FPR = 0.08
MLP_THRESHOLD_GRID = np.arange(0.01, 0.96, 0.01)

MAX_CATEGORICAL_UNIQUE = 60

USE_FOCAL_LOSS = True
FOCAL_GAMMA = 2.0
ATTACK_CLASS_WEIGHT_MULTIPLIER = 1.7

USE_RECONSTRUCTION_ERROR_AS_FEATURE = True
USE_AE_DECISION_AS_MLP_FEATURE = True

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device utilise :", DEVICE)

random.seed(RANDOM_STATE)
np.random.seed(RANDOM_STATE)
torch.manual_seed(RANDOM_STATE)


def progress(iterable, **kwargs):
    if tqdm is None:
        return iterable
    kwargs.setdefault("dynamic_ncols", True)
    return tqdm(iterable, **kwargs)


def save_object(obj, path):
    if joblib is not None:
        joblib.dump(obj, path)
        return
    with open(path, "wb") as file:
        pickle.dump(obj, file)


def validate_config():
    if len(CLIENT_DATA_PROPORTIONS) != NUM_CLIENTS:
        raise ValueError("CLIENT_DATA_PROPORTIONS doit avoir la meme longueur que NUM_CLIENTS.")
    if not np.isclose(sum(CLIENT_DATA_PROPORTIONS), 1.0):
        raise ValueError("La somme de CLIENT_DATA_PROPORTIONS doit etre egale a 1.0.")
    if len(CLIENT_EDGE_ASSIGNMENTS) != NUM_CLIENTS:
        raise ValueError("CLIENT_EDGE_ASSIGNMENTS doit avoir la meme longueur que NUM_CLIENTS.")
    if min(CLIENT_EDGE_ASSIGNMENTS) < 0 or max(CLIENT_EDGE_ASSIGNMENTS) >= NUM_EDGE_SERVERS:
        raise ValueError("Chaque edge id doit etre entre 0 et NUM_EDGE_SERVERS - 1.")


validate_config()


# =========================================================
# 2. CHARGEMENT + LABELS
# =========================================================
def find_label_column(df):
    for col in LABEL_CANDIDATES:
        if col in df.columns:
            return col
    raise ValueError(f"Aucune colonne label trouvee. Colonnes disponibles : {list(df.columns)}")


def encode_binary_labels(series):
    if pd.api.types.is_numeric_dtype(series):
        return series.fillna(0).astype(int).values
    values = series.astype(str).str.strip().str.lower()
    return values.apply(lambda x: 0 if x in NORMAL_TEXT_VALUES else 1).astype(int).values


def load_ton_iot_dataset(file_path):
    df = pd.read_csv(file_path, low_memory=False)
    df.columns = df.columns.str.strip()

    label_col = find_label_column(df)
    y = encode_binary_labels(df[label_col])
    original_labels = df[label_col].values

    print("\n===== DATASET BRUT ToN-IoT =====")
    print("Fichier :", file_path)
    print("Shape :", df.shape)
    print("Colonne label :", label_col)
    print("\n===== DISTRIBUTION LABELS BINAIRES =====")
    print(pd.Series(y).value_counts().sort_index())

    return df, y, original_labels, label_col


# =========================================================
# 3. PRETRAITEMENT ROBUSTE
# =========================================================
DROP_ALWAYS = {
    "type", "Type", "attack_cat", "Attack_cat", "category", "Category",
    "subcategory", "Subcategory", "ts", "time", "timestamp", "Timestamp",
    "src_ip", "dst_ip", "srcip", "dstip", "Source IP", "Destination IP",
    "Flow ID", "flow_id", "uid", "id", "Unnamed: 0",
    "http_uri", "http_user_agent", "dns_query", "ssl_subject", "ssl_issuer",
}


def _base_feature_frame(df, label_col):
    work = df.copy()
    work.columns = work.columns.str.strip()
    drop_cols = [c for c in work.columns if c in DROP_ALWAYS or c == label_col]
    work = work.drop(columns=drop_cols, errors="ignore")
    work = work.replace([np.inf, -np.inf], np.nan)
    return work


def preprocess_fit(df, label_col):
    work = _base_feature_frame(df, label_col)

    numeric_cols = list(work.select_dtypes(include=[np.number]).columns)
    object_cols = [c for c in work.columns if c not in numeric_cols]

    categorical_cols = []
    dropped_high_cardinality = []
    for col in object_cols:
        nunique = work[col].astype(str).nunique(dropna=True)
        if nunique <= MAX_CATEGORICAL_UNIQUE:
            categorical_cols.append(col)
        else:
            dropped_high_cardinality.append(col)

    num_df = work[numeric_cols].copy()
    for col in numeric_cols:
        num_df[col] = pd.to_numeric(num_df[col], errors="coerce")
    num_df = num_df.replace([np.inf, -np.inf], np.nan)
    medians = num_df.median(numeric_only=True)
    num_df = num_df.fillna(medians).fillna(0)

    if categorical_cols:
        cat_df = pd.get_dummies(work[categorical_cols].astype(str).fillna("missing"), columns=categorical_cols)
    else:
        cat_df = pd.DataFrame(index=work.index)

    X_df = pd.concat([num_df, cat_df], axis=1).replace([np.inf, -np.inf], np.nan).fillna(0)

    constant_cols = [col for col in X_df.columns if X_df[col].nunique() <= 1]
    if constant_cols:
        X_df = X_df.drop(columns=constant_cols)

    feature_columns = list(X_df.columns)
    scaler = StandardScaler()
    X = scaler.fit_transform(X_df).astype(np.float32)
    X = np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)

    preprocessor = {
        "label_col": label_col,
        "numeric_cols": numeric_cols,
        "categorical_cols": categorical_cols,
        "dropped_high_cardinality": dropped_high_cardinality,
        "medians": medians,
        "feature_columns": feature_columns,
        "scaler": scaler,
        "constant_cols": constant_cols,
    }

    print("\n===== PRETRAITEMENT FIT =====")
    print("Features finales :", len(feature_columns))
    print("Colonnes numeriques :", len(numeric_cols))
    print("Colonnes categorielles encodees :", len(categorical_cols))
    print("Colonnes haute cardinalite supprimees :", len(dropped_high_cardinality))
    print("Colonnes constantes supprimees :", len(constant_cols))
    return X, preprocessor


def preprocess_transform(df, preprocessor):
    label_col = preprocessor["label_col"]
    numeric_cols = preprocessor["numeric_cols"]
    categorical_cols = preprocessor["categorical_cols"]
    medians = preprocessor["medians"]
    feature_columns = preprocessor["feature_columns"]
    scaler = preprocessor["scaler"]

    work = _base_feature_frame(df, label_col)

    num_df = pd.DataFrame(index=work.index)
    for col in numeric_cols:
        if col in work.columns:
            num_df[col] = pd.to_numeric(work[col], errors="coerce")
        else:
            num_df[col] = 0
    num_df = num_df.replace([np.inf, -np.inf], np.nan).fillna(medians).fillna(0)

    if categorical_cols:
        cat_base = pd.DataFrame(index=work.index)
        for col in categorical_cols:
            cat_base[col] = work[col].astype(str).fillna("missing") if col in work.columns else "missing"
        cat_df = pd.get_dummies(cat_base, columns=categorical_cols)
    else:
        cat_df = pd.DataFrame(index=work.index)

    X_df = pd.concat([num_df, cat_df], axis=1)
    X_df = X_df.reindex(columns=feature_columns, fill_value=0).replace([np.inf, -np.inf], np.nan).fillna(0)
    X = scaler.transform(X_df).astype(np.float32)
    return np.nan_to_num(X, nan=0.0, posinf=0.0, neginf=0.0)


# =========================================================
# 4. MODELES
# =========================================================
class Autoencoder(nn.Module):
    def __init__(self, input_dim):
        super(Autoencoder, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, 64),
            nn.ReLU(),
        )
        self.decoder = nn.Sequential(
            nn.Linear(64, 128),
            nn.ReLU(),
            nn.Linear(128, 256),
            nn.ReLU(),
            nn.Linear(256, input_dim),
        )

    def forward(self, x):
        z = self.encoder(x)
        return self.decoder(z)

    def encode(self, x):
        return self.encoder(x)


class MLPBinaryClassifier(nn.Module):
    def __init__(self, input_dim):
        super(MLPBinaryClassifier, self).__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.ReLU(),
            nn.BatchNorm1d(256),
            nn.Dropout(0.4),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.BatchNorm1d(128),
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.BatchNorm1d(64),
            nn.Dropout(0.2),
            nn.Linear(64, 2),
        )

    def forward(self, x):
        return self.net(x)


class FocalLoss(nn.Module):
    def __init__(self, weight=None, gamma=2.0):
        super(FocalLoss, self).__init__()
        self.weight = weight
        self.gamma = gamma

    def forward(self, logits, targets):
        ce = nn.functional.cross_entropy(logits, targets, weight=self.weight, reduction="none")
        pt = torch.exp(-ce)
        return (((1 - pt) ** self.gamma) * ce).mean()


# =========================================================
# 5. DATA LOADERS / SPLIT / HFL
# =========================================================
def make_ae_loader(X, shuffle=True):
    X_tensor = torch.tensor(X, dtype=torch.float32)
    dataset = TensorDataset(X_tensor, X_tensor)
    return DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=shuffle)


def make_supervised_loader(X, y, shuffle=True):
    X_tensor = torch.tensor(X, dtype=torch.float32)
    y_tensor = torch.tensor(y, dtype=torch.long)
    dataset = TensorDataset(X_tensor, y_tensor)
    return DataLoader(dataset, batch_size=BATCH_SIZE, shuffle=shuffle)


def split_clients_unsupervised(X, proportions):
    indices = np.random.permutation(len(X))
    X = X[indices]
    counts = [int(len(X) * p) for p in proportions]
    counts[-1] = len(X) - sum(counts[:-1])
    clients = []
    start = 0
    for count in counts:
        end = start + count
        clients.append(X[start:end])
        start = end
    return clients


def split_clients_supervised(X, y, proportions):
    indices = np.random.permutation(len(X))
    X = X[indices]
    y = y[indices]
    counts = [int(len(X) * p) for p in proportions]
    counts[-1] = len(X) - sum(counts[:-1])
    clients = []
    start = 0
    for count in counts:
        end = start + count
        clients.append((X[start:end], y[start:end]))
        start = end
    return clients


def weighted_average_state_dicts(state_dicts, sizes):
    total_size = sum(sizes)
    if total_size == 0:
        raise ValueError("Impossible d'agreger avec total_size = 0.")
    avg_state = copy.deepcopy(state_dicts[0])
    for key in avg_state.keys():
        if not torch.is_floating_point(avg_state[key]):
            avg_state[key] = state_dicts[0][key]
            continue
        avg_state[key] = torch.zeros_like(avg_state[key])
        for state, size in zip(state_dicts, sizes):
            avg_state[key] += state[key] * (size / total_size)
    return avg_state


def hfl_aggregate(local_weights, local_sizes, model_name):
    print(f"\n===== AGREGATION HFL : {model_name} =====")
    edge_weights, edge_sizes = [], []
    for edge_id in range(NUM_EDGE_SERVERS):
        client_ids = [
            i for i, assigned_edge in enumerate(CLIENT_EDGE_ASSIGNMENTS)
            if assigned_edge == edge_id and local_sizes[i] > 0
        ]
        if not client_ids:
            print(f"Edge {edge_id + 1}: aucun client actif.")
            continue
        edge_state = weighted_average_state_dicts(
            [local_weights[i] for i in client_ids],
            [local_sizes[i] for i in client_ids],
        )
        edge_size = sum(local_sizes[i] for i in client_ids)
        edge_weights.append(edge_state)
        edge_sizes.append(edge_size)
        print(f"Edge {edge_id + 1}: clients={[i + 1 for i in client_ids]} | total_size={edge_size}")
    global_state = weighted_average_state_dicts(edge_weights, edge_sizes)
    print("Serveur global: tailles edges =", edge_sizes)
    return global_state


# =========================================================
# 6. ENTRAINEMENT LOCAL
# =========================================================
def train_local_autoencoder(global_model, client_X, client_idx):
    local_model = copy.deepcopy(global_model).to(DEVICE)
    local_model.train()
    loader = make_ae_loader(client_X, shuffle=True)
    criterion = nn.MSELoss()
    optimizer = optim.Adam(local_model.parameters(), lr=LEARNING_RATE_AE)
    losses = []
    for epoch_idx in range(LOCAL_EPOCHS_AE):
        running_loss = 0.0
        iterator = progress(
            loader,
            desc=f"AE Client {client_idx + 1}->E{CLIENT_EDGE_ASSIGNMENTS[client_idx] + 1} E{epoch_idx + 1}/{LOCAL_EPOCHS_AE}",
            leave=False,
        )
        for batch_x, batch_target in iterator:
            batch_x = batch_x.to(DEVICE)
            batch_target = batch_target.to(DEVICE)
            optimizer.zero_grad()
            output = local_model(batch_x)
            loss = criterion(output, batch_target)
            if torch.isnan(loss):
                continue
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * batch_x.size(0)
            if tqdm is not None:
                iterator.set_postfix(loss=f"{loss.item():.4f}")
        losses.append(running_loss / len(loader.dataset))
    return local_model.state_dict(), len(client_X), float(np.mean(losses))


def make_class_weights(y):
    class_counts = np.bincount(y, minlength=2)
    total = class_counts.sum()
    weights = total / (2.0 * np.maximum(class_counts, 1))
    weights[1] *= ATTACK_CLASS_WEIGHT_MULTIPLIER
    return torch.tensor(weights, dtype=torch.float32).to(DEVICE)


def train_local_mlp(global_model, client_X, client_y, client_idx):
    local_model = copy.deepcopy(global_model).to(DEVICE)
    local_model.train()
    loader = make_supervised_loader(client_X, client_y, shuffle=True)
    class_weights = make_class_weights(client_y)
    criterion = FocalLoss(weight=class_weights, gamma=FOCAL_GAMMA) if USE_FOCAL_LOSS else nn.CrossEntropyLoss(weight=class_weights)
    optimizer = optim.Adam(local_model.parameters(), lr=LEARNING_RATE_MLP, weight_decay=WEIGHT_DECAY_MLP)
    losses = []
    for epoch_idx in range(LOCAL_EPOCHS_MLP):
        running_loss = 0.0
        iterator = progress(
            loader,
            desc=f"MLP Client {client_idx + 1}->E{CLIENT_EDGE_ASSIGNMENTS[client_idx] + 1} E{epoch_idx + 1}/{LOCAL_EPOCHS_MLP}",
            leave=False,
        )
        for batch_x, batch_y in iterator:
            batch_x = batch_x.to(DEVICE)
            batch_y = batch_y.to(DEVICE)
            optimizer.zero_grad()
            logits = local_model(batch_x)
            loss = criterion(logits, batch_y)
            if torch.isnan(loss):
                continue
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * batch_x.size(0)
            if tqdm is not None:
                iterator.set_postfix(loss=f"{loss.item():.4f}")
        losses.append(running_loss / len(loader.dataset))
    return local_model.state_dict(), len(client_X), float(np.mean(losses))


# =========================================================
# 7. FEATURES AE / SEUILS / EVALUATION
# =========================================================
def compute_reconstruction_errors(model, X):
    model.eval()
    loader = DataLoader(torch.tensor(X, dtype=torch.float32), batch_size=BATCH_SIZE, shuffle=False)
    errors = []
    with torch.no_grad():
        for batch_x in loader:
            batch_x = batch_x.to(DEVICE)
            output = model(batch_x)
            err = torch.mean((batch_x - output) ** 2, dim=1)
            errors.extend(err.cpu().numpy())
    return np.array(errors, dtype=np.float32)


def choose_auto_threshold_percentile(normal_reference_errors, validation_errors, validation_y):
    best = {"percentile": None, "threshold": None, "accuracy": -1.0, "precision": 0.0, "recall": 0.0, "f1": -1.0, "fpr": 1.0}
    for percentile in AUTO_THRESHOLD_PERCENTILES:
        threshold = float(np.percentile(normal_reference_errors, percentile))
        pred = (validation_errors > threshold).astype(np.int64)
        acc = accuracy_score(validation_y, pred)
        prec = precision_score(validation_y, pred, zero_division=0)
        rec = recall_score(validation_y, pred, zero_division=0)
        f1 = f1_score(validation_y, pred, zero_division=0)
        tn, fp, fn, tp = confusion_matrix(validation_y, pred, labels=[0, 1]).ravel()
        fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
        better = f1 > best["f1"]
        same_f1_better_fpr = np.isclose(f1, best["f1"]) and fpr < best["fpr"]
        if better or same_f1_better_fpr:
            best = {"percentile": float(percentile), "threshold": threshold, "accuracy": float(acc), "precision": float(prec), "recall": float(rec), "f1": float(f1), "fpr": float(fpr)}
    return best


def extract_ae_features_and_detection(model, X, threshold, normal_error_std):
    model.eval()
    loader = DataLoader(torch.tensor(X, dtype=torch.float32), batch_size=BATCH_SIZE, shuffle=False)
    all_z, all_errors = [], []
    with torch.no_grad():
        for batch_x in loader:
            batch_x = batch_x.to(DEVICE)
            z = model.encode(batch_x)
            x_hat = model(batch_x)
            err = torch.mean((batch_x - x_hat) ** 2, dim=1, keepdim=True)
            all_z.append(z.cpu().numpy())
            all_errors.append(err.cpu().numpy())
    z_all = np.vstack(all_z).astype(np.float32)
    err_all = np.vstack(all_errors).astype(np.float32)
    features = [z_all]
    if USE_RECONSTRUCTION_ERROR_AS_FEATURE:
        features.append(err_all)
    ae_pred = (err_all > threshold).astype(np.float32)
    ae_score = ((err_all - threshold) / max(normal_error_std, 1e-12)).astype(np.float32)
    if USE_AE_DECISION_AS_MLP_FEATURE:
        features.extend([ae_pred, ae_score])
    X_mlp = np.hstack(features).astype(np.float32)
    return X_mlp, err_all.ravel(), ae_pred.ravel().astype(np.int64), ae_score.ravel()


def predict_mlp(model, X):
    model.eval()
    loader = DataLoader(torch.tensor(X, dtype=torch.float32), batch_size=BATCH_SIZE, shuffle=False)
    preds, probs = [], []
    softmax = nn.Softmax(dim=1)
    with torch.no_grad():
        for batch_x in loader:
            batch_x = batch_x.to(DEVICE)
            logits = model(batch_x)
            p = softmax(logits)
            y_pred = torch.argmax(p, dim=1)
            preds.extend(y_pred.cpu().numpy())
            probs.append(p.cpu().numpy())
    return np.array(preds), np.vstack(probs)


def choose_mlp_threshold_recall_with_fpr(y_true, scores):
    candidates = []
    fallback = {"threshold": 0.5, "accuracy": 0.0, "precision": 0.0, "recall": 0.0, "f1": 0.0, "f2": 0.0, "fpr": 1.0, "constraint_satisfied": False}
    for threshold in MLP_THRESHOLD_GRID:
        pred = (scores >= threshold).astype(np.int64)
        acc = accuracy_score(y_true, pred)
        prec = precision_score(y_true, pred, zero_division=0)
        rec = recall_score(y_true, pred, zero_division=0)
        f1 = f1_score(y_true, pred, zero_division=0)
        f2 = fbeta_score(y_true, pred, beta=2, zero_division=0)
        tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
        fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
        item = {"threshold": float(threshold), "accuracy": float(acc), "precision": float(prec), "recall": float(rec), "f1": float(f1), "f2": float(f2), "fpr": float(fpr), "constraint_satisfied": bool(fpr <= MAX_ALLOWED_FPR)}
        if fpr <= MAX_ALLOWED_FPR:
            candidates.append(item)
        if f2 > fallback["f2"] or (np.isclose(f2, fallback["f2"]) and fpr < fallback["fpr"]):
            fallback = item
    if candidates:
        return sorted(candidates, key=lambda d: (d["recall"], d["f1"], -d["fpr"]), reverse=True)[0]
    print(f"ATTENTION: aucun seuil ne respecte MAX_ALLOWED_FPR={MAX_ALLOWED_FPR}. Fallback meilleur F2.")
    return fallback


def evaluate_binary(name, y_true, y_pred, scores=None):
    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    f2 = fbeta_score(y_true, y_pred, beta=2, zero_division=0)
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
    fnr = fn / (fn + tp) if (fn + tp) > 0 else 0.0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    try:
        auc = roc_auc_score(y_true, scores) if scores is not None else np.nan
    except Exception:
        auc = np.nan
    print(f"\n===== RESULTATS {name} =====")
    print("Accuracy              :", acc)
    print("Precision             :", prec)
    print("Recall / DetectionRate:", rec)
    print("F1-score              :", f1)
    print("F2-score              :", f2)
    print("Specificity           :", specificity)
    print("False Positive Rate   :", fpr)
    print("False Negative Rate   :", fnr)
    print("ROC-AUC               :", auc)
    print("\nMatrice de confusion :")
    print(cm)
    print("\nClassification report :")
    print(classification_report(y_true, y_pred, target_names=["Normal", "Attack"], digits=4, zero_division=0))
    return {"accuracy": float(acc), "precision": float(prec), "recall_detection_rate": float(rec), "f1_score": float(f1), "f2_score": float(f2), "specificity": float(specificity), "fpr": float(fpr), "fnr": float(fnr), "roc_auc": float(auc) if not np.isnan(auc) else np.nan, "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)}


# =========================================================
# 8. CHARGEMENT + SPLIT RAW
# =========================================================
df_all, y_all, original_labels, label_col = load_ton_iot_dataset(DATA_FILE)

df_train_full, df_test, y_train_full, y_test, labels_train, labels_test = train_test_split(
    df_all, y_all, original_labels, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=y_all
)
df_train, df_val, y_train, y_val = train_test_split(
    df_train_full, y_train_full, test_size=VALID_SIZE, random_state=RANDOM_STATE, stratify=y_train_full
)

print("\n===== SPLIT DATA =====")
print("Train :", df_train.shape, "| normal=", np.sum(y_train == 0), "| attack=", np.sum(y_train == 1))
print("Val   :", df_val.shape, "| normal=", np.sum(y_val == 0), "| attack=", np.sum(y_val == 1))
print("Test  :", df_test.shape, "| normal=", np.sum(y_test == 0), "| attack=", np.sum(y_test == 1))
print("\n===== CONFIGURATION HFL =====")
print("NUM_CLIENTS :", NUM_CLIENTS)
print("NUM_EDGE_SERVERS :", NUM_EDGE_SERVERS)
print("CLIENT_EDGE_ASSIGNMENTS :", CLIENT_EDGE_ASSIGNMENTS)
print("MAX_ALLOWED_FPR :", MAX_ALLOWED_FPR)

X_train, preprocessor = preprocess_fit(df_train, label_col)
X_val = preprocess_transform(df_val, preprocessor)
X_test = preprocess_transform(df_test, preprocessor)


# =========================================================
# 9. AE NORMAL ONLY + HFL
# =========================================================
X_train_normal = X_train[y_train == 0]
if len(X_train_normal) == 0:
    raise ValueError("Aucune donnee normale dans le train pour l'AE.")
X_ae_train, X_ae_val = train_test_split(X_train_normal, test_size=AE_VALID_SIZE, random_state=RANDOM_STATE)

clients_ae = split_clients_unsupervised(X_ae_train, CLIENT_DATA_PROPORTIONS)
print("\n===== CLIENTS AE HFL =====")
for i, client_X in enumerate(clients_ae):
    print(f"Client AE {i + 1} -> Edge {CLIENT_EDGE_ASSIGNMENTS[i] + 1}: X={client_X.shape}")

input_dim = X_train.shape[1]
global_ae = Autoencoder(input_dim).to(DEVICE)
best_ae_val_loss = float("inf")
best_ae_path = os.path.join(SAVE_FOLDER, "best_hfl_autoencoder_ton_iot.pth")

print("\n===== DEBUT ENTRAINEMENT HFL + AE =====")
for round_idx in range(GLOBAL_ROUNDS):
    print(f"\n--- Round AE HFL {round_idx + 1}/{GLOBAL_ROUNDS} ---")
    local_weights, local_sizes, local_losses = [], [], []
    for client_idx, client_X in enumerate(clients_ae):
        weights, size, loss = train_local_autoencoder(global_ae, client_X, client_idx)
        local_weights.append(weights)
        local_sizes.append(size)
        local_losses.append(loss)
        print(f"Client AE {client_idx + 1} -> Edge {CLIENT_EDGE_ASSIGNMENTS[client_idx] + 1} | size={size} | loss={loss:.6f}")
    global_ae.load_state_dict(hfl_aggregate(local_weights, local_sizes, model_name="Autoencoder"))
    val_errors = compute_reconstruction_errors(global_ae, X_ae_val)
    val_loss = float(np.mean(val_errors))
    print(f"Loss moyenne clients AE : {np.mean(local_losses):.6f}")
    print(f"Validation loss AE      : {val_loss:.6f}")
    if val_loss < best_ae_val_loss:
        best_ae_val_loss = val_loss
        torch.save(global_ae.state_dict(), best_ae_path)
        print(">> Meilleur AE HFL sauvegarde.")

best_ae = Autoencoder(input_dim).to(DEVICE)
best_ae.load_state_dict(torch.load(best_ae_path, map_location=DEVICE))
best_ae.eval()


# =========================================================
# 10. SEUIL AE AUTO + FEATURES MLP
# =========================================================
print("\n===== CHOIX AUTOMATIQUE DU SEUIL AE =====")
normal_reference_errors = compute_reconstruction_errors(best_ae, X_ae_train)
val_errors_for_threshold = compute_reconstruction_errors(best_ae, X_val)
ae_threshold_info = choose_auto_threshold_percentile(normal_reference_errors, val_errors_for_threshold, y_val)
AE_THRESHOLD_PERCENTILE = ae_threshold_info["percentile"]
AE_THRESHOLD = ae_threshold_info["threshold"]
AE_NORMAL_ERROR_STD = float(np.std(normal_reference_errors))
print("threshold_percentile choisi :", AE_THRESHOLD_PERCENTILE)
print("threshold AE                :", AE_THRESHOLD)
print("Validation AE Accuracy      :", ae_threshold_info["accuracy"])
print("Validation AE Precision     :", ae_threshold_info["precision"])
print("Validation AE Recall        :", ae_threshold_info["recall"])
print("Validation AE F1            :", ae_threshold_info["f1"])
print("Validation AE FPR           :", ae_threshold_info["fpr"])

X_mlp_train, train_errors, train_ae_pred, train_ae_score = extract_ae_features_and_detection(best_ae, X_train, AE_THRESHOLD, AE_NORMAL_ERROR_STD)
X_mlp_val, val_errors, val_ae_pred, val_ae_score = extract_ae_features_and_detection(best_ae, X_val, AE_THRESHOLD, AE_NORMAL_ERROR_STD)
X_test_mlp, test_errors, test_ae_pred, test_ae_score = extract_ae_features_and_detection(best_ae, X_test, AE_THRESHOLD, AE_NORMAL_ERROR_STD)

print("\n===== PERFORMANCE AE SEUL VALIDATION =====")
print("Val AE F1 :", f1_score(y_val, val_ae_pred, zero_division=0))
print(confusion_matrix(y_val, val_ae_pred, labels=[0, 1]))

mlp_feature_scaler = StandardScaler()
X_mlp_train = mlp_feature_scaler.fit_transform(X_mlp_train).astype(np.float32)
X_mlp_val = mlp_feature_scaler.transform(X_mlp_val).astype(np.float32)
X_test_mlp = mlp_feature_scaler.transform(X_test_mlp).astype(np.float32)


# =========================================================
# 11. HFL + MLP
# =========================================================
clients_mlp = split_clients_supervised(X_mlp_train, y_train, CLIENT_DATA_PROPORTIONS)
print("\n===== CLIENTS MLP HFL =====")
for i, (client_X, client_y) in enumerate(clients_mlp):
    print(f"Client MLP {i + 1} -> Edge {CLIENT_EDGE_ASSIGNMENTS[i] + 1}: X={client_X.shape} | normal={np.sum(client_y == 0)} | attack={np.sum(client_y == 1)}")

mlp_input_dim = X_mlp_train.shape[1]
global_mlp = MLPBinaryClassifier(mlp_input_dim).to(DEVICE)
best_mlp_val_f1 = -1.0
best_mlp_path = os.path.join(SAVE_FOLDER, "best_hfl_mlp_ton_iot.pth")

print("\n===== DEBUT ENTRAINEMENT HFL + MLP =====")
for round_idx in range(GLOBAL_ROUNDS):
    print(f"\n--- Round MLP HFL {round_idx + 1}/{GLOBAL_ROUNDS} ---")
    local_weights, local_sizes, local_losses = [], [], []
    for client_idx, (client_X, client_y) in enumerate(clients_mlp):
        weights, size, loss = train_local_mlp(global_mlp, client_X, client_y, client_idx)
        local_weights.append(weights)
        local_sizes.append(size)
        local_losses.append(loss)
        print(f"Client MLP {client_idx + 1} -> Edge {CLIENT_EDGE_ASSIGNMENTS[client_idx] + 1} | size={size} | loss={loss:.6f}")
    global_mlp.load_state_dict(hfl_aggregate(local_weights, local_sizes, model_name="MLP"))
    val_pred_argmax, val_probs = predict_mlp(global_mlp, X_mlp_val)
    val_f1 = f1_score(y_val, val_pred_argmax, zero_division=0)
    val_acc = accuracy_score(y_val, val_pred_argmax)
    val_rec = recall_score(y_val, val_pred_argmax, zero_division=0)
    print(f"Loss moyenne clients MLP  : {np.mean(local_losses):.6f}")
    print(f"Validation Accuracy argmax: {val_acc:.6f}")
    print(f"Validation Recall argmax  : {val_rec:.6f}")
    print(f"Validation F1 argmax      : {val_f1:.6f}")
    if val_f1 > best_mlp_val_f1:
        best_mlp_val_f1 = val_f1
        torch.save(global_mlp.state_dict(), best_mlp_path)
        print(">> Meilleur MLP HFL sauvegarde.")

best_mlp = MLPBinaryClassifier(mlp_input_dim).to(DEVICE)
best_mlp.load_state_dict(torch.load(best_mlp_path, map_location=DEVICE))
best_mlp.eval()


# =========================================================
# 12. SEUIL MLP : MAX RECALL SOUS CONTRAINTE FPR
# =========================================================
print("\n===== CHOIX DU SEUIL MLP : MAX RECALL SOUS CONTRAINTE FPR =====")
val_pred_argmax, val_probs = predict_mlp(best_mlp, X_mlp_val)
val_scores = val_probs[:, 1]
mlp_threshold_info = choose_mlp_threshold_recall_with_fpr(y_val, val_scores)
MLP_DECISION_THRESHOLD = mlp_threshold_info["threshold"]
val_pred_threshold = (val_scores >= MLP_DECISION_THRESHOLD).astype(np.int64)
print("Contrainte MAX_ALLOWED_FPR :", MAX_ALLOWED_FPR)
print("Contrainte respectee       :", mlp_threshold_info["constraint_satisfied"])
print("MLP decision threshold     :", MLP_DECISION_THRESHOLD)
print("Validation Accuracy        :", accuracy_score(y_val, val_pred_threshold))
print("Validation Precision       :", precision_score(y_val, val_pred_threshold, zero_division=0))
print("Validation Recall          :", recall_score(y_val, val_pred_threshold, zero_division=0))
print("Validation F1              :", f1_score(y_val, val_pred_threshold, zero_division=0))
print("Validation F2              :", fbeta_score(y_val, val_pred_threshold, beta=2, zero_division=0))
print("Validation confusion       :")
print(confusion_matrix(y_val, val_pred_threshold, labels=[0, 1]))


# =========================================================
# 13. TEST FINAL
# =========================================================
print("\n===== TEST FINAL AE -> MLP HFL SUR ToN-IoT =====")
mlp_pred_argmax, test_probs = predict_mlp(best_mlp, X_test_mlp)
test_scores = test_probs[:, 1]
test_pred_threshold = (test_scores >= MLP_DECISION_THRESHOLD).astype(np.int64)
ae_test_metrics = evaluate_binary("AE HFL SEUL", y_test, test_ae_pred, scores=test_errors)
argmax_metrics = evaluate_binary("HFL AE -> MLP ARGMAX", y_test, mlp_pred_argmax, scores=test_scores)
final_metrics = evaluate_binary("HFL AE -> MLP SEUIL RECALL/FPR", y_test, test_pred_threshold, scores=test_scores)
print("\n===== COMPARAISON ARGMAX VS SEUIL RECALL/FPR =====")
print("Argmax attaques predites :", np.sum(mlp_pred_argmax == 1))
print("Seuil attaques predites  :", np.sum(test_pred_threshold == 1))
print("MLP decision threshold   :", MLP_DECISION_THRESHOLD)
print("MAX_ALLOWED_FPR          :", MAX_ALLOWED_FPR)
print("\n===== RESUME ERREURS RECONSTRUCTION TEST =====")
print(pd.Series(test_errors).describe())
print("\n===== RESUME SCORES MLP TEST =====")
print(pd.Series(test_scores).describe())


# =========================================================
# 14. SAUVEGARDE
# =========================================================
torch.save(best_ae.state_dict(), os.path.join(SAVE_FOLDER, "hfl_autoencoder_ton_iot_final.pth"))
torch.save(best_mlp.state_dict(), os.path.join(SAVE_FOLDER, "hfl_mlp_ton_iot_final.pth"))
save_object(preprocessor, os.path.join(SAVE_FOLDER, "preprocessor_ton_iot.pkl"))
save_object(mlp_feature_scaler, os.path.join(SAVE_FOLDER, "mlp_feature_scaler_ton_iot.pkl"))
save_object(ae_threshold_info, os.path.join(SAVE_FOLDER, "ae_threshold_info_ton_iot.pkl"))
save_object(MLP_DECISION_THRESHOLD, os.path.join(SAVE_FOLDER, "mlp_decision_threshold_ton_iot.pkl"))
save_object(mlp_threshold_info, os.path.join(SAVE_FOLDER, "mlp_threshold_info_ton_iot.pkl"))
metadata = {
    "architecture": "ToN-IoT HFL + AE + MLP. AE normal-only, AE threshold auto, FocalLoss, attack class boost, MLP threshold recall/FPR.",
    "data_file": DATA_FILE,
    "label_col": label_col,
    "num_clients": NUM_CLIENTS,
    "num_edge_servers": NUM_EDGE_SERVERS,
    "client_edge_assignments": CLIENT_EDGE_ASSIGNMENTS,
    "client_data_proportions": CLIENT_DATA_PROPORTIONS,
    "global_rounds": GLOBAL_ROUNDS,
    "local_epochs_ae": LOCAL_EPOCHS_AE,
    "local_epochs_mlp": LOCAL_EPOCHS_MLP,
    "batch_size": BATCH_SIZE,
    "learning_rate_ae": LEARNING_RATE_AE,
    "learning_rate_mlp": LEARNING_RATE_MLP,
    "weight_decay_mlp": WEIGHT_DECAY_MLP,
    "use_focal_loss": USE_FOCAL_LOSS,
    "focal_gamma": FOCAL_GAMMA,
    "attack_class_weight_multiplier": ATTACK_CLASS_WEIGHT_MULTIPLIER,
    "best_ae_val_loss": best_ae_val_loss,
    "best_mlp_val_f1_argmax": best_mlp_val_f1,
    "input_dim": input_dim,
    "mlp_input_dim": mlp_input_dim,
    "ae_threshold_percentile": AE_THRESHOLD_PERCENTILE,
    "ae_threshold": AE_THRESHOLD,
    "max_allowed_fpr": MAX_ALLOWED_FPR,
    "mlp_decision_threshold": MLP_DECISION_THRESHOLD,
}
all_metrics = {
    "ae_test_metrics": ae_test_metrics,
    "argmax_hfl_ae_mlp_metrics": argmax_metrics,
    "final_hfl_ae_mlp_recall_fpr_metrics": final_metrics,
    "ae_threshold_info": ae_threshold_info,
    "mlp_threshold_info": mlp_threshold_info,
}
save_object(metadata, os.path.join(SAVE_FOLDER, "metadata_hfl_ae_mlp_ton_iot_recall_fpr.pkl"))
save_object(all_metrics, os.path.join(SAVE_FOLDER, "metrics_hfl_ae_mlp_ton_iot_recall_fpr.pkl"))
results_df = pd.DataFrame({
    "label_original": labels_test,
    "y_true": y_test,
    "ae_pred": test_ae_pred,
    "mlp_pred_argmax": mlp_pred_argmax,
    "mlp_pred_threshold": test_pred_threshold,
    "reconstruction_error": test_errors,
    "ae_score": test_ae_score,
    "mlp_attack_score": test_scores,
})
results_path = os.path.join(SAVE_FOLDER, "detailed_predictions_hfl_ae_mlp_ton_iot_recall_fpr.csv")
results_df.to_csv(results_path, index=False)
print("\n===== SAUVEGARDE TERMINEE =====")
print("Dossier resultats :", SAVE_FOLDER)
print("Fichier predictions :", results_path)
